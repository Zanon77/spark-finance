const hre = require("hardhat");

async function main() {
  console.log("Starting deployment...\n");

  // Get signers
  const [deployer, bankA, bankB, alice, bob, carol, dave] = await hre.ethers.getSigners();

  console.log("Deployer address:", deployer.address);
  console.log("Bank A address:", bankA.address);
  console.log("Bank B address:", bankB.address);
  console.log("Alice address:", alice.address);
  console.log("Bob address:", bob.address);
  console.log("Carol address:", carol.address);
  console.log("Dave address:", dave.address);
  console.log("\n");

  // Deploy KYC Registry
  console.log("Deploying KYC Registry...");
  const KYCRegistry = await hre.ethers.getContractFactory("KYCRegistry");
  const kycRegistry = await KYCRegistry.deploy();
  await kycRegistry.waitForDeployment();
  const kycAddress = await kycRegistry.getAddress();
  console.log("KYC Registry deployed to:", kycAddress);

  // Whitelist users
  console.log("\nWhitelisting users...");
  await kycRegistry.batchWhitelist(
    [alice.address, bob.address, carol.address, dave.address, bankA.address, bankB.address],
    ["Alice", "Bob", "Carol", "Dave", "Bank A", "Bank B"]
  );
  console.log("Users whitelisted successfully");

  // Deploy Bank A Deposit Token
  console.log("\nDeploying Bank A Deposit Token...");
  const BankDepositToken = await hre.ethers.getContractFactory("BankDepositToken");
  const bankAToken = await BankDepositToken.deploy(
    "Bank A Deposit Token",
    "DA",
    "Bank A",
    kycAddress
  );
  await bankAToken.waitForDeployment();
  const bankATokenAddress = await bankAToken.getAddress();
  console.log("Bank A Token deployed to:", bankATokenAddress);

  // Deploy Bank B Deposit Token
  console.log("\nDeploying Bank B Deposit Token...");
  const bankBToken = await BankDepositToken.deploy(
    "Bank B Deposit Token",
    "DB",
    "Bank B",
    kycAddress
  );
  await bankBToken.waitForDeployment();
  const bankBTokenAddress = await bankBToken.getAddress();
  console.log("Bank B Token deployed to:", bankBTokenAddress);

  // Deploy Consortium Stablecoin
  console.log("\nDeploying Consortium Stablecoin...");
  const ConsortiumStablecoin = await hre.ethers.getContractFactory("ConsortiumStablecoin");
  const consortiumToken = await ConsortiumStablecoin.deploy(kycAddress);
  await consortiumToken.waitForDeployment();
  const consortiumTokenAddress = await consortiumToken.getAddress();
  console.log("Consortium Stablecoin deployed to:", consortiumTokenAddress);

  // Add banks to consortium
  console.log("\nAdding banks to consortium...");
  await consortiumToken.addBank(bankA.address, "Bank A");
  await consortiumToken.addBank(bankB.address, "Bank B");
  console.log("Banks added to consortium");

  // Grant roles
  console.log("\nGranting CONTROLLER_ROLE to deployer...");
  const CONTROLLER_ROLE = await consortiumToken.CONTROLLER_ROLE();
  await consortiumToken.grantRole(CONTROLLER_ROLE, deployer.address);
  console.log("Role granted");

  // Initial deposits for demo
  console.log("\n--- Setting up demo scenario ---");
  
  // Alice deposits at Bank A
  console.log("\nAlice depositing 10,000 DA at Bank A...");
  const aliceDepositAmount = hre.ethers.parseEther("10000");
  await bankAToken.connect(alice).deposit(aliceDepositAmount);
  const aliceBalance = await bankAToken.balanceOf(alice.address);
  console.log("Alice DA balance:", hre.ethers.formatEther(aliceBalance));

  // Bob deposits at Bank B
  console.log("\nBob depositing 10,000 DB at Bank B...");
  const bobDepositAmount = hre.ethers.parseEther("10000");
  await bankBToken.connect(bob).deposit(bobDepositAmount);
  const bobBalance = await bankBToken.balanceOf(bob.address);
  console.log("Bob DB balance:", hre.ethers.formatEther(bobBalance));

  // Save deployment addresses
  const deploymentInfo = {
    network: hre.network.name,
    deployer: deployer.address,
    contracts: {
      KYCRegistry: kycAddress,
      BankAToken: bankATokenAddress,
      BankBToken: bankBTokenAddress,
      ConsortiumStablecoin: consortiumTokenAddress
    },
    accounts: {
      bankA: bankA.address,
      bankB: bankB.address,
      alice: alice.address,
      bob: bob.address,
      carol: carol.address,
      dave: dave.address
    }
  };

  console.log("\n=== Deployment Summary ===");
  console.log(JSON.stringify(deploymentInfo, null, 2));

  // Write to file
  const fs = require('fs');
  fs.writeFileSync(
    'deployment-info.json',
    JSON.stringify(deploymentInfo, null, 2)
  );
  console.log("\nDeployment info saved to deployment-info.json");
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
