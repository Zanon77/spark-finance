const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("Consortium Banking System", function () {
  let kycRegistry, bankAToken, bankBToken, consortiumToken;
  let owner, bankA, bankB, alice, bob, carol, dave;

  beforeEach(async function () {
    [owner, bankA, bankB, alice, bob, carol, dave] = await ethers.getSigners();

    // Deploy KYC Registry
    const KYCRegistry = await ethers.getContractFactory("KYCRegistry");
    kycRegistry = await KYCRegistry.deploy();
    await kycRegistry.waitForDeployment();

    // Whitelist users
    await kycRegistry.batchWhitelist(
      [alice.address, bob.address, carol.address, dave.address, bankA.address, bankB.address],
      ["Alice", "Bob", "Carol", "Dave", "Bank A", "Bank B"]
    );

    // Deploy Bank Tokens
    const BankDepositToken = await ethers.getContractFactory("BankDepositToken");
    bankAToken = await BankDepositToken.deploy("Bank A Deposit", "DA", "Bank A", await kycRegistry.getAddress());
    bankBToken = await BankDepositToken.deploy("Bank B Deposit", "DB", "Bank B", await kycRegistry.getAddress());
    await bankAToken.waitForDeployment();
    await bankBToken.waitForDeployment();

    // Deploy Consortium Token
    const ConsortiumStablecoin = await ethers.getContractFactory("ConsortiumStablecoin");
    consortiumToken = await ConsortiumStablecoin.deploy(await kycRegistry.getAddress());
    await consortiumToken.waitForDeployment();

    // Add banks
    await consortiumToken.addBank(bankA.address, "Bank A");
    await consortiumToken.addBank(bankB.address, "Bank B");
  });

  describe("Flow 1: Deposit → Tokenized Deposit", function () {
    it("Should allow Alice to deposit and receive DA tokens", async function () {
      const depositAmount = ethers.parseEther("10000");
      
      await expect(bankAToken.connect(alice).deposit(depositAmount))
        .to.emit(bankAToken, "DepositMinted")
        .withArgs(alice.address, depositAmount);

      const balance = await bankAToken.balanceOf(alice.address);
      expect(balance).to.equal(depositAmount);
    });

    it("Should enforce daily deposit limit", async function () {
      const limit = ethers.parseEther("50000");
      const excess = ethers.parseEther("50001");

      await expect(bankAToken.connect(alice).deposit(excess))
        .to.be.revertedWith("Exceeds daily deposit limit");
    });

    it("Should enforce per-transaction limit", async function () {
      const excess = ethers.parseEther("10001");

      await expect(bankAToken.connect(alice).deposit(excess))
        .to.be.revertedWith("Exceeds per-transaction limit");
    });
  });

  describe("Flow 2: Tokenized Deposit → Consortium Stablecoin", function () {
    beforeEach(async function () {
      const depositAmount = ethers.parseEther("10000");
      await bankAToken.connect(alice).deposit(depositAmount);
    });

    it("Should convert DA to CS", async function () {
      const convertAmount = ethers.parseEther("4000");
      
      // Bank burns DA
      await bankAToken.burnForConsortium(convertAmount, alice.address);
      
      // Consortium mints CS
      await consortiumToken.connect(bankA).mintFromBankReserve(
        alice.address,
        convertAmount,
        bankA.address
      );

      const csBalance = await consortiumToken.balanceOf(alice.address);
      expect(csBalance).to.equal(convertAmount);
      
      const daBalance = await bankAToken.balanceOf(alice.address);
      expect(daBalance).to.equal(ethers.parseEther("6000"));
    });
  });

  describe("Flow 4: Intra-bank Payment", function () {
    beforeEach(async function () {
      await bankAToken.connect(alice).deposit(ethers.parseEther("10000"));
    });

    it("Should transfer DA from Alice to Carol", async function () {
      const transferAmount = ethers.parseEther("1200");
      
      await expect(bankAToken.connect(alice).transferDeposit(carol.address, transferAmount))
        .to.emit(bankAToken, "DepositTransferred")
        .withArgs(alice.address, carol.address, transferAmount);

      const aliceBalance = await bankAToken.balanceOf(alice.address);
      const carolBalance = await bankAToken.balanceOf(carol.address);
      
      expect(aliceBalance).to.equal(ethers.parseEther("8800"));
      expect(carolBalance).to.equal(transferAmount);
    });

    it("Should reject transfer to non-KYC address", async function () {
      const [nonKYC] = await ethers.getSigners();
      const transferAmount = ethers.parseEther("1000");

      await expect(bankAToken.connect(alice).transferDeposit(nonKYC.address, transferAmount))
        .to.be.revertedWith("Address not KYC approved");
    });
  });

  describe("KYC Registry", function () {
    it("Should whitelist new addresses", async function () {
      const [newUser] = await ethers.getSigners();
      
      await expect(kycRegistry.addToWhitelist(newUser.address, "New User"))
        .to.emit(kycRegistry, "AddressWhitelisted")
        .withArgs(newUser.address, "New User");

      const isWhitelisted = await kycRegistry.isWhitelisted(newUser.address);
      expect(isWhitelisted).to.be.true;
    });

    it("Should remove addresses from whitelist", async function () {
      await expect(kycRegistry.removeFromWhitelist(alice.address))
        .to.emit(kycRegistry, "AddressRemovedFromWhitelist")
        .withArgs(alice.address);

      const isWhitelisted = await kycRegistry.isWhitelisted(alice.address);
      expect(isWhitelisted).to.be.false;
    });
  });
});
