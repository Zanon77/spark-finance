# Backend - Consortium Banking System

Java Spring Boot backend with PostgreSQL database.

## Prerequisites

- Java 17 or higher
- Maven 3.8+
- PostgreSQL 14+

## Setup

1. **Database Setup**

```bash
# Create database
psql -U postgres
CREATE DATABASE consortium_banking;
\q
```

2. **Configure Database**

Edit `src/main/resources/application.properties`:
```properties
spring.datasource.username=your_username
spring.datasource.password=your_password
```

3. **Build and Run**

```bash
# Build the project
./mvnw clean install

# Run the application
./mvnw spring-boot:run
```

The backend will start on `http://localhost:8080`

## Database Views

After the application creates the tables, run the database views:

```bash
psql -U postgres -d consortium_banking -f src/main/resources/database-views.sql
```

## API Endpoints

### Transactions
- `POST /api/transactions` - Create transaction
- `GET /api/transactions/{address}` - Get transactions by address
- `GET /api/transactions/hash/{txHash}` - Get transaction by hash
- `GET /api/transactions/recent/{address}?days=30` - Get recent transactions
- `GET /api/transactions` - Get all transactions
- `PUT /api/transactions/{txHash}/status` - Update transaction status

### Users
- `POST /api/users` - Create user
- `GET /api/users/{walletAddress}` - Get user by wallet
- `GET /api/users` - Get all users
- `GET /api/users/kyc-verified` - Get KYC verified users
- `PUT /api/users/{walletAddress}/verify-kyc` - Verify KYC
- `PUT /api/users/{walletAddress}/login` - Update last login

## Database Schema

### Tables
- `users` - User information and KYC status
- `transactions` - All blockchain transactions

### Views
- `user_transaction_summary` - Aggregated user transaction data
- `daily_transaction_volume` - Daily volume by token type
- `token_distribution` - Token holder statistics
- `failed_transactions_analysis` - Failed transaction analysis
- `inter_bank_settlement` - CS settlement statistics

## Testing

```bash
./mvnw test
```
