package com.consortium.banking.controller;

import com.consortium.banking.service.BlockchainEventListener;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

@RestController
@RequestMapping("/api/events")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "${cors.allowed.origins}")
public class TransactionEventController {
    
    private final BlockchainEventListener eventListener;
    
    /**
     * Receive deposit event from frontend
     */
    @PostMapping("/deposit")
    public ResponseEntity<String> recordDepositEvent(@RequestBody DepositEventRequest request) {
        log.info("Received deposit event: {}", request);
        
        eventListener.recordDeposit(
            request.getTxHash(),
            request.getUserAddress(),
            request.getBank(),
            request.getAmount()
        );
        
        return ResponseEntity.ok("Deposit event recorded");
    }
    
    /**
     * Receive conversion event from frontend
     */
    @PostMapping("/conversion")
    public ResponseEntity<String> recordConversionEvent(@RequestBody ConversionEventRequest request) {
        log.info("Received conversion event: {}", request);
        
        eventListener.recordConversion(
            request.getTxHash(),
            request.getUserAddress(),
            request.getFromToken(),
            request.getAmount()
        );
        
        return ResponseEntity.ok("Conversion event recorded");
    }
    
    /**
     * Receive intra-bank transfer event from frontend
     */
    @PostMapping("/intra-bank-transfer")
    public ResponseEntity<String> recordIntraBankTransferEvent(@RequestBody TransferEventRequest request) {
        log.info("Received intra-bank transfer event: {}", request);
        
        eventListener.recordIntraBankTransfer(
            request.getTxHash(),
            request.getFromAddress(),
            request.getToAddress(),
            request.getTokenType(),
            request.getAmount()
        );
        
        return ResponseEntity.ok("Intra-bank transfer event recorded");
    }
    
    /**
     * Receive inter-bank transfer event from frontend
     */
    @PostMapping("/inter-bank-transfer")
    public ResponseEntity<String> recordInterBankTransferEvent(@RequestBody TransferEventRequest request) {
        log.info("Received inter-bank transfer event: {}", request);
        
        eventListener.recordInterBankTransfer(
            request.getTxHash(),
            request.getFromAddress(),
            request.getToAddress(),
            request.getAmount()
        );
        
        return ResponseEntity.ok("Inter-bank transfer event recorded");
    }
    
    /**
     * Receive CS conversion event from frontend
     */
    @PostMapping("/cs-conversion")
    public ResponseEntity<String> recordCSConversionEvent(@RequestBody CSConversionEventRequest request) {
        log.info("Received CS conversion event: {}", request);
        
        eventListener.recordCSConversion(
            request.getTxHash(),
            request.getUserAddress(),
            request.getToToken(),
            request.getAmount()
        );
        
        return ResponseEntity.ok("CS conversion event recorded");
    }
    
    // Request DTOs
    @Data
    public static class DepositEventRequest {
        private String txHash;
        private String userAddress;
        private String bank; // "A" or "B"
        private BigDecimal amount;
    }
    
    @Data
    public static class ConversionEventRequest {
        private String txHash;
        private String userAddress;
        private String fromToken; // "DA" or "DB"
        private BigDecimal amount;
    }
    
    @Data
    public static class TransferEventRequest {
        private String txHash;
        private String fromAddress;
        private String toAddress;
        private String tokenType; // "DA", "DB", or "CS"
        private BigDecimal amount;
    }
    
    @Data
    public static class CSConversionEventRequest {
        private String txHash;
        private String userAddress;
        private String toToken; // "DA" or "DB"
        private BigDecimal amount;
    }
}
