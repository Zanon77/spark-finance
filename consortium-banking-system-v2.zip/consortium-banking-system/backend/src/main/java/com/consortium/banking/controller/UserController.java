package com.consortium.banking.controller;

import com.consortium.banking.model.User;
import com.consortium.banking.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "${cors.allowed.origins}")
public class UserController {
    
    private final UserService userService;
    
    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody User user) {
        log.info("Creating user: {}", user.getWalletAddress());
        try {
            User created = userService.createUser(user);
            return ResponseEntity.status(HttpStatus.CREATED).body(created);
        } catch (Exception e) {
            log.error("Error creating user", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
    }
    
    @GetMapping("/{walletAddress}")
    public ResponseEntity<User> getUserByWallet(@PathVariable String walletAddress) {
        log.info("Fetching user by wallet: {}", walletAddress);
        return userService.getUserByWalletAddress(walletAddress)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }
    
    @GetMapping
    public ResponseEntity<List<User>> getAllUsers() {
        log.info("Fetching all users");
        try {
            List<User> users = userService.getAllUsers();
            return ResponseEntity.ok(users);
        } catch (Exception e) {
            log.error("Error fetching users", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    @GetMapping("/kyc-verified")
    public ResponseEntity<List<User>> getKYCVerifiedUsers() {
        log.info("Fetching KYC verified users");
        try {
            List<User> users = userService.getKYCVerifiedUsers();
            return ResponseEntity.ok(users);
        } catch (Exception e) {
            log.error("Error fetching KYC verified users", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    @PutMapping("/{walletAddress}/verify-kyc")
    public ResponseEntity<User> verifyKYC(@PathVariable String walletAddress) {
        log.info("Verifying KYC for: {}", walletAddress);
        try {
            User user = userService.verifyKYC(walletAddress);
            return ResponseEntity.ok(user);
        } catch (Exception e) {
            log.error("Error verifying KYC", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    @PutMapping("/{walletAddress}/login")
    public ResponseEntity<User> updateLastLogin(@PathVariable String walletAddress) {
        log.info("Updating last login for: {}", walletAddress);
        try {
            User user = userService.updateLastLogin(walletAddress);
            return ResponseEntity.ok(user);
        } catch (Exception e) {
            log.error("Error updating last login", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
