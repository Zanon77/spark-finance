package com.consortium.banking.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "transactions")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Transaction {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String txHash;
    
    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private TransactionType type;
    
    @Column(nullable = false)
    private String fromAddress;
    
    @Column(nullable = false)
    private String toAddress;
    
    @Column(nullable = false, precision = 20, scale = 2)
    private BigDecimal amount;
    
    @Column(nullable = false)
    private String tokenType; // DA, DB, or CS
    
    @Column(nullable = false)
    private LocalDateTime timestamp;
    
    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private TransactionStatus status;
    
    private String errorMessage;
    
    @Column(nullable = false)
    private Long blockNumber;
    
    private BigDecimal gasFee;
    
    public enum TransactionType {
        DEPOSIT,
        TRANSFER,
        CONVERSION,
        BURN,
        MINT
    }
    
    public enum TransactionStatus {
        PENDING,
        CONFIRMED,
        FAILED
    }
}
