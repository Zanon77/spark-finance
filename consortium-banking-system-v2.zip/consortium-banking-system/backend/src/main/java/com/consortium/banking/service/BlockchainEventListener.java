package com.consortium.banking.service;

import com.consortium.banking.model.Transaction;
import com.consortium.banking.repository.TransactionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Service
@EnableAsync
@RequiredArgsConstructor
@Slf4j
public class BlockchainEventListener {
    
    private final TransactionRepository transactionRepository;
    
    /**
     * Record a deposit transaction
     */
    @Async
    public void recordDeposit(String txHash, String userAddress, String bank, BigDecimal amount) {
        log.info("Recording deposit transaction: {} for user: {}", txHash, userAddress);
        
        Transaction transaction = new Transaction();
        transaction.setTxHash(txHash);
        transaction.setType(Transaction.TransactionType.DEPOSIT);
        transaction.setFromAddress(userAddress);
        transaction.setToAddress("Bank " + bank.toUpperCase());
        transaction.setAmount(amount);
        transaction.setTokenType(bank.equalsIgnoreCase("A") ? "DA" : "DB");
        transaction.setTimestamp(LocalDateTime.now());
        transaction.setStatus(Transaction.TransactionStatus.CONFIRMED);
        transaction.setBlockNumber(System.currentTimeMillis()); // Simulated block number
        transaction.setGasFee(new BigDecimal("0.001"));
        
        transactionRepository.save(transaction);
        log.info("Deposit transaction recorded successfully");
    }
    
    /**
     * Record a conversion transaction (DA/DB to CS)
     */
    @Async
    public void recordConversion(String txHash, String userAddress, String fromToken, BigDecimal amount) {
        log.info("Recording conversion transaction: {} for user: {}", txHash, userAddress);
        
        // Record the burn
        Transaction burnTx = new Transaction();
        burnTx.setTxHash(txHash + "-burn");
        burnTx.setType(Transaction.TransactionType.BURN);
        burnTx.setFromAddress(userAddress);
        burnTx.setToAddress("Consortium");
        burnTx.setAmount(amount);
        burnTx.setTokenType(fromToken);
        burnTx.setTimestamp(LocalDateTime.now());
        burnTx.setStatus(Transaction.TransactionStatus.CONFIRMED);
        burnTx.setBlockNumber(System.currentTimeMillis());
        burnTx.setGasFee(new BigDecimal("0.001"));
        
        transactionRepository.save(burnTx);
        
        // Record the mint
        Transaction mintTx = new Transaction();
        mintTx.setTxHash(txHash + "-mint");
        mintTx.setType(Transaction.TransactionType.MINT);
        mintTx.setFromAddress("Consortium");
        mintTx.setToAddress(userAddress);
        mintTx.setAmount(amount);
        mintTx.setTokenType("CS");
        mintTx.setTimestamp(LocalDateTime.now());
        mintTx.setStatus(Transaction.TransactionStatus.CONFIRMED);
        mintTx.setBlockNumber(System.currentTimeMillis());
        mintTx.setGasFee(new BigDecimal("0.001"));
        
        transactionRepository.save(mintTx);
        
        log.info("Conversion transaction recorded successfully");
    }
    
    /**
     * Record an intra-bank transfer
     */
    @Async
    public void recordIntraBankTransfer(String txHash, String fromAddress, String toAddress, 
                                        String tokenType, BigDecimal amount) {
        log.info("Recording intra-bank transfer: {} from {} to {}", txHash, fromAddress, toAddress);
        
        Transaction transaction = new Transaction();
        transaction.setTxHash(txHash);
        transaction.setType(Transaction.TransactionType.TRANSFER);
        transaction.setFromAddress(fromAddress);
        transaction.setToAddress(toAddress);
        transaction.setAmount(amount);
        transaction.setTokenType(tokenType);
        transaction.setTimestamp(LocalDateTime.now());
        transaction.setStatus(Transaction.TransactionStatus.CONFIRMED);
        transaction.setBlockNumber(System.currentTimeMillis());
        transaction.setGasFee(new BigDecimal("0.0005"));
        
        transactionRepository.save(transaction);
        log.info("Intra-bank transfer recorded successfully");
    }
    
    /**
     * Record an inter-bank transfer (CS transfer)
     */
    @Async
    public void recordInterBankTransfer(String txHash, String fromAddress, String toAddress, 
                                        BigDecimal amount) {
        log.info("Recording inter-bank transfer: {} from {} to {}", txHash, fromAddress, toAddress);
        
        Transaction transaction = new Transaction();
        transaction.setTxHash(txHash);
        transaction.setType(Transaction.TransactionType.TRANSFER);
        transaction.setFromAddress(fromAddress);
        transaction.setToAddress(toAddress);
        transaction.setAmount(amount);
        transaction.setTokenType("CS");
        transaction.setTimestamp(LocalDateTime.now());
        transaction.setStatus(Transaction.TransactionStatus.CONFIRMED);
        transaction.setBlockNumber(System.currentTimeMillis());
        transaction.setGasFee(new BigDecimal("0.0005"));
        
        transactionRepository.save(transaction);
        log.info("Inter-bank transfer recorded successfully");
    }
    
    /**
     * Record CS to DA/DB conversion
     */
    @Async
    public void recordCSConversion(String txHash, String userAddress, String toToken, BigDecimal amount) {
        log.info("Recording CS conversion transaction: {} for user: {}", txHash, userAddress);
        
        // Record the CS burn
        Transaction burnTx = new Transaction();
        burnTx.setTxHash(txHash + "-cs-burn");
        burnTx.setType(Transaction.TransactionType.BURN);
        burnTx.setFromAddress(userAddress);
        burnTx.setToAddress("Consortium");
        burnTx.setAmount(amount);
        burnTx.setTokenType("CS");
        burnTx.setTimestamp(LocalDateTime.now());
        burnTx.setStatus(Transaction.TransactionStatus.CONFIRMED);
        burnTx.setBlockNumber(System.currentTimeMillis());
        burnTx.setGasFee(new BigDecimal("0.001"));
        
        transactionRepository.save(burnTx);
        
        // Record the DA/DB mint
        Transaction mintTx = new Transaction();
        mintTx.setTxHash(txHash + "-token-mint");
        mintTx.setType(Transaction.TransactionType.MINT);
        mintTx.setFromAddress("Bank " + (toToken.equals("DA") ? "A" : "B"));
        mintTx.setToAddress(userAddress);
        mintTx.setAmount(amount);
        mintTx.setTokenType(toToken);
        mintTx.setTimestamp(LocalDateTime.now());
        mintTx.setStatus(Transaction.TransactionStatus.CONFIRMED);
        mintTx.setBlockNumber(System.currentTimeMillis());
        mintTx.setGasFee(new BigDecimal("0.001"));
        
        transactionRepository.save(mintTx);
        
        log.info("CS conversion transaction recorded successfully");
    }
}
