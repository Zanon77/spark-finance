package com.consortium.banking.service;

import com.consortium.banking.model.User;
import com.consortium.banking.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserService {
    
    private final UserRepository userRepository;
    
    @Transactional
    public User createUser(User user) {
        log.info("Creating user with wallet address: {}", user.getWalletAddress());
        
        if (userRepository.existsByWalletAddress(user.getWalletAddress())) {
            throw new RuntimeException("User already exists with this wallet address");
        }
        
        return userRepository.save(user);
    }
    
    public Optional<User> getUserByWalletAddress(String walletAddress) {
        return userRepository.findByWalletAddress(walletAddress);
    }
    
    public List<User> getKYCVerifiedUsers() {
        return userRepository.findByKycVerified(true);
    }
    
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
    
    @Transactional
    public User updateLastLogin(String walletAddress) {
        Optional<User> userOpt = userRepository.findByWalletAddress(walletAddress);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            user.setLastLoginAt(LocalDateTime.now());
            return userRepository.save(user);
        }
        throw new RuntimeException("User not found: " + walletAddress);
    }
    
    @Transactional
    public User verifyKYC(String walletAddress) {
        Optional<User> userOpt = userRepository.findByWalletAddress(walletAddress);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            user.setKycVerified(true);
            log.info("KYC verified for user: {}", walletAddress);
            return userRepository.save(user);
        }
        throw new RuntimeException("User not found: " + walletAddress);
    }
}
