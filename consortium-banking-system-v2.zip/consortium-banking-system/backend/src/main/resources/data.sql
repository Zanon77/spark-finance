-- Sample Users Data
INSERT INTO users (wallet_address, name, kyc_verified, email, phone, created_at) VALUES
('0x70997970C51812dc3A010C7d01b50e0d17dc79C8', 'Alice', true, 'alice@example.com', '+1-555-0101', CURRENT_TIMESTAMP),
('0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC', 'Bob', true, 'bob@example.com', '+1-555-0102', CURRENT_TIMESTAMP),
('0x90F79bf6EB2c4f870365E785982E1f101E93b906', 'Carol', true, 'carol@example.com', '+1-555-0103', CURRENT_TIMESTAMP),
('0x15d34AAf54267DB7D7c367839AAf71A00a2C6A65', 'Dave', true, 'dave@example.com', '+1-555-0104', CURRENT_TIMESTAMP);

-- Sample Transactions Data
INSERT INTO transactions (tx_hash, type, from_address, to_address, amount, token_type, timestamp, status, block_number, gas_fee) VALUES
('0xabc123...', 'DEPOSIT', '0x70997970C51812dc3A010C7d01b50e0d17dc79C8', 'BankA', 10000.00, 'DA', CURRENT_TIMESTAMP, 'CONFIRMED', 1, 0.001),
('0xdef456...', 'DEPOSIT', '0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC', 'BankB', 10000.00, 'DB', CURRENT_TIMESTAMP, 'CONFIRMED', 2, 0.001),
('0xghi789...', 'CONVERSION', '0x70997970C51812dc3A010C7d01b50e0d17dc79C8', 'Consortium', 4000.00, 'CS', CURRENT_TIMESTAMP, 'CONFIRMED', 3, 0.001);
