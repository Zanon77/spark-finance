import React, { useState } from 'react';
import {
  Box,
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Alert,
  CircularProgress,
  Typography,
  Paper,
} from '@mui/material';
import SwapHorizIcon from '@mui/icons-material/SwapHoriz';
import axios from 'axios';
import { getBalances, updateBalance } from './BalanceViewDemo';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8080';

function ConversionFlowDemo({ account }) {
  const [fromToken, setFromToken] = useState('DA');
  const [amount, setAmount] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  const handleConvert = async (e) => {
    e.preventDefault();
    setSuccess('');
    setError('');

    if (!amount || parseFloat(amount) <= 0) {
      setError('Please enter a valid amount');
      return;
    }

    if (parseFloat(amount) > 10000) {
      setError('Exceeds per-transaction conversion limit of $10,000');
      return;
    }

    const bankToken = fromToken === 'DA' ? 'bankA' : 'bankB';
    const currentBalances = getBalances(account.address);

    if (currentBalances[bankToken] < parseFloat(amount)) {
      setError(`Insufficient ${fromToken} balance. You have ${currentBalances[bankToken].toFixed(2)} ${fromToken}`);
      return;
    }

    try {
      setLoading(true);
      
      // Simulate blockchain transaction
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Generate transaction hash
      const txHash = '0x' + Math.random().toString(16).substr(2, 40);
      
      // Burn deposit tokens
      const newBankBalance = currentBalances[bankToken] - parseFloat(amount);
      updateBalance(account.address, bankToken, newBankBalance);
      
      // Mint CS tokens
      const newCSBalance = currentBalances.consortium + parseFloat(amount);
      updateBalance(account.address, 'consortium', newCSBalance);
      
      // ✅ SEND EVENT TO BACKEND
      try {
        await axios.post(`${API_URL}/api/events/conversion`, {
          txHash: txHash,
          userAddress: account.address,
          fromToken: fromToken,
          amount: parseFloat(amount)
        });
        console.log('✅ Conversion event sent to backend');
      } catch (backendError) {
        console.error('Failed to record event in backend:', backendError);
      }
      
      setSuccess(`✅ Conversion successful! Burned ${amount} ${fromToken}, Minted ${amount} CS. TX: ${txHash.substring(0, 10)}...`);
      setAmount('');
    } catch (err) {
      setError(err.message || 'Conversion failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Paper sx={{ p: 3 }}>
      <Typography variant="h6" gutterBottom>
        Flow 2: Tokenized Deposit ↔ Consortium Stablecoin
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Convert your bank deposit tokens to consortium stablecoin for cross-bank transactions
      </Typography>

      <Box component="form" onSubmit={handleConvert}>
        <FormControl fullWidth sx={{ mb: 2 }}>
          <InputLabel>From Token</InputLabel>
          <Select
            value={fromToken}
            label="From Token"
            onChange={(e) => setFromToken(e.target.value)}
          >
            <MenuItem value="DA">DA (Bank A Deposit Token)</MenuItem>
            <MenuItem value="DB">DB (Bank B Deposit Token)</MenuItem>
          </Select>
        </FormControl>

        <TextField
          fullWidth
          label="Amount"
          type="number"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          sx={{ mb: 2 }}
          inputProps={{ step: '0.01', min: '0' }}
          helperText={`Convert ${fromToken} to CS at 1:1 ratio`}
        />

        <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 2 }}>
          💡 Conversion Rate: 1 {fromToken} = 1 CS | Per Transaction Limit: $10,000
        </Typography>

        {success && <Alert severity="success" sx={{ mb: 2 }}>{success}</Alert>}
        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

        <Button
          type="submit"
          variant="contained"
          fullWidth
          startIcon={loading ? <CircularProgress size={20} /> : <SwapHorizIcon />}
          disabled={loading}
        >
          {loading ? 'Converting...' : `Convert ${fromToken} to CS`}
        </Button>
      </Box>

      <Box sx={{ mt: 3, p: 2, bgcolor: '#fff3e0', borderRadius: 1 }}>
        <Typography variant="caption" display="block">
          <strong>How it works:</strong>
        </Typography>
        <Typography variant="caption" component="div">
          1. User requests to convert DA/DB to CS<br/>
          2. Bank burns the deposit tokens<br/>
          3. Bank's reserve contribution is recorded (50/50 split)<br/>
          4. Consortium mints CS tokens to user<br/>
          5. CS can now be used for cross-bank settlements
        </Typography>
      </Box>
    </Paper>
  );
}

export default ConversionFlowDemo;
