import React, { useState, useEffect } from 'react';
import {
  Paper,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  Box,
  CircularProgress,
  Button,
} from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8080';

function TransactionHistoryDemo({ account }) {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchTransactions = async () => {
    setLoading(true);
    setError('');
    try {
      // Fetch transactions for this account from backend
      const response = await axios.get(`${API_URL}/api/transactions/${account.address}`);
      setTransactions(response.data);
      console.log('✅ Fetched transactions from backend:', response.data.length);
    } catch (err) {
      console.error('Failed to fetch transactions:', err);
      setError('Failed to load transactions from backend');
      setTransactions([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTransactions();
    
    // Auto-refresh every 5 seconds
    const interval = setInterval(fetchTransactions, 5000);
    return () => clearInterval(interval);
  }, [account.address]);

  const getTypeColor = (type) => {
    switch (type) {
      case 'DEPOSIT':
        return 'success';
      case 'TRANSFER':
        return 'primary';
      case 'CONVERSION':
        return 'warning';
      case 'BURN':
        return 'error';
      case 'MINT':
        return 'info';
      default:
        return 'default';
    }
  };

  const formatAddress = (addr) => {
    if (addr.includes('Bank') || addr.includes('Consortium')) return addr;
    return `${addr.substring(0, 6)}...${addr.substring(addr.length - 4)}`;
  };

  if (loading && transactions.length === 0) {
    return (
      <Paper sx={{ p: 3 }}>
        <Box display="flex" justifyContent="center" alignItems="center" p={3}>
          <CircularProgress />
          <Typography variant="body2" sx={{ ml: 2 }}>
            Loading transactions from backend...
          </Typography>
        </Box>
      </Paper>
    );
  }

  return (
    <Paper sx={{ p: 3 }}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
        <div>
          <Typography variant="h6">
            Transaction History
          </Typography>
          <Typography variant="body2" color="text.secondary">
            All transactions for {account.name} (real-time from backend)
          </Typography>
        </div>
        <Button
          variant="outlined"
          startIcon={<RefreshIcon />}
          onClick={fetchTransactions}
          disabled={loading}
        >
          Refresh
        </Button>
      </Box>

      {error && (
        <Box sx={{ p: 2, mb: 2, bgcolor: '#fff3e0', borderRadius: 1 }}>
          <Typography variant="body2" color="error">
            {error}
          </Typography>
        </Box>
      )}

      {transactions.length === 0 ? (
        <Box sx={{ p: 3, textAlign: 'center', bgcolor: '#f5f5f5', borderRadius: 1 }}>
          <Typography variant="body2" color="text.secondary">
            No transactions yet. Start by making a deposit!
          </Typography>
          <Typography variant="caption" color="text.secondary" display="block" sx={{ mt: 1 }}>
            Transactions are automatically recorded in the backend database when you perform any operation.
          </Typography>
        </Box>
      ) : (
        <>
          <Box sx={{ mb: 2, p: 2, bgcolor: '#e8f5e9', borderRadius: 1 }}>
            <Typography variant="body2">
              ✅ <strong>{transactions.length} transaction(s)</strong> found in backend database
            </Typography>
          </Box>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell><strong>Type</strong></TableCell>
                  <TableCell><strong>Amount</strong></TableCell>
                  <TableCell><strong>Token</strong></TableCell>
                  <TableCell><strong>From</strong></TableCell>
                  <TableCell><strong>To</strong></TableCell>
                  <TableCell><strong>Date</strong></TableCell>
                  <TableCell><strong>Status</strong></TableCell>
                  <TableCell><strong>TX Hash</strong></TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {transactions.map((tx) => (
                  <TableRow key={tx.id} hover>
                    <TableCell>
                      <Chip label={tx.type} color={getTypeColor(tx.type)} size="small" />
                    </TableCell>
                    <TableCell>
                      <strong>${parseFloat(tx.amount).toLocaleString()}</strong>
                    </TableCell>
                    <TableCell>
                      <Chip label={tx.tokenType} variant="outlined" size="small" />
                    </TableCell>
                    <TableCell>{formatAddress(tx.fromAddress)}</TableCell>
                    <TableCell>{formatAddress(tx.toAddress)}</TableCell>
                    <TableCell>
                      {new Date(tx.timestamp).toLocaleString()}
                    </TableCell>
                    <TableCell>
                      <Chip 
                        label={tx.status} 
                        color={tx.status === 'CONFIRMED' ? 'success' : 'default'} 
                        size="small" 
                        variant="outlined"
                      />
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" sx={{ fontFamily: 'monospace', color: '#1976d2', fontSize: '0.75rem' }}>
                        {tx.txHash.substring(0, 16)}...
                      </Typography>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </>
      )}

      <Box sx={{ mt: 3, p: 2, bgcolor: '#f5f5f5', borderRadius: 1 }}>
        <Typography variant="caption" color="text.secondary">
          <strong>🔄 Real-Time Updates:</strong> This data is fetched from the H2 database via Spring Boot REST API. 
          Every transaction you perform is automatically recorded by the event listener in the backend.
          The table refreshes every 5 seconds automatically.
        </Typography>
      </Box>
    </Paper>
  );
}

export default TransactionHistoryDemo;
