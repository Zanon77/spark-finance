import React from 'react';
import { Button, Chip } from '@mui/material';
import AccountBalanceWalletIcon from '@mui/icons-material/AccountBalanceWallet';
import { formatAddress } from '../utils/web3';

function WalletConnection({ account, onConnect }) {
  return (
    <>
      {account ? (
        <Chip
          icon={<AccountBalanceWalletIcon />}
          label={formatAddress(account)}
          color="primary"
          variant="outlined"
          sx={{ color: 'white', borderColor: 'white' }}
        />
      ) : (
        <Button
          variant="contained"
          color="secondary"
          startIcon={<AccountBalanceWalletIcon />}
          onClick={onConnect}
        >
          Connect Wallet
        </Button>
      )}
    </>
  );
}

export default WalletConnection;
