import React, { useState, useEffect } from 'react';
import {
  Paper,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  CircularProgress,
  Box,
} from '@mui/material';
import axios from 'axios';

function TransactionHistory({ account }) {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTransactions = async () => {
      try {
        setLoading(true);
        const response = await axios.get(
          `${process.env.REACT_APP_API_URL}/api/transactions/${account}`
        );
        setTransactions(response.data);
      } catch (error) {
        console.error('Error fetching transactions:', error);
        // For demo purposes, show some mock data if backend is not available
        setTransactions([
          {
            id: 1,
            type: 'DEPOSIT',
            amount: '10000',
            from: account,
            to: 'Bank A',
            timestamp: new Date().toISOString(),
            txHash: '0x1234567890abcdef',
          },
        ]);
      } finally {
        setLoading(false);
      }
    };

    fetchTransactions();
  }, [account]);

  const getTypeColor = (type) => {
    switch (type) {
      case 'DEPOSIT':
        return 'success';
      case 'TRANSFER':
        return 'primary';
      case 'CONVERSION':
        return 'warning';
      default:
        return 'default';
    }
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" p={4}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Paper sx={{ p: 3 }}>
      <Typography variant="h6" gutterBottom>
        Transaction History
      </Typography>

      {transactions.length === 0 ? (
        <Typography variant="body2" color="text.secondary" sx={{ p: 3, textAlign: 'center' }}>
          No transactions yet
        </Typography>
      ) : (
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Type</TableCell>
                <TableCell>Amount</TableCell>
                <TableCell>From</TableCell>
                <TableCell>To</TableCell>
                <TableCell>Date</TableCell>
                <TableCell>TX Hash</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {transactions.map((tx) => (
                <TableRow key={tx.id}>
                  <TableCell>
                    <Chip label={tx.type} color={getTypeColor(tx.type)} size="small" />
                  </TableCell>
                  <TableCell>${parseFloat(tx.amount).toFixed(2)}</TableCell>
                  <TableCell>
                    {tx.from.substring(0, 6)}...{tx.from.substring(tx.from.length - 4)}
                  </TableCell>
                  <TableCell>
                    {tx.to.substring(0, 6)}...{tx.to.substring(tx.to.length - 4)}
                  </TableCell>
                  <TableCell>
                    {new Date(tx.timestamp).toLocaleString()}
                  </TableCell>
                  <TableCell>
                    <a
                      href={`https://etherscan.io/tx/${tx.txHash}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{ color: '#1976d2' }}
                    >
                      {tx.txHash.substring(0, 10)}...
                    </a>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
    </Paper>
  );
}

export default TransactionHistory;
