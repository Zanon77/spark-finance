import React, { useState } from 'react';
import {
  Box,
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Alert,
  CircularProgress,
  Typography,
  Paper,
} from '@mui/material';
import SwapHorizIcon from '@mui/icons-material/SwapHoriz';
import { convertToConsortium, addresses } from '../utils/contracts';

function ConversionFlow({ account }) {
  const [fromToken, setFromToken] = useState('DA');
  const [amount, setAmount] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  const handleConvert = async (e) => {
    e.preventDefault();
    setSuccess('');
    setError('');

    if (!amount || parseFloat(amount) <= 0) {
      setError('Please enter a valid amount');
      return;
    }

    if (parseFloat(amount) > 10000) {
      setError('Exceeds per-transaction conversion limit of $10,000');
      return;
    }

    try {
      setLoading(true);
      const bankAddress = fromToken === 'DA' ? addresses.bankA : addresses.bankB;
      const txHash = await convertToConsortium(bankAddress, amount);
      setSuccess(`Conversion successful! ${amount} ${fromToken} → ${amount} CS. TX: ${txHash.substring(0, 10)}...`);
      setAmount('');
    } catch (err) {
      setError(err.message || 'Conversion failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Paper sx={{ p: 3 }}>
      <Typography variant="h6" gutterBottom>
        Flow 2: Tokenized Deposit ↔ Consortium Stablecoin
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Convert your bank deposit tokens to the consortium stablecoin for cross-bank transactions
      </Typography>

      <Box component="form" onSubmit={handleConvert}>
        <FormControl fullWidth sx={{ mb: 2 }}>
          <InputLabel>From Token</InputLabel>
          <Select
            value={fromToken}
            label="From Token"
            onChange={(e) => setFromToken(e.target.value)}
          >
            <MenuItem value="DA">DA (Bank A Deposit Token)</MenuItem>
            <MenuItem value="DB">DB (Bank B Deposit Token)</MenuItem>
          </Select>
        </FormControl>

        <TextField
          fullWidth
          label="Amount"
          type="number"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          sx={{ mb: 2 }}
          inputProps={{ step: '0.01', min: '0' }}
          helperText={`Convert ${fromToken} to CS at 1:1 ratio`}
        />

        <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 2 }}>
          Per Transaction Limit: $10,000
        </Typography>

        {success && <Alert severity="success" sx={{ mb: 2 }}>{success}</Alert>}
        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

        <Button
          type="submit"
          variant="contained"
          fullWidth
          startIcon={loading ? <CircularProgress size={20} /> : <SwapHorizIcon />}
          disabled={loading}
        >
          {loading ? 'Converting...' : `Convert to CS`}
        </Button>
      </Box>

      <Box sx={{ mt: 3, p: 2, bgcolor: '#f5f5f5', borderRadius: 1 }}>
        <Typography variant="caption" color="text.secondary">
          <strong>Note:</strong> When you convert deposit tokens to CS, your bank's deposit tokens are burned
          and consortium stablecoins are minted. The reserve is tracked on-chain with a 50/50 split between banks.
        </Typography>
      </Box>
    </Paper>
  );
}

export default ConversionFlow;
