import React, { useState } from 'react';
import {
  Box,
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Alert,
  CircularProgress,
  Typography,
  Paper,
  Tabs,
  Tab,
} from '@mui/material';
import SendIcon from '@mui/icons-material/Send';
import axios from 'axios';
import { getBalances, updateBalance } from './BalanceViewDemo';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8080';

function TabPanel({ children, value, index }) {
  return (
    <div hidden={value !== index}>
      {value === index && <Box sx={{ pt: 2 }}>{children}</Box>}
    </div>
  );
}

const ACCOUNTS = [
  { address: '0x70997970C51812dc3A010C7d01b50e0d17dc79C8', name: 'Alice' },
  { address: '0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC', name: 'Bob' },
  { address: '0x90F79bf6EB2c4f870365E785982E1f101E93b906', name: 'Carol' },
  { address: '0x15d34AAf54267DB7D7c367839AAf71A00a2C6A65', name: 'Dave' },
];

function TransferFlowDemo({ account }) {
  const [tabValue, setTabValue] = useState(0);
  const [bank, setBank] = useState('bankA');
  const [toAddress, setToAddress] = useState('');
  const [amount, setAmount] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  const handleIntraBankTransfer = async (e) => {
    e.preventDefault();
    setSuccess('');
    setError('');

    if (!toAddress || !amount) {
      setError('Please fill in all fields');
      return;
    }

    if (parseFloat(amount) > 10000) {
      setError('Exceeds per-transaction limit of $10,000');
      return;
    }

    const currentBalances = getBalances(account.address);
    if (currentBalances[bank] < parseFloat(amount)) {
      setError(`Insufficient balance. You have ${currentBalances[bank].toFixed(2)} ${bank === 'bankA' ? 'DA' : 'DB'}`);
      return;
    }

    try {
      setLoading(true);
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Generate transaction hash
      const txHash = '0x' + Math.random().toString(16).substr(2, 40);
      
      // Deduct from sender
      const newSenderBalance = currentBalances[bank] - parseFloat(amount);
      updateBalance(account.address, bank, newSenderBalance);
      
      // Add to recipient
      const recipientBalances = getBalances(toAddress);
      const newRecipientBalance = recipientBalances[bank] + parseFloat(amount);
      updateBalance(toAddress, bank, newRecipientBalance);
      
      // ✅ SEND EVENT TO BACKEND
      try {
        await axios.post(`${API_URL}/api/events/intra-bank-transfer`, {
          txHash: txHash,
          fromAddress: account.address,
          toAddress: toAddress,
          tokenType: bank === 'bankA' ? 'DA' : 'DB',
          amount: parseFloat(amount)
        });
        console.log('✅ Intra-bank transfer event sent to backend');
      } catch (backendError) {
        console.error('Failed to record event in backend:', backendError);
      }
      
      const recipientName = ACCOUNTS.find(acc => acc.address === toAddress)?.name || 'Unknown';
      
      setSuccess(`✅ Transfer successful! Sent ${amount} ${bank === 'bankA' ? 'DA' : 'DB'} to ${recipientName}. TX: ${txHash.substring(0, 10)}...`);
      setToAddress('');
      setAmount('');
    } catch (err) {
      setError(err.message || 'Transfer failed');
    } finally {
      setLoading(false);
    }
  };

  const handleInterBankTransfer = async (e) => {
    e.preventDefault();
    setSuccess('');
    setError('');

    if (!toAddress || !amount) {
      setError('Please fill in all fields');
      return;
    }

    if (parseFloat(amount) > 10000) {
      setError('Exceeds per-transaction limit of $10,000');
      return;
    }

    const currentBalances = getBalances(account.address);
    if (currentBalances.consortium < parseFloat(amount)) {
      setError(`Insufficient CS balance. You have ${currentBalances.consortium.toFixed(2)} CS`);
      return;
    }

    try {
      setLoading(true);
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Generate transaction hash
      const txHash = '0x' + Math.random().toString(16).substr(2, 40);
      
      // Deduct CS from sender
      const newSenderBalance = currentBalances.consortium - parseFloat(amount);
      updateBalance(account.address, 'consortium', newSenderBalance);
      
      // Add CS to recipient
      const recipientBalances = getBalances(toAddress);
      const newRecipientBalance = recipientBalances.consortium + parseFloat(amount);
      updateBalance(toAddress, 'consortium', newRecipientBalance);
      
      // ✅ SEND EVENT TO BACKEND
      try {
        await axios.post(`${API_URL}/api/events/inter-bank-transfer`, {
          txHash: txHash,
          fromAddress: account.address,
          toAddress: toAddress,
          tokenType: 'CS',
          amount: parseFloat(amount)
        });
        console.log('✅ Inter-bank transfer event sent to backend');
      } catch (backendError) {
        console.error('Failed to record event in backend:', backendError);
      }
      
      const recipientName = ACCOUNTS.find(acc => acc.address === toAddress)?.name || 'Unknown';
      
      setSuccess(`✅ Inter-bank transfer successful! Sent ${amount} CS to ${recipientName}. TX: ${txHash.substring(0, 10)}...`);
      setToAddress('');
      setAmount('');
    } catch (err) {
      setError(err.message || 'Transfer failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Paper sx={{ p: 3 }}>
      <Typography variant="h6" gutterBottom>
        Transfer Funds
      </Typography>

      <Tabs value={tabValue} onChange={(e, v) => setTabValue(v)} sx={{ mb: 2 }}>
        <Tab label="Flow 4: Intra-Bank" />
        <Tab label="Flow 5: Inter-Bank" />
      </Tabs>

      <TabPanel value={tabValue} index={0}>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
          Transfer deposit tokens within the same bank (DA→DA or DB→DB). Instant on-chain settlement.
        </Typography>

        <Box component="form" onSubmit={handleIntraBankTransfer}>
          <FormControl fullWidth sx={{ mb: 2 }}>
            <InputLabel>Bank</InputLabel>
            <Select
              value={bank}
              label="Bank"
              onChange={(e) => setBank(e.target.value)}
            >
              <MenuItem value="bankA">Bank A (DA tokens)</MenuItem>
              <MenuItem value="bankB">Bank B (DB tokens)</MenuItem>
            </Select>
          </FormControl>

          <FormControl fullWidth sx={{ mb: 2 }}>
            <InputLabel>Recipient</InputLabel>
            <Select
              value={toAddress}
              label="Recipient"
              onChange={(e) => setToAddress(e.target.value)}
            >
              {ACCOUNTS.filter(acc => acc.address !== account.address).map(acc => (
                <MenuItem key={acc.address} value={acc.address}>
                  {acc.name} ({acc.address.substring(0, 6)}...{acc.address.substring(38)})
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          <TextField
            fullWidth
            label="Amount"
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            sx={{ mb: 2 }}
            inputProps={{ step: '0.01', min: '0' }}
          />

          {success && <Alert severity="success" sx={{ mb: 2 }}>{success}</Alert>}
          {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

          <Button
            type="submit"
            variant="contained"
            fullWidth
            startIcon={loading ? <CircularProgress size={20} /> : <SendIcon />}
            disabled={loading}
          >
            {loading ? 'Processing...' : 'Send'}
          </Button>
        </Box>

        <Box sx={{ mt: 3, p: 2, bgcolor: '#e8f5e9', borderRadius: 1 }}>
          <Typography variant="caption" display="block">
            <strong>Intra-Bank Transfer:</strong> Both parties must use the same bank's tokens. Settlement is instant on-chain without intermediaries.
          </Typography>
        </Box>
      </TabPanel>

      <TabPanel value={tabValue} index={1}>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
          Transfer consortium stablecoins (CS) for cross-bank settlement. Works 24/7 regardless of recipient's bank.
        </Typography>

        <Box component="form" onSubmit={handleInterBankTransfer}>
          <FormControl fullWidth sx={{ mb: 2 }}>
            <InputLabel>Recipient</InputLabel>
            <Select
              value={toAddress}
              label="Recipient"
              onChange={(e) => setToAddress(e.target.value)}
            >
              {ACCOUNTS.filter(acc => acc.address !== account.address).map(acc => (
                <MenuItem key={acc.address} value={acc.address}>
                  {acc.name} ({acc.address.substring(0, 6)}...{acc.address.substring(38)})
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          <TextField
            fullWidth
            label="Amount (CS)"
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            sx={{ mb: 2 }}
            inputProps={{ step: '0.01', min: '0' }}
          />

          <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 2 }}>
            💡 Daily Transfer Cap: $100,000 | Per Transaction: $10,000
          </Typography>

          {success && <Alert severity="success" sx={{ mb: 2 }}>{success}</Alert>}
          {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

          <Button
            type="submit"
            variant="contained"
            fullWidth
            startIcon={loading ? <CircularProgress size={20} /> : <SendIcon />}
            disabled={loading}
          >
            {loading ? 'Processing...' : 'Send CS'}
          </Button>
        </Box>

        <Box sx={{ mt: 3, p: 2, bgcolor: '#fce4ec', borderRadius: 1 }}>
          <Typography variant="caption" display="block">
            <strong>Inter-Bank Transfer:</strong> Uses CS as universal settlement layer. Recipient can convert CS to their bank's deposit tokens (Flow 3).
          </Typography>
        </Box>
      </TabPanel>
    </Paper>
  );
}

export default TransferFlowDemo;
