import React, { useState } from 'react';
import {
  Box,
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Alert,
  CircularProgress,
  Typography,
  Paper,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import axios from 'axios';
import { getBalances, updateBalance } from './BalanceViewDemo';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8080';

function DepositFlowDemo({ account }) {
  const [bank, setBank] = useState('bankA');
  const [amount, setAmount] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  const handleDeposit = async (e) => {
    e.preventDefault();
    setSuccess('');
    setError('');

    if (!amount || parseFloat(amount) <= 0) {
      setError('Please enter a valid amount');
      return;
    }

    if (parseFloat(amount) > 10000) {
      setError('Exceeds per-transaction limit of $10,000');
      return;
    }

    try {
      setLoading(true);
      
      // Simulate blockchain transaction
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Generate transaction hash
      const txHash = '0x' + Math.random().toString(16).substr(2, 40);
      
      // Update balance
      const currentBalances = getBalances(account.address);
      const newBalance = currentBalances[bank] + parseFloat(amount);
      updateBalance(account.address, bank, newBalance);
      
      // ✅ SEND EVENT TO BACKEND
      try {
        await axios.post(`${API_URL}/api/events/deposit`, {
          txHash: txHash,
          userAddress: account.address,
          bank: bank === 'bankA' ? 'A' : 'B',
          amount: parseFloat(amount)
        });
        console.log('✅ Deposit event sent to backend');
      } catch (backendError) {
        console.error('Failed to record event in backend:', backendError);
      }
      
      setSuccess(`✅ Deposit successful! Minted ${amount} ${bank === 'bankA' ? 'DA' : 'DB'} tokens. TX: ${txHash.substring(0, 10)}...`);
      setAmount('');
    } catch (err) {
      setError(err.message || 'Transaction failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Paper sx={{ p: 3 }}>
      <Typography variant="h6" gutterBottom>
        Flow 1: Deposit → Tokenized Deposit
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Deposit cash to receive bank deposit tokens (DA or DB) with 1:1 backing
      </Typography>

      <Box component="form" onSubmit={handleDeposit}>
        <FormControl fullWidth sx={{ mb: 2 }}>
          <InputLabel>Select Bank</InputLabel>
          <Select
            value={bank}
            label="Select Bank"
            onChange={(e) => setBank(e.target.value)}
          >
            <MenuItem value="bankA">Bank A (Receive DA tokens)</MenuItem>
            <MenuItem value="bankB">Bank B (Receive DB tokens)</MenuItem>
          </Select>
        </FormControl>

        <TextField
          fullWidth
          label="Amount (USD)"
          type="number"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          sx={{ mb: 2 }}
          inputProps={{ step: '0.01', min: '0' }}
        />

        <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 2 }}>
          💡 Daily Limit: $50,000 | Per Transaction: $10,000 | KYC Required
        </Typography>

        {success && <Alert severity="success" sx={{ mb: 2 }}>{success}</Alert>}
        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

        <Button
          type="submit"
          variant="contained"
          fullWidth
          startIcon={loading ? <CircularProgress size={20} /> : <AddIcon />}
          disabled={loading}
        >
          {loading ? 'Processing Transaction...' : 'Deposit & Mint Tokens'}
        </Button>
      </Box>

      <Box sx={{ mt: 3, p: 2, bgcolor: '#e3f2fd', borderRadius: 1 }}>
        <Typography variant="caption" display="block">
          <strong>How it works:</strong>
        </Typography>
        <Typography variant="caption" component="div">
          1. User deposits cash at bank (off-chain)<br/>
          2. Bank verifies KYC and checks limits<br/>
          3. Smart contract mints deposit tokens 1:1<br/>
          4. Tokens appear in user's wallet<br/>
          5. Bank reserves the cash off-chain<br/>
          <strong style={{color: '#1976d2'}}>6. Event sent to backend for transaction history ✅</strong>
        </Typography>
      </Box>
    </Paper>
  );
}

export default DepositFlowDemo;
