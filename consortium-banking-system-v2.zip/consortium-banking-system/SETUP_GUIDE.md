# Consortium Banking System - Setup Guide

Complete guide for setting up and running the full-stack application.

## 🎯 Overview

This is a complete blockchain-based banking system with:
- **Smart Contracts** (Solidity + Hardhat)
- **Frontend** (React + Material-UI)
- **Backend** (Java Spring Boot + PostgreSQL)

## 📋 Prerequisites

### Required Software
- Node.js v16 or higher
- Java 17 or higher
- PostgreSQL 14 or higher
- MetaMask browser extension
- Git

### Verify Installation
```bash
node --version  # Should be v16+
java --version  # Should be 17+
psql --version  # Should be 14+
```

## 🚀 Quick Start (Automated)

### 1. Clone/Extract the Project
```bash
cd consortium-banking-system
```

### 2. Make Scripts Executable
```bash
chmod +x install.sh start-all.sh stop-all.sh
```

### 3. Run Installation
```bash
./install.sh
```

### 4. Setup Database
```bash
# Start PostgreSQL
# On Mac: brew services start postgresql
# On Linux: sudo systemctl start postgresql

# Create database
psql -U postgres
CREATE DATABASE consortium_banking;
\q
```

### 5. Configure Backend
Edit `backend/src/main/resources/application.properties`:
```properties
spring.datasource.username=postgres
spring.datasource.password=your_password
```

### 6. Start All Services
```bash
./start-all.sh
```

### 7. Access the Application
- Frontend: http://localhost:3000
- Backend API: http://localhost:8080
- Blockchain RPC: http://localhost:8545

## 🔧 Manual Setup (Step by Step)

### Smart Contracts Setup

```bash
cd contracts
npm install
npx hardhat compile

# Terminal 1: Start local blockchain
npx hardhat node

# Terminal 2: Deploy contracts
npx hardhat run scripts/deploy.js --network localhost
```

Save the deployed contract addresses from the output.

### Frontend Setup

```bash
cd frontend
npm install

# Create .env file
cp .env.example .env

# Edit .env with your contract addresses
nano .env
```

Update `.env`:
```
REACT_APP_KYC_ADDRESS=<from deployment>
REACT_APP_BANK_A_ADDRESS=<from deployment>
REACT_APP_BANK_B_ADDRESS=<from deployment>
REACT_APP_CONSORTIUM_ADDRESS=<from deployment>
```

Start frontend:
```bash
npm run start
```

### Backend Setup

```bash
cd backend
chmod +x mvnw

# Build
./mvnw clean install

# Run
./mvnw spring-boot:run
```

After tables are created, run database views:
```bash
psql -U postgres -d consortium_banking -f src/main/resources/database-views.sql
```

## 🧪 Testing

### Smart Contracts
```bash
cd contracts
npx hardhat test
```

### Frontend
```bash
cd frontend
npm test
```

### Backend
```bash
cd backend
./mvnw test
```

## 📱 Using the Application

### 1. Connect MetaMask
- Click "Connect Wallet" in the top right
- Approve the connection
- Make sure you're on the Localhost network (Chain ID: 1337)

### 2. Get Test Accounts
Hardhat provides 10 test accounts with 10,000 ETH each. The deployment script sets up:
- Alice: Has 10,000 DA tokens
- Bob: Has 10,000 DB tokens
- Carol, Dave: KYC approved but no initial balance

### 3. Import Account to MetaMask
1. Copy private key from Hardhat node output
2. MetaMask → Import Account → Private Key
3. Paste the private key

### 4. Try the Flows

#### Flow 1: Deposit
1. Go to "Deposit" tab
2. Select a bank (A or B)
3. Enter amount (max 10,000 per transaction)
4. Click "Deposit"

#### Flow 2: Convert to Consortium
1. Go to "Convert" tab
2. Select token type (DA or DB)
3. Enter amount
4. Click "Convert to CS"

#### Flow 4: Intra-Bank Transfer
1. Go to "Transfer" tab → "Intra-Bank"
2. Select bank
3. Enter recipient address
4. Enter amount
5. Click "Send"

#### Flow 5: Inter-Bank Transfer
1. Go to "Transfer" tab → "Inter-Bank"
2. Enter recipient address
3. Enter amount (in CS)
4. Click "Send CS"

## 🔍 Troubleshooting

### MetaMask Issues
- **Wrong network**: Switch to Localhost (http://127.0.0.1:8545, Chain ID: 1337)
- **Transaction rejected**: Check gas limits in MetaMask
- **Nonce too high**: Reset account in MetaMask → Settings → Advanced → Reset Account

### Database Issues
```bash
# Check if PostgreSQL is running
ps aux | grep postgres

# Check if database exists
psql -U postgres -l | grep consortium_banking

# Recreate database
psql -U postgres
DROP DATABASE consortium_banking;
CREATE DATABASE consortium_banking;
\q
```

### Port Conflicts
```bash
# Check what's using a port
lsof -i :8545  # Hardhat
lsof -i :3000  # Frontend
lsof -i :8080  # Backend

# Kill a process
kill -9 <PID>
```

### Contract Deployment Issues
```bash
# Clean and redeploy
cd contracts
rm -rf artifacts cache
npx hardhat clean
npx hardhat compile
npx hardhat run scripts/deploy.js --network localhost
```

## 📊 Monitoring

### View Logs
```bash
# Hardhat
tail -f logs/hardhat.log

# Backend
tail -f logs/backend.log

# Frontend (in terminal where it's running)
```

### Database Queries
```bash
psql -U postgres -d consortium_banking

# View transaction summary
SELECT * FROM user_transaction_summary;

# View daily volume
SELECT * FROM daily_transaction_volume;

# View token distribution
SELECT * FROM token_distribution;
```

## 🛑 Stopping Services

```bash
./stop-all.sh
```

Or manually:
```bash
# Stop Hardhat: Ctrl+C in terminal
# Stop Frontend: Ctrl+C in terminal
# Stop Backend: Ctrl+C in terminal
```

## 📚 Additional Resources

- [Hardhat Documentation](https://hardhat.org/docs)
- [React Documentation](https://react.dev)
- [Spring Boot Documentation](https://spring.io/projects/spring-boot)
- [PostgreSQL Documentation](https://www.postgresql.org/docs/)
- [MetaMask Documentation](https://docs.metamask.io)

## 🆘 Support

If you encounter issues:
1. Check the logs in `./logs/` directory
2. Verify all prerequisites are installed
3. Ensure all ports (8545, 3000, 8080) are available
4. Try the manual setup steps
5. Check that PostgreSQL is running and accessible

## 📄 License

MIT License - See LICENSE file for details
