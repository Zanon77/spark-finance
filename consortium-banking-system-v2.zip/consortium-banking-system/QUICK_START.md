# 🚀 QUICK START GUIDE - No MetaMask, No PostgreSQL

## What You Need
- Node.js 16+
- Java 17+
- That's it!

## Setup Steps (5 Minutes)

### 1. Extract the Project
```bash
cd ~/Downloads
unzip consortium-banking-system.zip
cd consortium-banking-system
```

### 2. Install Dependencies

**Smart Contracts:**
```bash
cd contracts
npm install
cd ..
```

**Frontend:**
```bash
cd frontend
npm install
cd ..
```

**Backend:**
```bash
cd backend
chmod +x mvnw
./mvnw clean install -DskipTests
cd ..
```

### 3. Start the Application

Open **3 separate terminals**:

**Terminal 1 - Blockchain (Hardhat):**
```bash
cd contracts
npx hardhat node
```
Leave this running. You'll see test accounts with addresses.

**Terminal 2 - Backend (Java):**
```bash
cd backend
./mvnw spring-boot:run
```
Wait until you see "Started BankingApplication"

**Terminal 3 - Frontend (React):**
```bash
cd frontend
npm start
```
Your browser will open automatically at http://localhost:3000

## ✅ What to Expect

### Frontend (http://localhost:3000)
- **No MetaMask required!** 
- Select from 4 demo accounts: Alice, Bob, Carol, Dave
- All transactions simulated locally
- Real-time balance updates

### Backend (http://localhost:8080)
- Using H2 in-memory database (no setup needed)
- View database at: http://localhost:8080/h2-console
  - JDBC URL: `jdbc:h2:mem:consortium_banking`
  - Username: `sa`
  - Password: (leave empty)

### Smart Contracts (http://localhost:8545)
- Local blockchain running
- Contracts deployed automatically
- Test accounts pre-funded

## 🎯 Try the 5 Flows

### Flow 1: Deposit
1. Select "Alice" account
2. Go to "Flow 1: Deposit" tab
3. Select "Bank A"
4. Enter amount (e.g., 1000)
5. Click "Deposit & Mint Tokens"
6. Watch balance update!

### Flow 2: Convert to CS
1. Go to "Flow 2: Convert" tab
2. Select "DA" token
3. Enter amount (e.g., 500)
4. Click "Convert DA to CS"
5. See CS balance increase!

### Flow 4: Intra-Bank Transfer
1. Go to "Transfer" tab → "Flow 4: Intra-Bank"
2. Select "Bank A"
3. Choose recipient (e.g., Carol)
4. Enter amount
5. Click "Send"

### Flow 5: Inter-Bank Transfer
1. Go to "Transfer" tab → "Flow 5: Inter-Bank"
2. Choose recipient (e.g., Bob)
3. Enter CS amount
4. Click "Send CS"

## 🔍 Understanding the Demo

### Demo Accounts (Hardhat Test Accounts)
- **Alice**: Bank A customer, starts with 10,000 DA
- **Bob**: Bank B customer, starts with 10,000 DB
- **Carol**: Bank A customer, starts with 0
- **Dave**: Bank A customer, starts with 0

### How It Works
1. **Frontend**: Simulates blockchain transactions locally
2. **Smart Contracts**: Run on Hardhat local blockchain
3. **Backend**: H2 database stores transaction history
4. **No External Services**: Everything runs on your machine

## 🛑 Stop the Application

Press `Ctrl+C` in each of the 3 terminals.

## 📊 View the Database

While the backend is running:
1. Open: http://localhost:8080/h2-console
2. Use JDBC URL: `jdbc:h2:mem:consortium_banking`
3. Username: `sa`, Password: (empty)
4. Click "Connect"
5. Run SQL queries:
   ```sql
   SELECT * FROM users;
   SELECT * FROM transactions;
   ```

## 🎓 Key Technologies

- **Frontend**: React 18 + Material-UI (no Web3 wallet needed)
- **Backend**: Spring Boot 3 + H2 Database
- **Blockchain**: Hardhat + Solidity (local testnet)

## ❓ Troubleshooting

### Port Already in Use
```bash
# Kill process on port 3000
lsof -ti:3000 | xargs kill -9

# Kill process on port 8080
lsof -ti:8080 | xargs kill -9

# Kill process on port 8545
lsof -ti:8545 | xargs kill -9
```

### Frontend Won't Start
```bash
cd frontend
rm -rf node_modules package-lock.json
npm install
npm start
```

### Backend Won't Start
```bash
cd backend
./mvnw clean install -DskipTests
./mvnw spring-boot:run
```

### Hardhat Won't Start
```bash
cd contracts
rm -rf node_modules package-lock.json cache artifacts
npm install
npx hardhat node
```

## 🎉 Success Indicators

✅ Hardhat shows "Started HTTP and WebSocket JSON-RPC server"
✅ Backend shows "Started BankingApplication in X seconds"
✅ Frontend opens in browser showing "Consortium Banking System (Demo Mode)"
✅ You can select accounts and see balances
✅ Transactions work and balances update

## 📝 Notes

- **Database**: Resets on every backend restart (in-memory)
- **Balances**: Stored in browser memory (resets on page refresh)
- **Blockchain**: Local only, no real money involved
- **MetaMask**: Not required for demo mode

## 🚀 Next Steps

Once you understand the flows:
1. Check `contracts/contracts/` for Solidity code
2. Review `frontend/src/components/` for UI components
3. Explore `backend/src/main/java/` for API code
4. Deploy to testnets (Sepolia, Goerli)
5. Add real Web3 wallet integration

---

**That's it! No database setup, no MetaMask, just pure demo functionality.** 🎊
