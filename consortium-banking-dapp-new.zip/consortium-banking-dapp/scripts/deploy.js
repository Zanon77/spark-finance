const hre = require("hardhat");

async function main() {
  console.log("Deploying Consortium Banking System...");

  // Deploy DepositTokenA
  const DepositTokenA = await hre.ethers.getContractFactory("DepositTokenA");
  const depositTokenA = await DepositTokenA.deploy();
  await depositTokenA.waitForDeployment();
  const depositTokenAAddress = await depositTokenA.getAddress();
  console.log("DepositTokenA deployed to:", depositTokenAAddress);

  // Deploy DepositTokenB
  const DepositTokenB = await hre.ethers.getContractFactory("DepositTokenB");
  const depositTokenB = await DepositTokenB.deploy();
  await depositTokenB.waitForDeployment();
  const depositTokenBAddress = await depositTokenB.getAddress();
  console.log("DepositTokenB deployed to:", depositTokenBAddress);

  // Deploy ConsortiumStablecoin
  const ConsortiumStablecoin = await hre.ethers.getContractFactory("ConsortiumStablecoin");
  const consortium = await ConsortiumStablecoin.deploy();
  await consortium.waitForDeployment();
  const consortiumAddress = await consortium.getAddress();
  console.log("ConsortiumStablecoin deployed to:", consortiumAddress);

  // Setup connections
  await depositTokenA.setConsortiumAddress(consortiumAddress);
  await depositTokenB.setConsortiumAddress(consortiumAddress);
  await consortium.setDepositTokens(depositTokenAAddress, depositTokenBAddress);

  console.log("\nContracts linked successfully!");

  // Get signers
  const [owner, alice, bob, carol, dave] = await hre.ethers.getSigners();

  // KYC disabled: skipping on-chain approvals for test users
  /*
  await depositTokenA.approveKYC(alice.address);
  await depositTokenA.approveKYC(carol.address);
  await depositTokenA.approveKYC(dave.address);
  
  await depositTokenB.approveKYC(bob.address);
  await depositTokenB.approveKYC(dave.address);

  console.log("\nKYC approved for test users:");
  console.log("Alice (BankA):", alice.address);
  console.log("Bob (BankB):", bob.address);
  console.log("Carol (BankA):", carol.address);
  console.log("Dave (Both):", dave.address);
  */

  // Save deployment addresses
  const fs = require("fs");
  const deploymentInfo = {
    network: hre.network.name,
    contracts: {
      DepositTokenA: depositTokenAAddress,
      DepositTokenB: depositTokenBAddress,
      ConsortiumStablecoin: consortiumAddress
    },
    testAccounts: {
      alice: alice.address,
      bob: bob.address,
      carol: carol.address,
      dave: dave.address
    }
  };

  fs.writeFileSync(
    "./deployment.json",
    JSON.stringify(deploymentInfo, null, 2)
  );
  
  console.log("\nDeployment info saved to deployment.json");

  // Try to copy deployment.json to frontend public folder for the UI
  try {
    const destPath = "./frontend/public/deployment.json";
    fs.copyFileSync("./deployment.json", destPath);
    console.log(`Copied deployment.json to ${destPath}`);
  } catch (copyErr) {
    console.warn("Could not copy deployment.json to frontend/public:", copyErr.message);
  }
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
