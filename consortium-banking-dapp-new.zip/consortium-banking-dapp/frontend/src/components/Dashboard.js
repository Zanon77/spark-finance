import React, { useState, useEffect } from 'react';
import { ethers } from 'ethers';
import { BlockchainService } from '../services/BlockchainService';
import './Dashboard.css';

function Dashboard({ user, blockchainService, signer }) {
  const [balances, setBalances] = useState({
    depositToken: '0',
    consortium: '0',
    usd: '0'
  });
  const [reserves, setReserves] = useState({ reserveA: '0', reserveB: '0', total: '0' });
  const [loading, setLoading] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);
  
  // Form states
  const [depositAmount, setDepositAmount] = useState('');
  const [convertAmount, setConvertAmount] = useState('');
  const [transferAmount, setTransferAmount] = useState('');
  const [transferTo, setTransferTo] = useState('');
  const [interBankAmount, setInterBankAmount] = useState('');
  const [interBankTo, setInterBankTo] = useState('');
  // Admin form
  const [adminAddress, setAdminAddress] = useState('');
  const [adminBank, setAdminBank] = useState('BankA');

  useEffect(() => {
    if (user) {
      loadBalances();
      loadReserves();

      // Poll for updates every 5 seconds
      const interval = setInterval(() => {
        loadBalances();
        loadReserves();
      }, 5000);

      return () => clearInterval(interval);
    }
  }, [blockchainService, user]);

  const loadBalances = async () => {
    try {
      const address = await signer.getAddress();
      let tokenBal = '0';
      let csBal = '0';

      if (blockchainService) {
        const tokenBalance = await blockchainService.getDepositTokenBalance(user.bank, address);
        const csBalance = await blockchainService.getConsortiumBalance(address);
        tokenBal = ethers.formatEther(tokenBalance);
        csBal = ethers.formatEther(csBalance);
      }

      // Get USD balance from backend
      const usdResponse = await fetch(`http://localhost:8080/api/balance/${user.username}`);
      const usdData = await usdResponse.json();

      setBalances({
        depositToken: tokenBal,
        consortium: csBal,
        usd: usdData.balance || '0'
      });
    } catch (error) {
      console.error('Error loading balances:', error);
    }
  };

  const loadReserves = async () => {
    try {
      if (!blockchainService) {
        setReserves({ reserveA: '0', reserveB: '0', total: '0' });
        return;
      }
      const reserveData = await blockchainService.getReserves();
      setReserves(reserveData);
    } catch (error) {
      console.error('Error loading reserves:', error);
    }
  };

  const handleDeposit = async (e) => {
    e.preventDefault();
    if (!blockchainService) {
      alert('Blockchain is not available. Start the local node to perform deposits.');
      return;
    }

    setActionLoading(true);

    try {
      const amount = ethers.parseEther(depositAmount);
      const tx = await blockchainService.deposit(user.bank, amount);

      alert(`Deposit successful! Transaction: ${tx.hash}`);

      // Update USD balance in backend
      await fetch('http://localhost:8080/api/balance/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: user.username,
          amount: -parseFloat(depositAmount)
        })
      });

      setDepositAmount('');
      await loadBalances();
    } catch (error) {
      alert('Deposit failed: ' + (error?.message || error));
      console.error(error);
    } finally {
      setActionLoading(false);
    }
  };

  const handleConvertToConsortium = async (e) => {
    e.preventDefault();
    if (!blockchainService) {
      alert('Blockchain is not available. Start the local node to perform conversions.');
      return;
    }

    setActionLoading(true);

    try {
      const amount = ethers.parseEther(convertAmount);
      const tx = await blockchainService.convertToConsortium(user.bank, amount);

      alert(`Conversion successful! Transaction: ${tx.hash}`);
      setConvertAmount('');
      await loadBalances();
      await loadReserves();
    } catch (error) {
      alert('Conversion failed: ' + (error?.message || error));
      console.error(error);
    } finally {
      setActionLoading(false);
    }
  };

  const handleConvertFromConsortium = async (e) => {
    e.preventDefault();
    if (!blockchainService) {
      alert('Blockchain is not available. Start the local node to perform conversions.');
      return;
    }

    setActionLoading(true);

    try {
      const amount = ethers.parseEther(convertAmount);
      const tx = await blockchainService.convertFromConsortium(user.bank, amount);

      alert(`Conversion successful! Transaction: ${tx.hash}`);
      setConvertAmount('');
      await loadBalances();
      await loadReserves();
    } catch (error) {
      alert('Conversion failed: ' + (error?.message || error));
      console.error(error);
    } finally {
      setActionLoading(false);
    }
  };

  const handleIntraBankTransfer = async (e) => {
    e.preventDefault();
    if (!blockchainService) {
      alert('Blockchain is not available. Start the local node to perform transfers.');
      return;
    }

    setActionLoading(true);
    
    try {
      const amount = ethers.parseEther(transferAmount);
      const tx = await blockchainService.intraBankTransfer(user.bank, transferTo, amount);
      
      alert(`Transfer successful! Transaction: ${tx.hash}`);
      setTransferAmount('');
      setTransferTo('');
      await loadBalances();
    } catch (error) {
      alert('Transfer failed: ' + (error?.message || error));
      console.error(error);
    } finally {
      setActionLoading(false);
    }
  };

  const handleInterBankTransfer = async (e) => {
    e.preventDefault();
    if (!blockchainService) {
      alert('Blockchain is not available. Start the local node to perform inter-bank transfers.');
      return;
    }

    setActionLoading(true);
    
    try {
      const targetBank = user.bank === 'BankA' ? 'BankB' : 'BankA';
      const amount = ethers.parseEther(interBankAmount);
      const tx = await blockchainService.interBankTransfer(user.bank, targetBank, interBankTo, amount);
      
      alert(`Inter-bank transfer successful! Transaction: ${tx.hash}`);
      setInterBankAmount('');
      setInterBankTo('');
      await loadBalances();
      await loadReserves();
    } catch (error) {
      alert('Inter-bank transfer failed: ' + (error?.message || error));
      console.error(error);
    } finally {
      setActionLoading(false);
    }
  };

  // KYC disabled: approval UI and client flows removed/disabled
  /*
  const handleApproveKYC = async (e) => {
    e.preventDefault();
    if (!blockchainService) {
      alert('Blockchain is not available. Start the local node and log in as an admin to approve KYC.');
      return;
    }

    setActionLoading(true);
    try {
      const tx = await blockchainService.approveKYC(adminBank, adminAddress);
      alert(`KYC approved! Transaction: ${tx.hash}`);
      setAdminAddress('');
    } catch (error) {
      alert('Approve KYC failed: ' + (error?.message || error));
      console.error(error);
    } finally {
      setActionLoading(false);
    }
  };

  const handleApproveAllKYC = async () => {
    if (!blockchainService) {
      alert('Blockchain is not available. Start the local node and log in as admin to approve KYC.');
      return;
    }

    setActionLoading(true);
    try {
      await blockchainService.approveAllKYC();
      alert('KYC approved for all test users (where applicable).');
    } catch (error) {
      alert('Approve all KYC failed: ' + (error?.message || error));
      console.error(error);
    } finally {
      setActionLoading(false);
    }
  };

  // Non-admin: request KYC approval by supplying admin credentials
  const handleRequestKYC = async () => {
    if (!signer || !signer.provider) {
      alert('Start the local node and ensure you are connected before requesting KYC.');
      return;
    }

    const adminKey = window.prompt('Enter admin (owner) private key to perform KYC approval (keeps key local):');
    if (!adminKey) return;

    // Basic check for private key format
    if (!adminKey.startsWith('0x') || (adminKey.length !== 66 && adminKey.length !== 64)) {
      if (!window.confirm('The provided key does not look like a valid private key. Proceed anyway?')) return;
    }

    const addressToApprove = window.prompt('Address to approve (leave empty to approve your address):', user.address || '');
    if (!addressToApprove) return;

    const bankChoice = window.prompt('Bank to approve for (BankA or BankB):', user.bank || 'BankA');
    if (!bankChoice) return;

    setActionLoading(true);
    try {
      const adminWallet = new ethers.Wallet(adminKey, signer.provider);

      // Ask the user to confirm admin wallet address to avoid wrong-key mistakes
      const confirmed = window.confirm(`Using admin address ${adminWallet.address} to approve KYC. Proceed?`);
      if (!confirmed) {
        setActionLoading(false);
        return;
      }

      const adminService = new BlockchainService(adminWallet);
      const initialized = await adminService.initialize();
      if (!initialized) {
        alert('Failed to initialize blockchain service with admin key (check deployment.json).');
        setActionLoading(false);
        return;
      }

      const tx = await adminService.approveKYC(bankChoice, addressToApprove);
      alert('KYC approved! Transaction: ' + (tx.hash || 'n/a'));
    } catch (err) {
      // Friendly error parsing
      const errMsg = err?.reason || err?.data?.message || err?.error?.message || err?.message || String(err);
      alert('KYC approval request failed: ' + errMsg);
      console.error('KYC approval failed:', err);
    } finally {
      setActionLoading(false);
    }
  };
  */

  return (
    <div className="dashboard">
      <h2>Dashboard - {user.bank}</h2>
      {!blockchainService && (
        <div className="offline-banner">⚠️ Blockchain offline — on-chain operations are disabled. Start the Hardhat node to enable them.</div>
      )}
      
      {/* Balances Card */}
      <div className="card balances-card">
        <h3>Your Balances</h3>
        <div className="balance-grid">
          <div className="balance-item">
            <label>USD (Off-Ledger)</label>
            <span className="balance-value">${balances.usd}</span>
          </div>
          <div className="balance-item">
            <label>{user.bank === 'BankA' ? 'DA' : 'DB'} (Deposit Token)</label>
            <span className="balance-value">{parseFloat(balances.depositToken).toFixed(4)}</span>
          </div>
          <div className="balance-item">
            <label>CS (Consortium)</label>
            <span className="balance-value">{parseFloat(balances.consortium).toFixed(4)}</span>
          </div>
        </div>
      </div>

      {/* Reserves Card */}
      <div className="card reserves-card">
        <h3>Consortium Reserves</h3>
        <div className="reserve-grid">
          <div className="reserve-item">
            <label>Bank A Reserve</label>
            <span>{reserves.reserveA}</span>
          </div>
          <div className="reserve-item">
            <label>Bank B Reserve</label>
            <span>{reserves.reserveB}</span>
          </div>
          <div className="reserve-item total">
            <label>Total Reserve</label>
            <span>{reserves.total}</span>
          </div>
        </div>
      </div>

      {/* Operations */}
      <div className="operations-grid">
        {/* Deposit */}
        <div className="card operation-card">
          <h3>1. Deposit USD</h3>
          <p className="description">Convert off-ledger USD to on-ledger deposit tokens</p>
          <form onSubmit={handleDeposit}>
            <input
              type="number"
              step="0.01"
              placeholder="Amount (USD)"
              value={depositAmount}
              onChange={(e) => setDepositAmount(e.target.value)}
              required
            />
            <button type="submit" disabled={!blockchainService || actionLoading}>
              {actionLoading ? 'Processing...' : 'Deposit'}
            </button>
          </form>
        </div>

        {/* Convert to Consortium */}
        <div className="card operation-card">
          <h3>2. Convert to Consortium</h3>
          <p className="description">Convert deposit tokens to consortium stablecoin</p>
          <form onSubmit={handleConvertToConsortium}>
            <input
              type="number"
              step="0.01"
              placeholder="Amount"
              value={convertAmount}
              onChange={(e) => setConvertAmount(e.target.value)}
              required
            />
            <button type="submit" disabled={!blockchainService || actionLoading}>
              {actionLoading ? 'Processing...' : `${user.bank === 'BankA' ? 'DA' : 'DB'} → CS`}
            </button>
          </form>
        </div>

        {/* Convert from Consortium */}
        <div className="card operation-card">
          <h3>3. Convert from Consortium</h3>
          <p className="description">Convert consortium stablecoin back to deposit tokens</p>
          <form onSubmit={handleConvertFromConsortium}>
            <input
              type="number"
              step="0.01"
              placeholder="Amount"
              value={convertAmount}
              onChange={(e) => setConvertAmount(e.target.value)}
              required
            />
            <button type="submit" disabled={!blockchainService || actionLoading}>
              {actionLoading ? 'Processing...' : `CS → ${user.bank === 'BankA' ? 'DA' : 'DB'}`}
            </button>
          </form>
        </div>

        {/* Intra-bank Transfer */}
        <div className="card operation-card">
          <h3>4. Intra-Bank Transfer</h3>
          <p className="description">Send deposit tokens to another {user.bank} customer</p>
          <form onSubmit={handleIntraBankTransfer}>
            <input
              type="text"
              placeholder="Recipient Address"
              value={transferTo}
              onChange={(e) => setTransferTo(e.target.value)}
              required
            />
            <input
              type="number"
              step="0.01"
              placeholder="Amount"
              value={transferAmount}
              onChange={(e) => setTransferAmount(e.target.value)}
              required
            />
            <button type="submit" disabled={!blockchainService || actionLoading}>
              {actionLoading ? 'Processing...' : 'Transfer'}
            </button>
          </form>
        </div>

        {/* Inter-bank Transfer */}
        <div className="card operation-card">
          <h3>5. Inter-Bank Transfer</h3>
          <p className="description">Send to {user.bank === 'BankA' ? 'Bank B' : 'Bank A'} customer via consortium</p>
          <form onSubmit={handleInterBankTransfer}>
            <input
              type="text"
              placeholder="Recipient Address"
              value={interBankTo}
              onChange={(e) => setInterBankTo(e.target.value)}
              required
            />
            <input
              type="number"
              step="0.01"
              placeholder="Amount"
              value={interBankAmount}
              onChange={(e) => setInterBankAmount(e.target.value)}
              required
            />
            <button type="submit" disabled={!blockchainService || actionLoading}>
              {actionLoading ? 'Processing...' : 'Send'}
            </button>
          </form>
        </div>
      </div>

      {/* KYC features disabled — KYC assumed approved for all users */}
      {false && user && user.username !== 'admin' && (
        <div className="card kyc-request-card">
          <h3>Request KYC Approval</h3>
          <p className="description">Provide admin credentials to approve KYC for an address (for demo only).</p>
          <div>
            <button disabled>
              {actionLoading ? 'Processing...' : 'Request Approve KYC (enter admin key)'}
            </button>
          </div>
        </div>
      )}

      {/* Admin Panel (owner only) - KYC disabled */}
      {false && user && user.username === 'admin' && (
        <div className="card admin-card">
          <h3>Admin: KYC Management</h3>
          <p className="description">KYC is disabled in this build; approvals are not necessary.</p>
        </div>
      )}
    </div>
  );
}

export default Dashboard;
