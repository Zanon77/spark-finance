import React, { useState } from 'react';
import axios from 'axios';
import './Login.css';

function Login({ onLogin }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      // Authenticate with backend
      const response = await axios.post('http://localhost:8080/api/auth/login', {
        username,
        password
      });

      if (response.data.success) {
        onLogin(response.data.user);
      } else {
        setError('Invalid credentials');
      }
    } catch (err) {
      setError('Login failed. Please check your credentials and try again.');
      console.error('Login error:', err);
    } finally {
      setLoading(false);
    }
  };

  const quickLogin = (user) => {
    setUsername(user);
    setPassword('password123');
  };

  return (
    <div className="login-container">
      <div className="login-box">
        <h2>Consortium Banking System</h2>
        <p className="subtitle">Blockchain-Powered Banking</p>
        
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Username</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Enter username"
              required
            />
          </div>
          
          <div className="form-group">
            <label>Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter password"
              required
            />
          </div>
          
          {error && <div className="error-message">{error}</div>}
          
          <button type="submit" className="login-btn" disabled={loading}>
            {loading ? 'Logging in...' : 'Login'}
          </button>
        </form>
        
        <div className="quick-login">
          <p>Quick Login (Demo Users):</p>
          <div className="demo-users">
            <button onClick={() => quickLogin('alice')} className="demo-btn">Alice (Bank A)</button>
            <button onClick={() => quickLogin('bob')} className="demo-btn">Bob (Bank B)</button>
            <button onClick={() => quickLogin('carol')} className="demo-btn">Carol (Bank A)</button>
            <button onClick={() => quickLogin('dave')} className="demo-btn">Dave (Both)</button>
          </div>
        </div>
        
        <div className="info-box">
          <p><strong>Important:</strong> Please ensure Hardhat node is running on localhost:8545</p>
          <p style={{marginTop: '8px', fontSize: '11px'}}>No wallet extension required - accounts are automatically managed!</p>
        </div>
      </div>
    </div>
  );
}

export default Login;
