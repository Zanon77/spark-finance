import { ethers } from 'ethers';
import DepositTokenA from '../artifacts/contracts/DepositTokenA/DepositTokenA.json';
import DepositTokenB from '../artifacts/contracts/DepositTokenB/DepositTokenB.json';
import ConsortiumStablecoin from '../artifacts/contracts/ConsortiumStablecoin/ConsortiumStablecoin.json';

export class BlockchainService {
  constructor(signer) {
    this.signer = signer;
    this.contracts = {};
    this.addresses = {};
  }

  async initialize() {
    this.initialized = false;
    try {
      // Load deployment addresses
      const response = await fetch('/deployment.json');
      if (!response.ok) {
        console.error('deployment.json not found (expected in frontend/public/).');
        return false;
      }

      const deployment = await response.json();
      if (!deployment || !deployment.contracts) {
        console.error('deployment.json does not include contracts.');
        return false;
      }

      this.addresses = deployment.contracts;
      // Save test accounts mapping if present so admin tooling can use it
      this.testAccounts = deployment.testAccounts || {};

      // Initialize contracts
      this.contracts.depositTokenA = new ethers.Contract(
        this.addresses.DepositTokenA,
        DepositTokenA.abi,
        this.signer
      );

      this.contracts.depositTokenB = new ethers.Contract(
        this.addresses.DepositTokenB,
        DepositTokenB.abi,
        this.signer
      );

      this.contracts.consortium = new ethers.Contract(
        this.addresses.ConsortiumStablecoin,
        ConsortiumStablecoin.abi,
        this.signer
      );

      this.initialized = true;
      console.log('Blockchain service initialized');
      return true;
    } catch (error) {
      console.error('Failed to initialize blockchain service:', error);
      return false;
    }
  }

  getDepositContract(bank) {
    return bank === 'BankA' ? this.contracts.depositTokenA : this.contracts.depositTokenB;
  }

  async getDepositTokenBalance(bank, address) {
    const contract = this.getDepositContract(bank);
    return await contract.balanceOf(address);
  }

  async getConsortiumBalance(address) {
    return await this.contracts.consortium.balanceOf(address);
  }

  async getReserves() {
    const [reserveA, reserveB] = await this.contracts.consortium.getReserves();
    const total = await this.contracts.consortium.getTotalReserve();
    
    return {
      reserveA: ethers.formatEther(reserveA),
      reserveB: ethers.formatEther(reserveB),
      total: ethers.formatEther(total)
    };
  }

  // KYC helpers - DISABLED: KYC checks are turned off and assumed approved
  async approveKYC(bank, address) {
    console.log('approveKYC called but KYC is disabled in this build; assuming approved.');
    return { hash: null };
  }

  async approveAllKYC() {
    console.log('approveAllKYC called but KYC is disabled in this build; no-op.');
    return [];
  }

  async isKycApproved(bank, address) {
    // KYC is disabled; assume approved
    return true;
  }

  async deposit(bank, amount) {
    const contract = this.getDepositContract(bank);
    const tx = await contract.deposit(amount);
    await tx.wait();
    return tx;
  }

  async convertToConsortium(bank, amount) {
    const contract = this.getDepositContract(bank);

    // Step 1: Burn deposit tokens — the deposit contract will call the consortium contract internally
    const burnTx = await contract.burnForConsortium(amount);
    await burnTx.wait();

    return burnTx;
  }

  async convertFromConsortium(bank, amount) {
    const burnMethod = bank === 'BankA' ? 'burnForBankA' : 'burnForBankB';

    // Step 1: Burn consortium tokens — the consortium contract will mint deposit tokens internally
    const burnTx = await this.contracts.consortium[burnMethod](amount);
    await burnTx.wait();

    return burnTx;
  }

  async intraBankTransfer(bank, toAddress, amount) {
    const contract = this.getDepositContract(bank);
    const tx = await contract.transferDeposit(toAddress, amount);
    await tx.wait();
    return tx;
  }

  async interBankTransfer(fromBank, toBank, toAddress, amount) {
    // Step 1: Convert to consortium
    await this.convertToConsortium(fromBank, amount);
    
    // Step 2: Convert from consortium to target bank's deposit token
    const burnMethod = toBank === 'BankA' ? 'burnForBankA' : 'burnForBankB';
    const burnTx = await this.contracts.consortium[burnMethod](amount);
    await burnTx.wait();
    
    // Step 3: Mint to recipient
    const targetContract = this.getDepositContract(toBank);
    const mintTx = await targetContract.mintFromConsortium(toAddress, amount);
    await mintTx.wait();
    
    return mintTx;
  }

  async getTransactionHistory(bank) {
    const contract = this.getDepositContract(bank);
    const consortium = this.contracts.consortium;
    const provider = this.signer.provider;
    
    const currentBlock = await provider.getBlockNumber();
    const fromBlock = Math.max(0, currentBlock - 10000); // Last ~10k blocks
    
    const transactions = [];

    // Get deposit events
    try {
      const depositFilter = contract.filters.DepositMinted();
      const depositEvents = await contract.queryFilter(depositFilter, fromBlock, currentBlock);
      
      for (const event of depositEvents) {
        const block = await event.getBlock();
        transactions.push({
          type: 'DepositMinted',
          user: event.args.user,
          amount: event.args.amount.toString(),
          transactionHash: event.transactionHash,
          blockNumber: event.blockNumber,
          timestamp: block.timestamp
        });
      }
    } catch (error) {
      console.error('Error fetching deposit events:', error);
    }

    // Get burn events
    try {
      const burnFilter = contract.filters.DepositBurned();
      const burnEvents = await contract.queryFilter(burnFilter, fromBlock, currentBlock);
      
      for (const event of burnEvents) {
        const block = await event.getBlock();
        transactions.push({
          type: 'DepositBurned',
          user: event.args.user,
          amount: event.args.amount.toString(),
          transactionHash: event.transactionHash,
          blockNumber: event.blockNumber,
          timestamp: block.timestamp
        });
      }
    } catch (error) {
      console.error('Error fetching burn events:', error);
    }

    // Get transfer events
    try {
      const transferFilter = contract.filters.DepositTransferred();
      const transferEvents = await contract.queryFilter(transferFilter, fromBlock, currentBlock);
      
      for (const event of transferEvents) {
        const block = await event.getBlock();
        transactions.push({
          type: 'DepositTransferred',
          from: event.args.from,
          to: event.args.to,
          amount: event.args.amount.toString(),
          transactionHash: event.transactionHash,
          blockNumber: event.blockNumber,
          timestamp: block.timestamp
        });
      }
    } catch (error) {
      console.error('Error fetching transfer events:', error);
    }

    // Get consortium events
    try {
      const consortiumMintFilter = consortium.filters.ConsortiumMinted();
      const consortiumMintEvents = await consortium.queryFilter(consortiumMintFilter, fromBlock, currentBlock);
      
      for (const event of consortiumMintEvents) {
        const block = await event.getBlock();
        transactions.push({
          type: 'ConsortiumMinted',
          user: event.args.user,
          amount: event.args.amount.toString(),
          bank: event.args.bank,
          transactionHash: event.transactionHash,
          blockNumber: event.blockNumber,
          timestamp: block.timestamp
        });
      }
    } catch (error) {
      console.error('Error fetching consortium mint events:', error);
    }

    // Get consortium burn events
    try {
      const consortiumBurnFilter = consortium.filters.ConsortiumBurned();
      const consortiumBurnEvents = await consortium.queryFilter(consortiumBurnFilter, fromBlock, currentBlock);
      
      for (const event of consortiumBurnEvents) {
        const block = await event.getBlock();
        transactions.push({
          type: 'ConsortiumBurned',
          user: event.args.user,
          amount: event.args.amount.toString(),
          transactionHash: event.transactionHash,
          blockNumber: event.blockNumber,
          timestamp: block.timestamp
        });
      }
    } catch (error) {
      console.error('Error fetching consortium burn events:', error);
    }

    // Sort by block number (newest first)
    transactions.sort((a, b) => b.blockNumber - a.blockNumber);
    
    return transactions;
  }
}
