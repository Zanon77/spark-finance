package com.consortium.banking.controller;

import com.consortium.banking.model.User;
import com.consortium.banking.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {
    
    @Autowired
    private UserService userService;
    
    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody Map<String, String> credentials) {
        String username = credentials.get("username");
        String password = credentials.get("password");
        
        User user = userService.authenticateUser(username, password);
        
        Map<String, Object> response = new HashMap<>();
        
        if (user != null) {
            Map<String, Object> userInfo = new HashMap<>();
            userInfo.put("username", user.getUsername());
            userInfo.put("bank", user.getBank());
            userInfo.put("fullName", user.getFullName());
            userInfo.put("email", user.getEmail());
            userInfo.put("kycApproved", user.isKycApproved());
            
            response.put("success", true);
            response.put("user", userInfo);
        } else {
            response.put("success", false);
            response.put("message", "Invalid credentials");
        }
        
        return ResponseEntity.ok(response);
    }
    
    @PostMapping("/register")
    public ResponseEntity<Map<String, Object>> register(@RequestBody User user) {
        Map<String, Object> response = new HashMap<>();
        
        User existingUser = userService.getUserByUsername(user.getUsername());
        if (existingUser != null) {
            response.put("success", false);
            response.put("message", "Username already exists");
            return ResponseEntity.ok(response);
        }
        
        User savedUser = userService.saveUser(user);
        response.put("success", true);
        response.put("message", "User registered successfully");
        
        return ResponseEntity.ok(response);
    }
}
