package com.consortium.banking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsortiumBankingApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(ConsortiumBankingApplication.class, args);
    }
}
