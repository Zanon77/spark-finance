package com.consortium.banking.service;

import com.consortium.banking.model.User;
import com.consortium.banking.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {
    
    @Autowired
    private UserRepository userRepository;
    
    public User authenticateUser(String username, String password) {
        Optional<User> user = userRepository.findByUsernameAndPassword(username, password);
        return user.orElse(null);
    }
    
    public User getUserByUsername(String username) {
        return userRepository.findByUsername(username).orElse(null);
    }
    
    public User saveUser(User user) {
        return userRepository.save(user);
    }
    
    public boolean updateBalance(String username, Double amount) {
        User user = getUserByUsername(username);
        if (user != null) {
            double newBalance = user.getUsdBalance() + amount;
            if (newBalance >= 0) {
                user.setUsdBalance(newBalance);
                userRepository.save(user);
                return true;
            }
        }
        return false;
    }
    
    public Double getBalance(String username) {
        User user = getUserByUsername(username);
        return user != null ? user.getUsdBalance() : 0.0;
    }
}
