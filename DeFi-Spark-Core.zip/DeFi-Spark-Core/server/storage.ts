import { users, transactions, type User, type InsertUser, type Transaction, type InsertTransaction } from "@shared/schema";
import { db } from "./db";
import { eq, or } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUsers(): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  
  createTransaction(tx: InsertTransaction): Promise<Transaction>;
  getTransactions(userId?: number): Promise<Transaction[]>;
  
  // Banking Helpers
  updateUserBalance(userId: number, amountChange: number): Promise<void>; // Simplified for DB-only tracking
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  async createTransaction(tx: InsertTransaction): Promise<Transaction> {
    const [newTx] = await db.insert(transactions).values(tx).returning();
    return newTx;
  }

  async getTransactions(userId?: number): Promise<Transaction[]> {
    if (userId) {
      return await db.select().from(transactions)
        .where(or(eq(transactions.fromUserId, userId), eq(transactions.toUserId, userId)))
        .orderBy(transactions.createdAt);
    }
    return await db.select().from(transactions).orderBy(transactions.createdAt);
  }

  async updateUserBalance(userId: number, amountChange: number): Promise<void> {
    // In a real DB-ledger, we'd have a balances table. 
    // For this prototype, we calculate balances from transactions on the fly or just log it.
    // The frontend will calculate balances by summing transactions for display.
    return;
  }
}

export const storage = new DatabaseStorage();
