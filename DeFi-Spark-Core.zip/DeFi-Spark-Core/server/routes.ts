import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api, buildUrl } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // === User Routes ===
  app.get(api.users.list.path, async (req, res) => {
    const users = await storage.getUsers();
    res.json(users);
  });

  app.get(api.users.get.path, async (req, res) => {
    const user = await storage.getUser(Number(req.params.id));
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    res.json(user);
  });

  // === Transaction Routes ===
  app.get(api.transactions.list.path, async (req, res) => {
    const txs = await storage.getTransactions();
    res.json(txs);
  });

  app.post(api.transactions.transfer.path, async (req, res) => {
    try {
      const input = api.transactions.transfer.input.parse(req.body);
      
      const fromUser = await storage.getUser(input.fromUserId);
      const toUser = await storage.getUser(input.toUserId);

      if (!fromUser || !toUser) {
        return res.status(400).json({ message: "Invalid users" });
      }

      // Determine Transfer Type
      const isIntraBank = fromUser.bank === toUser.bank;
      const type = isIntraBank ? "intra-bank" : "inter-bank";
      const tokenSymbol = fromUser.bank === "BankA" ? "DA" : "DB"; // Sender's token

      // Simulate Blockchain Logic Here
      // In a real app, this would call:
      // if (isIntraBank) BankContract.transfer(...)
      // else BankContract.burnForConsortium(...)

      // 1. Debit Sender (Burn/Transfer)
      const tx1 = await storage.createTransaction({
        fromUserId: fromUser.id,
        toUserId: toUser.id,
        amount: -input.amount,
        tokenSymbol: tokenSymbol,
        type: type,
        status: "completed",
        txHash: "0x" + Math.random().toString(16).slice(2)
      });

      // 2. Credit Recipient (Mint/Transfer)
      const recipientToken = toUser.bank === "BankA" ? "DA" : "DB";
      const tx2 = await storage.createTransaction({
        fromUserId: fromUser.id,
        toUserId: toUser.id,
        amount: input.amount,
        tokenSymbol: recipientToken,
        type: type,
        status: "completed",
        txHash: "0x" + Math.random().toString(16).slice(2)
      });

      res.json({ success: true, message: "Transfer successful", txHash: tx1.txHash });
    } catch (err) {
       if (err instanceof z.ZodError) {
          return res.status(400).json({
            message: err.errors[0].message,
            field: err.errors[0].path.join('.'),
          });
        }
        res.status(500).json({ message: "Internal server error" });
    }
  });

  // Seed Data
  const users = await storage.getUsers();
  if (users.length === 0) {
    console.log("Seeding users...");
    await storage.createUser({ name: "Alice", bank: "BankA", role: "client", walletAddress: "0xAlice" });
    await storage.createUser({ name: "Bob", bank: "BankB", role: "client", walletAddress: "0xBob" });
    await storage.createUser({ name: "Carol", bank: "BankA", role: "client", walletAddress: "0xCarol" });
    await storage.createUser({ name: "Dave", bank: "BankB", role: "client", walletAddress: "0xDave" });
    
    // Initial Balances (Minting)
    await storage.createTransaction({
      fromUserId: 0, // System
      toUserId: 1, // Alice
      amount: 4000,
      tokenSymbol: "DA",
      type: "mint",
      status: "completed"
    });
     await storage.createTransaction({
      fromUserId: 0, // System
      toUserId: 2, // Bob
      amount: 2500,
      tokenSymbol: "DB",
      type: "mint",
      status: "completed"
    });
  }

  return httpServer;
}
