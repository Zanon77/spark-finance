import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  bank: text("bank").notNull(), // 'BankA', 'BankB'
  role: text("role").notNull().default("client"), // 'client', 'admin'
  walletAddress: text("wallet_address"), // For on-chain mapping
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  fromUserId: integer("from_user_id").notNull(),
  toUserId: integer("to_user_id").notNull(),
  amount: integer("amount").notNull(),
  tokenSymbol: text("token_symbol").notNull(), // 'DA', 'DB', 'CS'
  type: text("type").notNull(), // 'intra-bank', 'inter-bank', 'mint', 'burn'
  status: text("status").notNull(), // 'pending', 'completed', 'failed'
  txHash: text("tx_hash"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export const insertTransactionSchema = createInsertSchema(transactions).omit({ id: true, createdAt: true });

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;

// API Types
export type TransferRequest = {
  fromUserId: number;
  toUserId: number;
  amount: number;
};
