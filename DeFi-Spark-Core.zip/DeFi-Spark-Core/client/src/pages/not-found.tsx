import { Link } from "wouter";
import { AlertCircle } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center bg-background text-foreground">
      <div className="w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center mb-6">
        <AlertCircle className="w-8 h-8 text-destructive" />
      </div>
      <h1 className="text-4xl font-display font-bold text-white mb-2">404 Page Not Found</h1>
      <p className="text-muted-foreground mb-8">The requested resource could not be found on the ledger.</p>
      
      <Link href="/" className="px-6 py-3 bg-primary text-primary-foreground font-semibold rounded-lg hover:bg-primary/90 transition-colors">
        Return to Dashboard
      </Link>
    </div>
  );
}
