import { useState } from "react";
import { UserSwitcher } from "@/components/UserSwitcher";
import { BalanceCard } from "@/components/BalanceCard";
import { TransactionList } from "@/components/TransactionList";
import { TransferForm } from "@/components/TransferForm";
import { useUser, useTransactions } from "@/hooks/use-spark";
import { LayoutDashboard, History, Activity, AlertCircle } from "lucide-react";
import { motion } from "framer-motion";

export default function Dashboard() {
  const [currentUserId, setCurrentUserId] = useState<number | null>(null);
  const { data: user, isLoading: userLoading } = useUser(currentUserId);
  const { data: transactions } = useTransactions();

  // Calculate dynamic balances from transaction history
  const calculateBalance = (userId: number | null, tokenSymbol: string) => {
    if (!userId || !transactions) return 0;
    
    // Initial Seed Balances (simulated)
    let balance = 1000; 

    transactions.forEach(tx => {
      if (tx.status !== 'completed' || tx.tokenSymbol !== tokenSymbol) return;
      if (tx.toUserId === userId) balance += tx.amount;
      if (tx.fromUserId === userId) balance -= tx.amount;
    });
    
    return balance;
  };

  const userToken = user?.bank === 'BankA' ? 'DA' : user?.bank === 'BankB' ? 'DB' : 'CS';
  const balance = calculateBalance(currentUserId, userToken);
  const stableBalance = calculateBalance(currentUserId, 'CS');

  return (
    <div className="min-h-screen bg-[#0B0E14] text-foreground font-body selection:bg-primary/20">
      {/* Navbar */}
      <header className="sticky top-0 z-50 border-b border-border/40 bg-background/80 backdrop-blur-md">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-blue-600 flex items-center justify-center shadow-lg shadow-blue-500/20">
              <Activity className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-xl font-display font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-white/70">
              Spark<span className="font-light">Finance</span>
            </h1>
          </div>
          <UserSwitcher currentUserId={currentUserId} onUserChange={setCurrentUserId} />
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 space-y-8">
        {!currentUserId ? (
          <div className="flex flex-col items-center justify-center h-[60vh] text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center animate-pulse">
              <LayoutDashboard className="w-8 h-8 text-primary" />
            </div>
            <h2 className="text-2xl font-bold font-display">Initializing Dashboard...</h2>
            <p className="text-muted-foreground">Connecting to Spark Settlement Network</p>
          </div>
        ) : (
          <>
            {/* Overview Section */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="grid grid-cols-1 md:grid-cols-3 gap-6"
            >
              <BalanceCard 
                label="Deposit Token Balance" 
                amount={balance} 
                symbol={userToken} 
                bank={user?.bank || 'Unknown'} 
                type={user?.bank === 'BankA' ? 'primary' : 'secondary'}
              />
              <BalanceCard 
                label="Consortium Stablecoin" 
                amount={stableBalance} 
                symbol="CS" 
                bank="Network Reserve" 
                type="neutral"
              />
              <div className="md:col-span-1 bg-gradient-to-br from-card to-card/50 border border-border/50 rounded-2xl p-6 flex flex-col justify-between">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-2">Network Status</h3>
                  <div className="flex items-center gap-2 text-emerald-400 text-sm font-medium">
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                    </span>
                    Block Height: #14,203,992
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t border-white/5">
                  <div className="flex justify-between text-xs text-muted-foreground mb-1">
                    <span>Gas Price</span>
                    <span className="text-foreground font-mono">12 Gwei</span>
                  </div>
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>TPS</span>
                    <span className="text-foreground font-mono">2,400</span>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Operations Section */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Transfer Form */}
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 }}
                className="lg:col-span-1"
              >
                <TransferForm currentUserId={currentUserId} userBalance={balance} />
              </motion.div>

              {/* Transaction History */}
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 }}
                className="lg:col-span-2 space-y-6"
              >
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-bold font-display flex items-center gap-2">
                    <History className="w-5 h-5 text-primary" />
                    Transaction History
                  </h2>
                  <div className="text-xs font-mono text-muted-foreground bg-white/5 px-2 py-1 rounded">
                    Live Feed
                  </div>
                </div>
                
                <div className="bg-card/30 backdrop-blur rounded-2xl border border-border/50 p-1 min-h-[400px]">
                  <TransactionList currentUserId={currentUserId} />
                </div>
              </motion.div>
            </div>
          </>
        )}
      </main>
    </div>
  );
}
