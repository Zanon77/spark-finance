import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type TransferRequest } from "@shared/routes";
import { z } from "zod";

// ============================================
// USERS
// ============================================

export function useUsers() {
  return useQuery({
    queryKey: [api.users.list.path],
    queryFn: async () => {
      const res = await fetch(api.users.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch users");
      return api.users.list.responses[200].parse(await res.json());
    },
  });
}

export function useUser(id: number | null) {
  return useQuery({
    queryKey: [api.users.get.path, id],
    enabled: !!id,
    queryFn: async () => {
      if (!id) return null;
      const url = api.users.get.path.replace(":id", id.toString());
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch user");
      return api.users.get.responses[200].parse(await res.json());
    },
  });
}

// ============================================
// TRANSACTIONS
// ============================================

export function useTransactions() {
  return useQuery({
    queryKey: [api.transactions.list.path],
    queryFn: async () => {
      const res = await fetch(api.transactions.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch transactions");
      return api.transactions.list.responses[200].parse(await res.json());
    },
    // Poll every 5 seconds to simulate real-time blockchain updates
    refetchInterval: 5000, 
  });
}

export function useTransfer() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: TransferRequest) => {
      const validated = api.transactions.transfer.input.parse(data);
      const res = await fetch(api.transactions.transfer.path, {
        method: api.transactions.transfer.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      
      const json = await res.json();
      
      if (!res.ok) {
        if (res.status === 400) {
          const error = api.transactions.transfer.responses[400].parse(json);
          throw new Error(error.message);
        }
        if (res.status === 500) {
           const error = api.transactions.transfer.responses[500].parse(json);
           throw new Error(error.message);
        }
        throw new Error("Transfer failed");
      }
      return api.transactions.transfer.responses[200].parse(json);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.transactions.list.path] });
    },
  });
}
