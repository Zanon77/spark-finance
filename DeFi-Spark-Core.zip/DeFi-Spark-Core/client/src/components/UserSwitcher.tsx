import { useUsers } from "@/hooks/use-spark";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { User, Building2, ShieldCheck, Wallet } from "lucide-react";
import { useEffect } from "react";

interface UserSwitcherProps {
  currentUserId: number | null;
  onUserChange: (id: number) => void;
}

export function UserSwitcher({ currentUserId, onUserChange }: UserSwitcherProps) {
  const { data: users, isLoading } = useUsers();

  // Auto-select first user if none selected
  useEffect(() => {
    if (users && users.length > 0 && !currentUserId) {
      onUserChange(users[0].id);
    }
  }, [users, currentUserId, onUserChange]);

  if (isLoading) {
    return (
      <div className="h-10 w-48 bg-white/5 animate-pulse rounded-lg border border-white/10" />
    );
  }

  return (
    <div className="flex items-center gap-3">
      <div className="hidden md:flex items-center gap-2 text-xs font-medium text-muted-foreground uppercase tracking-widest">
        <ShieldCheck className="w-3.5 h-3.5 text-primary" />
        <span>Simulating As</span>
      </div>
      <Select 
        value={currentUserId?.toString()} 
        onValueChange={(val) => onUserChange(Number(val))}
      >
        <SelectTrigger className="w-[240px] h-11 bg-card/50 backdrop-blur border-border/50 hover:border-primary/50 transition-colors">
          <SelectValue placeholder="Select a user entity..." />
        </SelectTrigger>
        <SelectContent>
          {users?.map((user) => (
            <SelectItem key={user.id} value={user.id.toString()} className="py-3">
              <div className="flex items-center justify-between w-full gap-4">
                <div className="flex items-center gap-3">
                  <div className={`
                    w-8 h-8 rounded-full flex items-center justify-center
                    ${user.bank === 'BankA' ? 'bg-blue-500/20 text-blue-400' : 
                      user.bank === 'BankB' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-purple-500/20 text-purple-400'}
                  `}>
                    <User className="w-4 h-4" />
                  </div>
                  <div className="flex flex-col text-left">
                    <span className="font-semibold text-foreground">{user.name}</span>
                    <span className="text-xs text-muted-foreground font-mono">{user.role}</span>
                  </div>
                </div>
                <div className={`
                  text-[10px] font-bold px-2 py-0.5 rounded border uppercase tracking-wider
                  ${user.bank === 'BankA' ? 'bg-blue-950/30 text-blue-400 border-blue-500/20' : 
                    user.bank === 'BankB' ? 'bg-emerald-950/30 text-emerald-400 border-emerald-500/20' : 'bg-purple-950/30 text-purple-400 border-purple-500/20'}
                `}>
                  {user.bank}
                </div>
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
