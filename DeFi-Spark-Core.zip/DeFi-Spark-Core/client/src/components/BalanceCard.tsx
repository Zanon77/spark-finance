import { ArrowUpRight, ArrowDownLeft, TrendingUp } from "lucide-react";
import { motion } from "framer-motion";

interface BalanceCardProps {
  label: string;
  amount: number;
  symbol: string;
  bank: string;
  type: "primary" | "secondary" | "neutral";
}

export function BalanceCard({ label, amount, symbol, bank, type }: BalanceCardProps) {
  const gradients = {
    primary: "from-blue-500/20 to-cyan-500/5 border-blue-500/20",
    secondary: "from-emerald-500/20 to-teal-500/5 border-emerald-500/20",
    neutral: "from-purple-500/20 to-pink-500/5 border-purple-500/20",
  };

  const textColors = {
    primary: "text-blue-400",
    secondary: "text-emerald-400",
    neutral: "text-purple-400",
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className={`
        relative overflow-hidden rounded-2xl border p-6
        bg-gradient-to-br backdrop-blur-sm
        ${gradients[type]}
      `}
    >
      <div className="flex justify-between items-start mb-8">
        <div>
          <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-1">
            {label}
          </h3>
          <p className="text-xs font-mono opacity-60">{bank}</p>
        </div>
        <div className={`p-2 rounded-full bg-white/5 ${textColors[type]}`}>
          <TrendingUp className="w-5 h-5" />
        </div>
      </div>
      
      <div className="space-y-1">
        <h2 className="text-4xl font-display font-bold text-white tracking-tight">
          {amount.toLocaleString()} <span className="text-lg opacity-50 font-normal">{symbol}</span>
        </h2>
        <div className="flex items-center gap-2 text-xs font-mono text-muted-foreground">
          <span className="text-green-400 flex items-center gap-1">
            <ArrowUpRight className="w-3 h-3" /> +2.4%
          </span>
          <span className="opacity-40">vs last week</span>
        </div>
      </div>

      {/* Decorative background glow */}
      <div className={`absolute -bottom-12 -right-12 w-32 h-32 rounded-full blur-[60px] opacity-20 ${type === 'primary' ? 'bg-blue-500' : type === 'secondary' ? 'bg-emerald-500' : 'bg-purple-500'}`} />
    </motion.div>
  );
}
