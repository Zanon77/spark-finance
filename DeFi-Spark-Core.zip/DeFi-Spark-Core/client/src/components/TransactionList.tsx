import { useTransactions } from "@/hooks/use-spark";
import { format } from "date-fns";
import { ArrowRightLeft, ArrowUpRight, ArrowDownLeft, Activity, CheckCircle2, Clock, XCircle } from "lucide-react";
import { motion } from "framer-motion";

interface TransactionListProps {
  currentUserId: number | null;
}

export function TransactionList({ currentUserId }: TransactionListProps) {
  const { data: transactions, isLoading } = useTransactions();

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="h-20 w-full bg-card/50 rounded-xl animate-pulse" />
        ))}
      </div>
    );
  }

  const userTransactions = transactions?.filter(tx => 
    tx.fromUserId === currentUserId || tx.toUserId === currentUserId
  ).sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());

  if (!userTransactions || userTransactions.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-64 border border-dashed border-white/10 rounded-xl bg-white/5">
        <Activity className="w-8 h-8 text-muted-foreground mb-4 opacity-50" />
        <p className="text-muted-foreground">No transactions found</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {userTransactions.map((tx, idx) => {
        const isIncoming = tx.toUserId === currentUserId;
        const statusColor = tx.status === 'completed' ? 'text-green-400' : tx.status === 'pending' ? 'text-yellow-400' : 'text-red-400';
        const StatusIcon = tx.status === 'completed' ? CheckCircle2 : tx.status === 'pending' ? Clock : XCircle;

        return (
          <motion.div
            key={tx.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: idx * 0.05 }}
            className="group flex items-center justify-between p-4 rounded-xl bg-card border border-border/40 hover:border-primary/30 hover:bg-card/80 transition-all duration-200"
          >
            <div className="flex items-center gap-4">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isIncoming ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'}`}>
                {isIncoming ? <ArrowDownLeft className="w-5 h-5" /> : <ArrowUpRight className="w-5 h-5" />}
              </div>
              
              <div>
                <h4 className="font-medium text-sm text-foreground">
                  {isIncoming ? 'Received' : 'Sent'} {tx.tokenSymbol}
                </h4>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span className="font-mono">{format(new Date(tx.createdAt!), "MMM d, HH:mm")}</span>
                  <span className="w-1 h-1 rounded-full bg-white/20" />
                  <span className="capitalize">{tx.type.replace('-', ' ')}</span>
                </div>
              </div>
            </div>

            <div className="flex flex-col items-end gap-1">
              <span className={`font-mono font-bold ${isIncoming ? 'text-emerald-400' : 'text-foreground'}`}>
                {isIncoming ? '+' : '-'}{tx.amount} <span className="text-xs opacity-60">{tx.tokenSymbol}</span>
              </span>
              <div className={`flex items-center gap-1.5 text-[10px] uppercase tracking-wider font-semibold ${statusColor}`}>
                <StatusIcon className="w-3 h-3" />
                {tx.status}
              </div>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}
