import { useState } from "react";
import { useUsers, useTransfer } from "@/hooks/use-spark";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { Loader2, SendHorizontal, Wallet } from "lucide-react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormMessage } from "@/components/ui/form";

const transferSchema = z.object({
  recipientId: z.string().min(1, "Recipient is required"),
  amount: z.string().min(1, "Amount is required").refine((val) => !isNaN(Number(val)) && Number(val) > 0, "Must be positive number"),
});

interface TransferFormProps {
  currentUserId: number;
  userBalance: number;
}

export function TransferForm({ currentUserId, userBalance }: TransferFormProps) {
  const { data: users } = useUsers();
  const { mutate: transfer, isPending } = useTransfer();
  const { toast } = useToast();
  
  const form = useForm<z.infer<typeof transferSchema>>({
    resolver: zodResolver(transferSchema),
    defaultValues: {
      recipientId: "",
      amount: "",
    },
  });

  const onSubmit = (values: z.infer<typeof transferSchema>) => {
    if (Number(values.amount) > userBalance) {
      form.setError("amount", { message: "Insufficient balance" });
      return;
    }

    transfer(
      {
        fromUserId: currentUserId,
        toUserId: Number(values.recipientId),
        amount: Number(values.amount),
      },
      {
        onSuccess: (data) => {
          toast({
            title: "Transfer Successful",
            description: `Sent ${values.amount} tokens. Hash: ${data.txHash?.slice(0, 10)}...`,
          });
          form.reset();
        },
        onError: (error) => {
          toast({
            title: "Transfer Failed",
            description: error.message,
            variant: "destructive",
          });
        },
      }
    );
  };

  const recipientOptions = users?.filter(u => u.id !== currentUserId) || [];

  return (
    <Card className="glass-card p-6 lg:p-8 h-full">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2.5 rounded-lg bg-primary/10 text-primary">
          <SendHorizontal className="w-5 h-5" />
        </div>
        <div>
          <h2 className="text-xl font-bold font-display">Quick Transfer</h2>
          <p className="text-sm text-muted-foreground">Send tokens instantly via blockchain</p>
        </div>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="recipientId"
            render={({ field }) => (
              <FormItem>
                <Label className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">Recipient</Label>
                <Select onValueChange={field.onChange} value={field.value}>
                  <FormControl>
                    <SelectTrigger className="h-12 bg-background/50 border-input hover:border-primary/50 transition-colors">
                      <SelectValue placeholder="Select beneficiary..." />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {recipientOptions.map((user) => (
                      <SelectItem key={user.id} value={user.id.toString()}>
                        <span className="font-medium text-foreground">{user.name}</span>
                        <span className="ml-2 text-xs text-muted-foreground">({user.bank})</span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="amount"
            render={({ field }) => (
              <FormItem>
                <Label className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">Amount</Label>
                <div className="relative">
                  <FormControl>
                    <Input 
                      placeholder="0.00" 
                      className="h-12 pl-10 bg-background/50 border-input font-mono text-lg hover:border-primary/50 transition-colors focus:ring-primary/20"
                      {...field} 
                    />
                  </FormControl>
                  <Wallet className="absolute left-3 top-3.5 w-5 h-5 text-muted-foreground" />
                  <div className="absolute right-3 top-3.5 text-xs font-mono text-muted-foreground bg-white/5 px-2 py-0.5 rounded">
                    Max: {userBalance}
                  </div>
                </div>
                <FormMessage />
              </FormItem>
            )}
          />

          <Button 
            type="submit" 
            className="w-full h-12 text-base font-semibold bg-gradient-to-r from-primary to-blue-600 hover:to-blue-500 shadow-lg shadow-blue-500/20"
            disabled={isPending}
          >
            {isPending ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                Processing Block...
              </>
            ) : (
              "Confirm Transfer"
            )}
          </Button>
        </form>
      </Form>
    </Card>
  );
}
