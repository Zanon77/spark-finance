## Packages
recharts | Dashboard charts for balance history and transaction flow
framer-motion | Smooth page transitions and interaction animations
lucide-react | Iconography for the dashboard
date-fns | Formatting transaction dates

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["'Outfit'", "sans-serif"],
  body: ["'DM Sans'", "sans-serif"],
  mono: ["'Space Mono'", "monospace"],
}
