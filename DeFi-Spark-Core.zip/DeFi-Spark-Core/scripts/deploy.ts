import { ethers } from "hardhat";

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deploying contracts with the account:", deployer.address);

  // 1. Deploy Consortium Stablecoin
  const CS = await ethers.getContractFactory("ConsortiumStablecoin");
  const cs = await CS.deploy();
  await cs.waitForDeployment();
  console.log("ConsortiumStablecoin deployed to:", await cs.getAddress());

  // 2. Deploy Bank A & Token A
  const DA = await ethers.getContractFactory("DepositToken");
  const da = await DA.deploy("DepositToken A", "DA");
  await da.waitForDeployment();
  const daAddress = await da.getAddress();
  console.log("DepositToken A deployed to:", daAddress);

  const BankA = await ethers.getContractFactory("Bank");
  const bankA = await BankA.deploy(daAddress, await cs.getAddress());
  await bankA.waitForDeployment();
  console.log("Bank A deployed to:", await bankA.getAddress());

  // Transfer ownership of DA to Bank A so it can mint/burn
  await da.transferOwnership(await bankA.getAddress());
  console.log("DA ownership transferred to Bank A");

  // 3. Deploy Bank B & Token B
  const DB = await ethers.getContractFactory("DepositToken");
  const db = await DB.deploy("DepositToken B", "DB");
  await db.waitForDeployment();
  const dbAddress = await db.getAddress();
  console.log("DepositToken B deployed to:", dbAddress);

  const BankB = await ethers.getContractFactory("Bank");
  const bankB = await BankB.deploy(dbAddress, await cs.getAddress());
  await bankB.waitForDeployment();
  console.log("Bank B deployed to:", await bankB.getAddress());

  // Transfer ownership of DB to Bank B
  await db.transferOwnership(await bankB.getAddress());
  console.log("DB ownership transferred to Bank B");
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
