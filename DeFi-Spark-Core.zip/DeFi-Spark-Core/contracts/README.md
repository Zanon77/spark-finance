# Smart Contracts

This folder contains the Solidity contracts for the Spark Finance prototype.

## Contracts
- `ConsortiumStablecoin.sol`: The universal settlement token (CS).
- `DepositToken.sol`: The bank-specific tokenized deposit (DA, DB).
- `Bank.sol`: Manages minting/burning and interactions with CS.

## Setup
1. Install dependencies: `npm install`
2. Compile: `npx hardhat compile`
3. Test: `npx hardhat test`
4. Deploy: `npx hardhat run scripts/deploy.ts`
