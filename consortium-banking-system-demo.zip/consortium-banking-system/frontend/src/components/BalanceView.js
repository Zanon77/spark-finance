import React, { useState, useEffect } from 'react';
import { Grid, Card, CardContent, Typography, Box, CircularProgress } from '@mui/material';
import AccountBalanceIcon from '@mui/icons-material/AccountBalance';
import { getBalance, addresses, checkKYC } from '../utils/contracts';

function BalanceView({ account }) {
  const [balances, setBalances] = useState({
    bankA: '0',
    bankB: '0',
    consortium: '0',
  });
  const [kycInfo, setKycInfo] = useState({ isWhitelisted: false, name: '' });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchBalances = async () => {
      if (!account) return;

      try {
        setLoading(true);
        const [bankABalance, bankBBalance, consortiumBalance, kyc] = await Promise.all([
          getBalance(addresses.bankA, account),
          getBalance(addresses.bankB, account),
          getBalance(addresses.consortium, account),
          checkKYC(account),
        ]);

        setBalances({
          bankA: bankABalance,
          bankB: bankBBalance,
          consortium: consortiumBalance,
        });
        setKycInfo(kyc);
      } catch (error) {
        console.error('Error fetching balances:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchBalances();

    // Refresh every 5 seconds
    const interval = setInterval(fetchBalances, 5000);
    return () => clearInterval(interval);
  }, [account]);

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" p={4}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box>
      <Typography variant="h5" gutterBottom>
        Account Balances
        {kycInfo.name && (
          <Typography component="span" variant="body2" color="text.secondary" sx={{ ml: 2 }}>
            ({kycInfo.name})
          </Typography>
        )}
      </Typography>

      {!kycInfo.isWhitelisted && (
        <Typography variant="body2" color="error" sx={{ mb: 2 }}>
          ⚠️ Your address is not KYC approved. You cannot perform transactions.
        </Typography>
      )}

      <Grid container spacing={3}>
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <Box display="flex" alignItems="center" mb={1}>
                <AccountBalanceIcon color="primary" sx={{ mr: 1 }} />
                <Typography variant="h6">Bank A</Typography>
              </Box>
              <Typography variant="h4" color="primary">
                {parseFloat(balances.bankA).toFixed(2)} DA
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Deposit Token A
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <Box display="flex" alignItems="center" mb={1}>
                <AccountBalanceIcon color="secondary" sx={{ mr: 1 }} />
                <Typography variant="h6">Bank B</Typography>
              </Box>
              <Typography variant="h4" color="secondary">
                {parseFloat(balances.bankB).toFixed(2)} DB
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Deposit Token B
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <Box display="flex" alignItems="center" mb={1}>
                <AccountBalanceIcon sx={{ mr: 1, color: '#4caf50' }} />
                <Typography variant="h6">Consortium</Typography>
              </Box>
              <Typography variant="h4" sx={{ color: '#4caf50' }}>
                {parseFloat(balances.consortium).toFixed(2)} CS
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Consortium Stablecoin
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}

export default BalanceView;
