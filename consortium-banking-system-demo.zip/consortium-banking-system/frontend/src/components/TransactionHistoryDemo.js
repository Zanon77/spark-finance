import React, { useState } from 'react';
import {
  Paper,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  Box,
} from '@mui/material';

// Mock transaction data
const mockTransactions = [
  {
    id: 1,
    type: 'DEPOSIT',
    amount: '10000',
    from: '0x70997970C51812dc3A010C7d01b50e0d17dc79C8',
    to: 'Bank A',
    timestamp: new Date().toISOString(),
    txHash: '0xabc123def456',
    tokenType: 'DA'
  },
  {
    id: 2,
    type: 'CONVERSION',
    amount: '4000',
    from: '0x70997970C51812dc3A010C7d01b50e0d17dc79C8',
    to: 'Consortium',
    timestamp: new Date(Date.now() - 3600000).toISOString(),
    txHash: '0xdef456ghi789',
    tokenType: 'CS'
  },
  {
    id: 3,
    type: 'TRANSFER',
    amount: '1200',
    from: '0x70997970C51812dc3A010C7d01b50e0d17dc79C8',
    to: '0x90F79bf6EB2c4f870365E785982E1f101E93b906',
    timestamp: new Date(Date.now() - 7200000).toISOString(),
    txHash: '0xghi789jkl012',
    tokenType: 'DA'
  },
];

function TransactionHistoryDemo({ account }) {
  const [transactions] = useState(mockTransactions.filter(
    tx => tx.from === account.address || tx.to === account.address
  ));

  const getTypeColor = (type) => {
    switch (type) {
      case 'DEPOSIT':
        return 'success';
      case 'TRANSFER':
        return 'primary';
      case 'CONVERSION':
        return 'warning';
      default:
        return 'default';
    }
  };

  const formatAddress = (addr) => {
    if (addr.includes('Bank') || addr.includes('Consortium')) return addr;
    return `${addr.substring(0, 6)}...${addr.substring(addr.length - 4)}`;
  };

  return (
    <Paper sx={{ p: 3 }}>
      <Typography variant="h6" gutterBottom>
        Transaction History
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        All blockchain transactions for {account.name}
      </Typography>

      {transactions.length === 0 ? (
        <Box sx={{ p: 3, textAlign: 'center', bgcolor: '#f5f5f5', borderRadius: 1 }}>
          <Typography variant="body2" color="text.secondary">
            No transactions yet. Start by making a deposit!
          </Typography>
        </Box>
      ) : (
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell><strong>Type</strong></TableCell>
                <TableCell><strong>Amount</strong></TableCell>
                <TableCell><strong>Token</strong></TableCell>
                <TableCell><strong>From</strong></TableCell>
                <TableCell><strong>To</strong></TableCell>
                <TableCell><strong>Date</strong></TableCell>
                <TableCell><strong>TX Hash</strong></TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {transactions.map((tx) => (
                <TableRow key={tx.id} hover>
                  <TableCell>
                    <Chip label={tx.type} color={getTypeColor(tx.type)} size="small" />
                  </TableCell>
                  <TableCell>
                    <strong>${parseFloat(tx.amount).toLocaleString()}</strong>
                  </TableCell>
                  <TableCell>
                    <Chip label={tx.tokenType} variant="outlined" size="small" />
                  </TableCell>
                  <TableCell>{formatAddress(tx.from)}</TableCell>
                  <TableCell>{formatAddress(tx.to)}</TableCell>
                  <TableCell>
                    {new Date(tx.timestamp).toLocaleString()}
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2" sx={{ fontFamily: 'monospace', color: '#1976d2' }}>
                      {tx.txHash}
                    </Typography>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      <Box sx={{ mt: 3, p: 2, bgcolor: '#f5f5f5', borderRadius: 1 }}>
        <Typography variant="caption" color="text.secondary">
          <strong>Note:</strong> In production, this data would be fetched from the backend API which tracks all on-chain events and stores them in PostgreSQL with indexed views for fast querying.
        </Typography>
      </Box>
    </Paper>
  );
}

export default TransactionHistoryDemo;
