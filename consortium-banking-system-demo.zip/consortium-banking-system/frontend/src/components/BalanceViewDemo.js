import React, { useState, useEffect } from 'react';
import { Grid, Card, CardContent, Typography, Box } from '@mui/material';
import AccountBalanceIcon from '@mui/icons-material/AccountBalance';

// Simulated balances storage
const balanceStore = {
  '0x70997970C51812dc3A010C7d01b50e0d17dc79C8': { bankA: 10000, bankB: 0, consortium: 0 }, // Alice
  '0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC': { bankA: 0, bankB: 10000, consortium: 0 }, // Bob
  '0x90F79bf6EB2c4f870365E785982E1f101E93b906': { bankA: 0, bankB: 0, consortium: 0 }, // Carol
  '0x15d34AAf54267DB7D7c367839AAf71A00a2C6A65': { bankA: 0, bankB: 0, consortium: 0 }, // Dave
};

export function updateBalance(address, token, amount) {
  if (!balanceStore[address]) {
    balanceStore[address] = { bankA: 0, bankB: 0, consortium: 0 };
  }
  balanceStore[address][token] = amount;
}

export function getBalances(address) {
  return balanceStore[address] || { bankA: 0, bankB: 0, consortium: 0 };
}

function BalanceViewDemo({ account }) {
  const [balances, setBalances] = useState({ bankA: 0, bankB: 0, consortium: 0 });

  useEffect(() => {
    const fetchBalances = () => {
      const currentBalances = getBalances(account.address);
      setBalances(currentBalances);
    };

    fetchBalances();

    // Refresh every 2 seconds
    const interval = setInterval(fetchBalances, 2000);
    return () => clearInterval(interval);
  }, [account]);

  return (
    <Box>
      <Typography variant="h5" gutterBottom>
        Account Balances - {account.name}
        <Typography component="span" variant="body2" color="text.secondary" sx={{ ml: 2 }}>
          (KYC Verified ✓)
        </Typography>
      </Typography>

      <Grid container spacing={3}>
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <Box display="flex" alignItems="center" mb={1}>
                <AccountBalanceIcon color="primary" sx={{ mr: 1 }} />
                <Typography variant="h6">Bank A</Typography>
              </Box>
              <Typography variant="h4" color="primary">
                {balances.bankA.toFixed(2)} DA
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Deposit Token A
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <Box display="flex" alignItems="center" mb={1}>
                <AccountBalanceIcon color="secondary" sx={{ mr: 1 }} />
                <Typography variant="h6">Bank B</Typography>
              </Box>
              <Typography variant="h4" color="secondary">
                {balances.bankB.toFixed(2)} DB
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Deposit Token B
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <Box display="flex" alignItems="center" mb={1}>
                <AccountBalanceIcon sx={{ mr: 1, color: '#4caf50' }} />
                <Typography variant="h6">Consortium</Typography>
              </Box>
              <Typography variant="h4" sx={{ color: '#4caf50' }}>
                {balances.consortium.toFixed(2)} CS
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Consortium Stablecoin
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}

export default BalanceViewDemo;
