import React, { useState, useEffect } from 'react';
import {
  AppBar,
  Toolbar,
  Typography,
  Container,
  Box,
  Alert,
  Tab,
  Tabs,
  Paper,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Button
} from '@mui/material';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import DepositFlowDemo from './components/DepositFlowDemo';
import ConversionFlowDemo from './components/ConversionFlowDemo';
import TransferFlowDemo from './components/TransferFlowDemo';
import BalanceViewDemo from './components/BalanceViewDemo';
import TransactionHistoryDemo from './components/TransactionHistoryDemo';

const theme = createTheme({
  palette: {
    mode: 'light',
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
  },
});

// Mock accounts from Hardhat
const MOCK_ACCOUNTS = [
  { address: '0x70997970C51812dc3A010C7d01b50e0d17dc79C8', name: 'Alice', bank: 'A' },
  { address: '0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC', name: 'Bob', bank: 'B' },
  { address: '0x90F79bf6EB2c4f870365E785982E1f101E93b906', name: 'Carol', bank: 'A' },
  { address: '0x15d34AAf54267DB7D7c367839AAf71A00a2C6A65', name: 'Dave', bank: 'A' },
];

function TabPanel({ children, value, index }) {
  return (
    <div hidden={value !== index} style={{ marginTop: '20px' }}>
      {value === index && <Box>{children}</Box>}
    </div>
  );
}

function App() {
  const [selectedAccount, setSelectedAccount] = useState(MOCK_ACCOUNTS[0]);
  const [tabValue, setTabValue] = useState(0);

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleAccountChange = (event) => {
    const account = MOCK_ACCOUNTS.find(acc => acc.address === event.target.value);
    setSelectedAccount(account);
  };

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            🏦 Consortium Banking System (Demo Mode)
          </Typography>
          
          <FormControl sx={{ minWidth: 200 }}>
            <InputLabel sx={{ color: 'white' }}>Account</InputLabel>
            <Select
              value={selectedAccount.address}
              onChange={handleAccountChange}
              label="Account"
              sx={{ 
                color: 'white',
                '.MuiOutlinedInput-notchedOutline': { borderColor: 'white' },
                '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: 'white' },
                '.MuiSvgIcon-root': { color: 'white' }
              }}
            >
              {MOCK_ACCOUNTS.map((account) => (
                <MenuItem key={account.address} value={account.address}>
                  {account.name} (Bank {account.bank})
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Toolbar>
      </AppBar>

      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Alert severity="info" sx={{ mb: 2 }}>
          <strong>Demo Mode:</strong> No MetaMask required. Select an account above to simulate blockchain transactions.
          All operations are simulated locally.
        </Alert>

        <BalanceViewDemo account={selectedAccount} />

        <Paper sx={{ mt: 3 }}>
          <Tabs value={tabValue} onChange={handleTabChange} aria-label="banking operations">
            <Tab label="Flow 1: Deposit" />
            <Tab label="Flow 2: Convert" />
            <Tab label="Flow 4 & 5: Transfer" />
            <Tab label="Transaction History" />
          </Tabs>

          <TabPanel value={tabValue} index={0}>
            <DepositFlowDemo account={selectedAccount} />
          </TabPanel>

          <TabPanel value={tabValue} index={1}>
            <ConversionFlowDemo account={selectedAccount} />
          </TabPanel>

          <TabPanel value={tabValue} index={2}>
            <TransferFlowDemo account={selectedAccount} />
          </TabPanel>

          <TabPanel value={tabValue} index={3}>
            <TransactionHistoryDemo account={selectedAccount} />
          </TabPanel>
        </Paper>

        <Paper sx={{ mt: 3, p: 3, bgcolor: '#f5f5f5' }}>
          <Typography variant="h6" gutterBottom>
            🎯 Five Core Banking Flows
          </Typography>
          <Typography variant="body2" component="div">
            <ol>
              <li><strong>Deposit → Tokenized Deposit:</strong> Convert cash to DA/DB tokens</li>
              <li><strong>Tokenized Deposit → Consortium Stablecoin:</strong> Convert DA/DB to CS</li>
              <li><strong>CS → Tokenized Deposit (Cross-Bank):</strong> Convert CS to any bank token</li>
              <li><strong>Intra-Bank Payment:</strong> Transfer within same bank (DA→DA or DB→DB)</li>
              <li><strong>Inter-Bank Payment:</strong> Transfer CS for cross-bank settlement</li>
            </ol>
          </Typography>
        </Paper>
      </Container>
    </ThemeProvider>
  );
}

export default App;
