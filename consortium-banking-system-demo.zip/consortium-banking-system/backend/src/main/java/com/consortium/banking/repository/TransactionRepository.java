package com.consortium.banking.repository;

import com.consortium.banking.model.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    
    Optional<Transaction> findByTxHash(String txHash);
    
    List<Transaction> findByFromAddressOrToAddressOrderByTimestampDesc(
        String fromAddress, 
        String toAddress
    );
    
    List<Transaction> findByFromAddressOrderByTimestampDesc(String fromAddress);
    
    List<Transaction> findByToAddressOrderByTimestampDesc(String toAddress);
    
    List<Transaction> findByTypeAndStatus(
        Transaction.TransactionType type, 
        Transaction.TransactionStatus status
    );
    
    @Query("SELECT t FROM Transaction t WHERE " +
           "(t.fromAddress = :address OR t.toAddress = :address) " +
           "AND t.timestamp >= :startDate " +
           "ORDER BY t.timestamp DESC")
    List<Transaction> findRecentTransactionsByAddress(
        @Param("address") String address,
        @Param("startDate") LocalDateTime startDate
    );
    
    @Query("SELECT t FROM Transaction t WHERE " +
           "t.tokenType = :tokenType " +
           "AND t.status = :status " +
           "ORDER BY t.timestamp DESC")
    List<Transaction> findByTokenTypeAndStatus(
        @Param("tokenType") String tokenType,
        @Param("status") Transaction.TransactionStatus status
    );
}
