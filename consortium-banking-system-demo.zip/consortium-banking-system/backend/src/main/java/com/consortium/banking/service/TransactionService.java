package com.consortium.banking.service;

import com.consortium.banking.model.Transaction;
import com.consortium.banking.repository.TransactionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class TransactionService {
    
    private final TransactionRepository transactionRepository;
    
    @Transactional
    public Transaction saveTransaction(Transaction transaction) {
        log.info("Saving transaction: {}", transaction.getTxHash());
        return transactionRepository.save(transaction);
    }
    
    public Optional<Transaction> getTransactionByHash(String txHash) {
        return transactionRepository.findByTxHash(txHash);
    }
    
    public List<Transaction> getTransactionsByAddress(String address) {
        return transactionRepository.findByFromAddressOrToAddressOrderByTimestampDesc(
            address, 
            address
        );
    }
    
    public List<Transaction> getRecentTransactions(String address, int days) {
        LocalDateTime startDate = LocalDateTime.now().minusDays(days);
        return transactionRepository.findRecentTransactionsByAddress(address, startDate);
    }
    
    public List<Transaction> getTransactionsByType(
        Transaction.TransactionType type, 
        Transaction.TransactionStatus status
    ) {
        return transactionRepository.findByTypeAndStatus(type, status);
    }
    
    public List<Transaction> getAllTransactions() {
        return transactionRepository.findAll();
    }
    
    @Transactional
    public Transaction updateTransactionStatus(
        String txHash, 
        Transaction.TransactionStatus status,
        String errorMessage
    ) {
        Optional<Transaction> txOpt = transactionRepository.findByTxHash(txHash);
        if (txOpt.isPresent()) {
            Transaction transaction = txOpt.get();
            transaction.setStatus(status);
            if (errorMessage != null) {
                transaction.setErrorMessage(errorMessage);
            }
            return transactionRepository.save(transaction);
        }
        throw new RuntimeException("Transaction not found: " + txHash);
    }
}
