#!/bin/bash

echo "🏦 Consortium Banking System - Quick Start"
echo "=========================================="
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js 16+ first."
    exit 1
fi

# Check if Java is installed
if ! command -v java &> /dev/null; then
    echo "❌ Java is not installed. Please install Java 17+ first."
    exit 1
fi

echo "✅ Prerequisites check passed"
echo ""

# Function to install contract dependencies
install_contracts() {
    echo "📦 Installing smart contract dependencies..."
    cd contracts
    npm install
    cd ..
    echo "✅ Smart contract dependencies installed"
    echo ""
}

# Function to install frontend dependencies
install_frontend() {
    echo "📦 Installing frontend dependencies..."
    cd frontend
    
    # Copy env example if .env doesn't exist
    if [ ! -f .env ]; then
        cp .env.example .env
        echo "✅ Created .env file from .env.example"
    fi
    
    npm install
    cd ..
    echo "✅ Frontend dependencies installed"
    echo ""
}

# Function to install backend dependencies
install_backend() {
    echo "📦 Installing backend dependencies..."
    cd backend
    chmod +x mvnw
    ./mvnw clean install -DskipTests
    cd ..
    echo "✅ Backend dependencies installed"
    echo ""
}

# Main installation
echo "Starting installation..."
echo ""

install_contracts
install_frontend
install_backend

echo ""
echo "✨ Installation complete!"
echo ""
echo "Next steps:"
echo "1. Start PostgreSQL and create database: consortium_banking"
echo "2. Update backend/src/main/resources/application.properties with your DB credentials"
echo "3. Run: ./start-all.sh to start all services"
echo ""
