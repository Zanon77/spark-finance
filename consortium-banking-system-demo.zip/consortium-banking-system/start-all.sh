#!/bin/bash

echo "🏦 Starting Consortium Banking System"
echo "======================================"
echo ""

# Function to check if port is in use
check_port() {
    if lsof -Pi :$1 -sTCP:LISTEN -t >/dev/null ; then
        echo "⚠️  Port $1 is already in use"
        return 1
    fi
    return 0
}

# Check ports
check_port 8545
check_port 3000
check_port 8080

echo "Starting services..."
echo ""

# Start Hardhat node in background
echo "🔗 Starting local blockchain (Hardhat)..."
cd contracts
npx hardhat node > ../logs/hardhat.log 2>&1 &
HARDHAT_PID=$!
echo "   PID: $HARDHAT_PID"
cd ..

# Wait for Hardhat to start
sleep 5

# Deploy contracts
echo "📝 Deploying smart contracts..."
cd contracts
npx hardhat run scripts/deploy.js --network localhost > ../logs/deploy.log 2>&1
cd ..

# Start backend in background
echo "☕ Starting Java backend..."
cd backend
./mvnw spring-boot:run > ../logs/backend.log 2>&1 &
BACKEND_PID=$!
echo "   PID: $BACKEND_PID"
cd ..

# Wait for backend to start
sleep 10

# Start frontend
echo "⚛️  Starting React frontend..."
cd frontend
npm start &
FRONTEND_PID=$!
echo "   PID: $FRONTEND_PID"
cd ..

echo ""
echo "✅ All services started!"
echo ""
echo "Services:"
echo "- Blockchain:  http://localhost:8545"
echo "- Frontend:    http://localhost:3000"
echo "- Backend:     http://localhost:8080"
echo ""
echo "Logs are in ./logs/ directory"
echo ""
echo "To stop all services, run: ./stop-all.sh"
echo ""

# Save PIDs for cleanup
mkdir -p .pids
echo $HARDHAT_PID > .pids/hardhat.pid
echo $BACKEND_PID > .pids/backend.pid
echo $FRONTEND_PID > .pids/frontend.pid
