#!/bin/bash

echo "🛑 Stopping Consortium Banking System"
echo "======================================"
echo ""

# Function to stop process by PID file
stop_service() {
    SERVICE_NAME=$1
    PID_FILE=".pids/$2.pid"
    
    if [ -f "$PID_FILE" ]; then
        PID=$(cat "$PID_FILE")
        if ps -p $PID > /dev/null 2>&1; then
            echo "Stopping $SERVICE_NAME (PID: $PID)..."
            kill $PID
            rm "$PID_FILE"
        else
            echo "$SERVICE_NAME is not running"
            rm "$PID_FILE"
        fi
    else
        echo "No PID file found for $SERVICE_NAME"
    fi
}

stop_service "Hardhat" "hardhat"
stop_service "Backend" "backend"
stop_service "Frontend" "frontend"

# Also kill any remaining processes on these ports
echo ""
echo "Checking for remaining processes..."

if lsof -ti:8545 > /dev/null 2>&1; then
    echo "Killing process on port 8545..."
    lsof -ti:8545 | xargs kill -9
fi

if lsof -ti:3000 > /dev/null 2>&1; then
    echo "Killing process on port 3000..."
    lsof -ti:3000 | xargs kill -9
fi

if lsof -ti:8080 > /dev/null 2>&1; then
    echo "Killing process on port 8080..."
    lsof -ti:8080 | xargs kill -9
fi

echo ""
echo "✅ All services stopped"
