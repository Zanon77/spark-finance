# Consortium Banking System - Blockchain Hackathon Project

A full-stack decentralized banking system with tokenized deposits and consortium stablecoin.

## Project Structure

```
consortium-banking-system/
├── contracts/          # Hardhat Solidity smart contracts
├── frontend/          # React frontend application
├── backend/           # Java Spring Boot backend
└── README.md
```

## Features

- **Tokenized Deposits**: Banks can issue deposit tokens (DA, DB)
- **Consortium Stablecoin**: Inter-bank settlement layer (CS)
- **5 Core Flows**:
  1. Deposit → Tokenized Deposit
  2. Tokenized Deposit → Consortium Stablecoin
  3. CS → Tokenized Deposit (cross-bank)
  4. Intra-bank payments
  5. Inter-bank payments

## Quick Start

### Prerequisites
- Node.js v16+
- Java 17+
- PostgreSQL 14+
- MetaMask browser extension

### 1. Smart Contracts Setup

```bash
cd contracts
npm install
npx hardhat compile
npx hardhat node              # Start local blockchain (Terminal 1)
npx hardhat run scripts/deploy.js --network localhost  # Deploy contracts (Terminal 2)
```

### 2. Frontend Setup

```bash
cd frontend
npm install
npm run start                 # Starts on http://localhost:3000
```

### 3. Backend Setup

```bash
cd backend
./mvnw clean install
./mvnw spring-boot:run        # Starts on http://localhost:8080
```

### 4. Database Setup

```sql
-- Connect to PostgreSQL and run:
CREATE DATABASE consortium_banking;
-- Tables will be auto-created by Hibernate
```

## Environment Variables

### Frontend (.env)
```
REACT_APP_API_URL=http://localhost:8080
REACT_APP_CONTRACT_ADDRESS=<deployed_address>
```

### Backend (application.properties)
```
spring.datasource.url=jdbc:postgresql://localhost:5432/consortium_banking
spring.datasource.username=postgres
spring.datasource.password=your_password
```

## Architecture

### Smart Contracts
- **BankDepositToken.sol**: ERC-20 tokenized deposits (DA/DB)
- **ConsortiumStablecoin.sol**: Cross-bank settlement token (CS)
- **ConsortiumController.sol**: Multi-sig governance
- **KYCRegistry.sol**: Whitelist management

### Frontend
- React 18 with Hooks
- ethers.js for Web3 integration
- Material-UI components
- Real-time balance updates

### Backend
- Spring Boot 3.x
- PostgreSQL with JPA/Hibernate
- RESTful APIs
- Transaction history views

## Testing

```bash
# Smart Contracts
cd contracts
npx hardhat test

# Frontend
cd frontend
npm test

# Backend
cd backend
./mvnw test
```

## Demo Accounts

- **Alice**: BankA client (10,000 DA initial)
- **Bob**: BankB client (10,000 DB initial)
- **Carol**: BankA client
- **Dave**: BankA client

## License

MIT
