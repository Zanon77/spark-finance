import React, { useState } from 'react';
import {
  Box,
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Alert,
  CircularProgress,
  Typography,
  Paper,
  Tabs,
  Tab,
} from '@mui/material';
import SendIcon from '@mui/icons-material/Send';
import { transferDeposit, transferConsortium, addresses } from '../utils/contracts';

function TabPanel({ children, value, index }) {
  return (
    <div hidden={value !== index}>
      {value === index && <Box sx={{ pt: 2 }}>{children}</Box>}
    </div>
  );
}

function TransferFlow({ account }) {
  const [tabValue, setTabValue] = useState(0);
  const [bank, setBank] = useState('bankA');
  const [toAddress, setToAddress] = useState('');
  const [amount, setAmount] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  const handleIntraBankTransfer = async (e) => {
    e.preventDefault();
    setSuccess('');
    setError('');

    if (!toAddress || !amount) {
      setError('Please fill in all fields');
      return;
    }

    if (parseFloat(amount) > 10000) {
      setError('Exceeds per-transaction limit of $10,000');
      return;
    }

    try {
      setLoading(true);
      const bankAddress = bank === 'bankA' ? addresses.bankA : addresses.bankB;
      const txHash = await transferDeposit(bankAddress, toAddress, amount);
      setSuccess(`Transfer successful! Sent ${amount} ${bank === 'bankA' ? 'DA' : 'DB'}. TX: ${txHash.substring(0, 10)}...`);
      setToAddress('');
      setAmount('');
    } catch (err) {
      setError(err.message || 'Transfer failed');
    } finally {
      setLoading(false);
    }
  };

  const handleInterBankTransfer = async (e) => {
    e.preventDefault();
    setSuccess('');
    setError('');

    if (!toAddress || !amount) {
      setError('Please fill in all fields');
      return;
    }

    if (parseFloat(amount) > 10000) {
      setError('Exceeds per-transaction limit of $10,000');
      return;
    }

    try {
      setLoading(true);
      const txHash = await transferConsortium(toAddress, amount);
      setSuccess(`Transfer successful! Sent ${amount} CS. TX: ${txHash.substring(0, 10)}...`);
      setToAddress('');
      setAmount('');
    } catch (err) {
      setError(err.message || 'Transfer failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Paper sx={{ p: 3 }}>
      <Typography variant="h6" gutterBottom>
        Transfer Funds
      </Typography>

      <Tabs value={tabValue} onChange={(e, v) => setTabValue(v)} sx={{ mb: 2 }}>
        <Tab label="Intra-Bank (Flow 4)" />
        <Tab label="Inter-Bank (Flow 5)" />
      </Tabs>

      <TabPanel value={tabValue} index={0}>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
          Transfer deposit tokens within the same bank (DA to DA or DB to DB)
        </Typography>

        <Box component="form" onSubmit={handleIntraBankTransfer}>
          <FormControl fullWidth sx={{ mb: 2 }}>
            <InputLabel>Bank</InputLabel>
            <Select
              value={bank}
              label="Bank"
              onChange={(e) => setBank(e.target.value)}
            >
              <MenuItem value="bankA">Bank A (DA tokens)</MenuItem>
              <MenuItem value="bankB">Bank B (DB tokens)</MenuItem>
            </Select>
          </FormControl>

          <TextField
            fullWidth
            label="Recipient Address"
            value={toAddress}
            onChange={(e) => setToAddress(e.target.value)}
            sx={{ mb: 2 }}
            placeholder="0x..."
          />

          <TextField
            fullWidth
            label="Amount"
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            sx={{ mb: 2 }}
            inputProps={{ step: '0.01', min: '0' }}
          />

          {success && <Alert severity="success" sx={{ mb: 2 }}>{success}</Alert>}
          {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

          <Button
            type="submit"
            variant="contained"
            fullWidth
            startIcon={loading ? <CircularProgress size={20} /> : <SendIcon />}
            disabled={loading}
          >
            {loading ? 'Processing...' : 'Send'}
          </Button>
        </Box>
      </TabPanel>

      <TabPanel value={tabValue} index={1}>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
          Transfer consortium stablecoins (CS) for cross-bank settlement - works 24/7
        </Typography>

        <Box component="form" onSubmit={handleInterBankTransfer}>
          <TextField
            fullWidth
            label="Recipient Address"
            value={toAddress}
            onChange={(e) => setToAddress(e.target.value)}
            sx={{ mb: 2 }}
            placeholder="0x..."
          />

          <TextField
            fullWidth
            label="Amount (CS)"
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            sx={{ mb: 2 }}
            inputProps={{ step: '0.01', min: '0' }}
          />

          <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 2 }}>
            Daily Transfer Cap: $100,000 | Per Transaction: $10,000
          </Typography>

          {success && <Alert severity="success" sx={{ mb: 2 }}>{success}</Alert>}
          {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

          <Button
            type="submit"
            variant="contained"
            fullWidth
            startIcon={loading ? <CircularProgress size={20} /> : <SendIcon />}
            disabled={loading}
          >
            {loading ? 'Processing...' : 'Send CS'}
          </Button>
        </Box>
      </TabPanel>
    </Paper>
  );
}

export default TransferFlow;
