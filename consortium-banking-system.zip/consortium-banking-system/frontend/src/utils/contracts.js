import { ethers } from 'ethers';
import { getSigner } from './web3';

// Contract ABIs (simplified for demo)
const DEPOSIT_TOKEN_ABI = [
  "function deposit(uint256 amount) external",
  "function transferDeposit(address to, uint256 amount) external",
  "function balanceOf(address account) view returns (uint256)",
  "function name() view returns (string)",
  "function symbol() view returns (string)",
  "function burnForConsortium(uint256 amount, address from) external",
  "function mintFromConsortium(address to, uint256 amount) external",
  "event DepositMinted(address indexed user, uint256 amount)",
  "event DepositBurned(address indexed user, uint256 amount)",
  "event DepositTransferred(address indexed from, address indexed to, uint256 amount)"
];

const CONSORTIUM_TOKEN_ABI = [
  "function transferCS(address to, uint256 amount) external",
  "function balanceOf(address account) view returns (uint256)",
  "function mintFromBankReserve(address user, uint256 amount, address bank) external",
  "function burnAndCreatePending(address user, uint256 amount, address bank) external",
  "function pendingConversions(address bank) view returns (uint256)",
  "function bankReserves(address bank) view returns (uint256)",
  "event ConsortiumMinted(address indexed user, uint256 amount, address indexed bank)",
  "event ConsortiumBurned(address indexed user, uint256 amount)"
];

const KYC_REGISTRY_ABI = [
  "function isWhitelisted(address user) view returns (bool)",
  "function customerNames(address user) view returns (string)"
];

// Contract addresses from environment
const addresses = {
  kycRegistry: process.env.REACT_APP_KYC_ADDRESS,
  bankA: process.env.REACT_APP_BANK_A_ADDRESS,
  bankB: process.env.REACT_APP_BANK_B_ADDRESS,
  consortium: process.env.REACT_APP_CONSORTIUM_ADDRESS,
};

export const getDepositTokenContract = async (bankAddress) => {
  const signer = await getSigner();
  return new ethers.Contract(bankAddress, DEPOSIT_TOKEN_ABI, signer);
};

export const getConsortiumContract = async () => {
  const signer = await getSigner();
  return new ethers.Contract(addresses.consortium, CONSORTIUM_TOKEN_ABI, signer);
};

export const getKYCContract = async () => {
  const signer = await getSigner();
  return new ethers.Contract(addresses.kycRegistry, KYC_REGISTRY_ABI, signer);
};

// Banking operations
export const depositToBank = async (bankAddress, amount) => {
  const contract = await getDepositTokenContract(bankAddress);
  const tx = await contract.deposit(ethers.parseEther(amount.toString()));
  await tx.wait();
  return tx.hash;
};

export const transferDeposit = async (bankAddress, toAddress, amount) => {
  const contract = await getDepositTokenContract(bankAddress);
  const tx = await contract.transferDeposit(toAddress, ethers.parseEther(amount.toString()));
  await tx.wait();
  return tx.hash;
};

export const convertToConsortium = async (bankAddress, amount) => {
  const contract = await getDepositTokenContract(bankAddress);
  const signer = await getSigner();
  const userAddress = await signer.getAddress();
  
  // Burn deposit tokens
  const tx = await contract.burnForConsortium(ethers.parseEther(amount.toString()), userAddress);
  await tx.wait();
  
  return tx.hash;
};

export const transferConsortium = async (toAddress, amount) => {
  const contract = await getConsortiumContract();
  const tx = await contract.transferCS(toAddress, ethers.parseEther(amount.toString()));
  await tx.wait();
  return tx.hash;
};

export const getBalance = async (contractAddress, userAddress) => {
  const signer = await getSigner();
  const contract = new ethers.Contract(contractAddress, DEPOSIT_TOKEN_ABI, signer);
  const balance = await contract.balanceOf(userAddress);
  return ethers.formatEther(balance);
};

export const checkKYC = async (userAddress) => {
  const contract = await getKYCContract();
  const isWhitelisted = await contract.isWhitelisted(userAddress);
  const name = await contract.customerNames(userAddress);
  return { isWhitelisted, name };
};

export { addresses };
