import React, { useState, useEffect } from 'react';
import {
  AppBar,
  Toolbar,
  Typography,
  Container,
  Box,
  Alert,
  Tab,
  Tabs,
  Paper
} from '@mui/material';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import WalletConnection from './components/WalletConnection';
import DepositFlow from './components/DepositFlow';
import ConversionFlow from './components/ConversionFlow';
import TransferFlow from './components/TransferFlow';
import BalanceView from './components/BalanceView';
import TransactionHistory from './components/TransactionHistory';
import { connectWallet, getCurrentAccount } from './utils/web3';

const theme = createTheme({
  palette: {
    mode: 'light',
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
  },
});

function TabPanel({ children, value, index }) {
  return (
    <div hidden={value !== index} style={{ marginTop: '20px' }}>
      {value === index && <Box>{children}</Box>}
    </div>
  );
}

function App() {
  const [account, setAccount] = useState('');
  const [error, setError] = useState('');
  const [tabValue, setTabValue] = useState(0);

  useEffect(() => {
    const checkWallet = async () => {
      const acc = await getCurrentAccount();
      if (acc) {
        setAccount(acc);
      }
    };
    checkWallet();

    // Listen for account changes
    if (window.ethereum) {
      window.ethereum.on('accountsChanged', (accounts) => {
        if (accounts.length > 0) {
          setAccount(accounts[0]);
        } else {
          setAccount('');
        }
      });
    }
  }, []);

  const handleConnect = async () => {
    try {
      const acc = await connectWallet();
      setAccount(acc);
      setError('');
    } catch (err) {
      setError(err.message);
    }
  };

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            🏦 Consortium Banking System
          </Typography>
          <WalletConnection account={account} onConnect={handleConnect} />
        </Toolbar>
      </AppBar>

      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        {error && (
          <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>
            {error}
          </Alert>
        )}

        {!account ? (
          <Paper sx={{ p: 4, textAlign: 'center' }}>
            <Typography variant="h5" gutterBottom>
              Welcome to Consortium Banking
            </Typography>
            <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
              Connect your wallet to access tokenized banking services
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Please install MetaMask and connect to continue
            </Typography>
          </Paper>
        ) : (
          <>
            <BalanceView account={account} />

            <Paper sx={{ mt: 3 }}>
              <Tabs value={tabValue} onChange={handleTabChange} aria-label="banking operations">
                <Tab label="Deposit" />
                <Tab label="Convert" />
                <Tab label="Transfer" />
                <Tab label="History" />
              </Tabs>

              <TabPanel value={tabValue} index={0}>
                <DepositFlow account={account} />
              </TabPanel>

              <TabPanel value={tabValue} index={1}>
                <ConversionFlow account={account} />
              </TabPanel>

              <TabPanel value={tabValue} index={2}>
                <TransferFlow account={account} />
              </TabPanel>

              <TabPanel value={tabValue} index={3}>
                <TransactionHistory account={account} />
              </TabPanel>
            </Paper>
          </>
        )}
      </Container>
    </ThemeProvider>
  );
}

export default App;
