-- Database Views for Consortium Banking System

-- Create view for user transaction summary
CREATE OR REPLACE VIEW user_transaction_summary AS
SELECT 
    u.wallet_address,
    u.name,
    COUNT(DISTINCT t.id) as total_transactions,
    COUNT(DISTINCT CASE WHEN t.type = 'DEPOSIT' THEN t.id END) as deposit_count,
    COUNT(DISTINCT CASE WHEN t.type = 'TRANSFER' THEN t.id END) as transfer_count,
    COUNT(DISTINCT CASE WHEN t.type = 'CONVERSION' THEN t.id END) as conversion_count,
    SUM(CASE WHEN t.from_address = u.wallet_address THEN t.amount ELSE 0 END) as total_sent,
    SUM(CASE WHEN t.to_address = u.wallet_address THEN t.amount ELSE 0 END) as total_received,
    MAX(t.timestamp) as last_transaction_date
FROM users u
LEFT JOIN transactions t ON (u.wallet_address = t.from_address OR u.wallet_address = t.to_address)
GROUP BY u.wallet_address, u.name;

-- Create view for daily transaction volume
CREATE OR REPLACE VIEW daily_transaction_volume AS
SELECT 
    DATE(timestamp) as transaction_date,
    token_type,
    COUNT(*) as transaction_count,
    SUM(amount) as total_volume,
    AVG(amount) as average_amount,
    COUNT(DISTINCT from_address) as unique_senders,
    COUNT(DISTINCT to_address) as unique_receivers
FROM transactions
WHERE status = 'CONFIRMED'
GROUP BY DATE(timestamp), token_type
ORDER BY transaction_date DESC, token_type;

-- Create view for token distribution
CREATE OR REPLACE VIEW token_distribution AS
SELECT 
    'DA' as token_type,
    COUNT(DISTINCT CASE WHEN t.to_address IS NOT NULL THEN t.to_address END) as holder_count,
    SUM(CASE WHEN t.to_address IS NOT NULL THEN t.amount ELSE 0 END) as total_supply
FROM transactions t
WHERE t.token_type = 'DA' AND t.status = 'CONFIRMED'
UNION ALL
SELECT 
    'DB' as token_type,
    COUNT(DISTINCT CASE WHEN t.to_address IS NOT NULL THEN t.to_address END) as holder_count,
    SUM(CASE WHEN t.to_address IS NOT NULL THEN t.amount ELSE 0 END) as total_supply
FROM transactions t
WHERE t.token_type = 'DB' AND t.status = 'CONFIRMED'
UNION ALL
SELECT 
    'CS' as token_type,
    COUNT(DISTINCT CASE WHEN t.to_address IS NOT NULL THEN t.to_address END) as holder_count,
    SUM(CASE WHEN t.to_address IS NOT NULL THEN t.amount ELSE 0 END) as total_supply
FROM transactions t
WHERE t.token_type = 'CS' AND t.status = 'CONFIRMED';

-- Create view for failed transactions analysis
CREATE OR REPLACE VIEW failed_transactions_analysis AS
SELECT 
    DATE(timestamp) as failure_date,
    type,
    token_type,
    COUNT(*) as failure_count,
    error_message,
    COUNT(DISTINCT from_address) as affected_users
FROM transactions
WHERE status = 'FAILED'
GROUP BY DATE(timestamp), type, token_type, error_message
ORDER BY failure_date DESC;

-- Create view for inter-bank settlement summary
CREATE OR REPLACE VIEW inter_bank_settlement AS
SELECT 
    DATE(timestamp) as settlement_date,
    COUNT(*) as settlement_count,
    SUM(amount) as total_settled_amount,
    AVG(amount) as average_settlement,
    MIN(amount) as min_settlement,
    MAX(amount) as max_settlement
FROM transactions
WHERE token_type = 'CS' 
    AND type IN ('TRANSFER', 'CONVERSION')
    AND status = 'CONFIRMED'
GROUP BY DATE(timestamp)
ORDER BY settlement_date DESC;

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_transactions_from_address ON transactions(from_address);
CREATE INDEX IF NOT EXISTS idx_transactions_to_address ON transactions(to_address);
CREATE INDEX IF NOT EXISTS idx_transactions_timestamp ON transactions(timestamp);
CREATE INDEX IF NOT EXISTS idx_transactions_type_status ON transactions(type, status);
CREATE INDEX IF NOT EXISTS idx_transactions_token_type ON transactions(token_type);
CREATE INDEX IF NOT EXISTS idx_users_wallet_address ON users(wallet_address);
CREATE INDEX IF NOT EXISTS idx_users_kyc_verified ON users(kyc_verified);
