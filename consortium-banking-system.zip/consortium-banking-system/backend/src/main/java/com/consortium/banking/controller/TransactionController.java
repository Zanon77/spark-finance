package com.consortium.banking.controller;

import com.consortium.banking.model.Transaction;
import com.consortium.banking.service.TransactionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/transactions")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "${cors.allowed.origins}")
public class TransactionController {
    
    private final TransactionService transactionService;
    
    @PostMapping
    public ResponseEntity<Transaction> createTransaction(@RequestBody Transaction transaction) {
        log.info("Creating transaction: {}", transaction.getTxHash());
        try {
            Transaction saved = transactionService.saveTransaction(transaction);
            return ResponseEntity.status(HttpStatus.CREATED).body(saved);
        } catch (Exception e) {
            log.error("Error creating transaction", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    @GetMapping("/{address}")
    public ResponseEntity<List<Transaction>> getTransactionsByAddress(@PathVariable String address) {
        log.info("Fetching transactions for address: {}", address);
        try {
            List<Transaction> transactions = transactionService.getTransactionsByAddress(address);
            return ResponseEntity.ok(transactions);
        } catch (Exception e) {
            log.error("Error fetching transactions", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    @GetMapping("/hash/{txHash}")
    public ResponseEntity<Transaction> getTransactionByHash(@PathVariable String txHash) {
        log.info("Fetching transaction by hash: {}", txHash);
        return transactionService.getTransactionByHash(txHash)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }
    
    @GetMapping("/recent/{address}")
    public ResponseEntity<List<Transaction>> getRecentTransactions(
        @PathVariable String address,
        @RequestParam(defaultValue = "30") int days
    ) {
        log.info("Fetching recent {} days transactions for: {}", days, address);
        try {
            List<Transaction> transactions = transactionService.getRecentTransactions(address, days);
            return ResponseEntity.ok(transactions);
        } catch (Exception e) {
            log.error("Error fetching recent transactions", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    @GetMapping
    public ResponseEntity<List<Transaction>> getAllTransactions() {
        log.info("Fetching all transactions");
        try {
            List<Transaction> transactions = transactionService.getAllTransactions();
            return ResponseEntity.ok(transactions);
        } catch (Exception e) {
            log.error("Error fetching all transactions", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    @PutMapping("/{txHash}/status")
    public ResponseEntity<Transaction> updateTransactionStatus(
        @PathVariable String txHash,
        @RequestParam Transaction.TransactionStatus status,
        @RequestParam(required = false) String errorMessage
    ) {
        log.info("Updating transaction {} status to: {}", txHash, status);
        try {
            Transaction updated = transactionService.updateTransactionStatus(txHash, status, errorMessage);
            return ResponseEntity.ok(updated);
        } catch (Exception e) {
            log.error("Error updating transaction status", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
