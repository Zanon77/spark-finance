# Consortium Banking DApp

A full-stack blockchain-based banking system with tokenized deposits, consortium stablecoins, and inter-bank settlements.

## Architecture Overview

### Smart Contracts (Solidity)

- **DepositTokenA.sol**: Tokenized deposits for Bank A
- **DepositTokenB.sol**: Tokenized deposits for Bank B
- **ConsortiumStablecoin.sol**: Shared stablecoin for inter-bank settlements

### Frontend (React)

- Dashboard with real-time balances
- Transaction operations (deposit, convert, transfer)
- Live on-ledger transaction history

### Backend (Java/Spring Boot)

- User authentication
- H2 in-memory database (user data only)

## Key Features

✅ **Real Blockchain Integration**: Actual smart contract interactions via ethers.js
✅ **On-Ledger Transactions**: All deposit tokens and consortium tokens live on blockchain
✅ **KYC Enforcement**: Smart contract-level KYC checks
✅ **Reserve Management**: Dynamic consortium reserve tracking
✅ **Transaction History**: Live event listening from blockchain
✅ **Bank Restrictions**: BankA customers can only mint DA tokens, not DB

## Prerequisites

- Node.js v16+ and npm
- Java 17+
- Maven 3.6+

## Installation & Setup

### 1. Install Dependencies

```bash
# Root directory - Install Hardhat dependencies
npm install

# Frontend
cd frontend
npm install
cd ..

# Backend (Maven will handle dependencies)
```

### 2. Start Hardhat Local Blockchain

```bash
# Terminal 1: Start Hardhat node
npx hardhat node

# Keep this terminal running! It provides:
# - Local blockchain at http://127.0.0.1:8545
# - Test accounts with ETH
# - Block mining
```

### 3. Deploy Smart Contracts

```bash
# Terminal 2: Deploy contracts
npx hardhat run scripts/deploy.js --network localhost

# This will:
# - Deploy DepositTokenA, DepositTokenB, ConsortiumStablecoin
# - Link contracts together
# - Approve KYC for test users
# - Save deployment info to deployment.json
```

**Important**: Copy deployment.json to frontend/public/:

```bash
cp deployment.json frontend/public/
```

### 4. Start Backend

```bash
# Terminal 3
cd backend
mvn spring-boot:run

# Backend: http://localhost:8080
# H2 Console: http://localhost:8080/h2-console
```

### 5. Start Frontend

```bash
# Terminal 4
cd frontend
npm start

# Frontend: http://localhost:3000
```

## Usage

### Login Credentials

- alice / password123 (Bank A)
- bob / password123 (Bank B)
- carol / password123 (Bank A)
- dave / password123 (Bank A)

**Note**: No wallet extension needed! Accounts are automatically managed using Hardhat's built-in signers.

### Operations

1. **Deposit USD**: Convert off-ledger USD to on-ledger tokens
2. **Convert to Consortium**: Burn deposit tokens → mint CS tokens
3. **Intra-Bank Transfer**: Send deposit tokens within same bank
4. **Inter-Bank Transfer**: Send across banks via consortium

## Technical Details

### Smart Contract Events

- `DepositMinted(address user, uint256 amount)`
- `DepositBurned(address user, uint256 amount)`
- `DepositTransferred(address from, address to, uint256 amount)`
- `ConsortiumMinted(address user, uint256 amount, string bank)`
- `ConsortiumBurned(address user, uint256 amount)`

### Database Schema (H2)

Users table:

- id, username, password, bank, full_name, email, kyc_approved, usd_balance

Note: NO deposit token or consortium data in database - all on-chain!

### API Endpoints

- POST /api/auth/login
- GET /api/balance/{username}
- POST /api/balance/update

## Troubleshooting

**Blockchain not connecting?**

- Ensure Hardhat node is running on localhost:8545
- Check deployment.json exists in frontend/public/
- Verify contracts are deployed

**Transactions failing?**

- Verify KYC approval (should be automatic after deployment)
- Check account has sufficient balance
- Ensure Hardhat node is still running

**Frontend can't find contracts?**

- Confirm deployment.json copied to frontend/public/
- Check contract addresses in deployment.json match deployed contracts
- Restart frontend if needed

## Development Commands

```bash
# Compile contracts
npx hardhat compile

# Run tests
npx hardhat test

# Clean and rebuild
npx hardhat clean
npm install
```
