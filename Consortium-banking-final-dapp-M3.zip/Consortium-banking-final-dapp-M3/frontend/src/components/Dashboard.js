import React, { useState, useEffect } from "react";
import { ethers } from "ethers";
import { BlockchainService } from "../services/BlockchainService";
import "./Dashboard.css";

function Dashboard({ user, blockchainService, signer }) {
  const [balances, setBalances] = useState({
    depositToken: "0",
    consortium: "0",
    usd: "0",
  });
  const [reserves, setReserves] = useState({
    reserveA: "0",
    reserveB: "0",
    total: "0",
  });
  const [loading, setLoading] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);
  const [themedAlert, setThemedAlert] = useState(null);

  // Form states
  const [depositAmount, setDepositAmount] = useState("");
  const [convertToAmount, setConvertToAmount] = useState("");
  const [convertFromAmount, setConvertFromAmount] = useState("");
  const [transferAmount, setTransferAmount] = useState("");
  const [transferTo, setTransferTo] = useState("");
  const [interBankAmount, setInterBankAmount] = useState("");
  const [interBankTo, setInterBankTo] = useState("");
  // Admin form
  const [adminAddress, setAdminAddress] = useState("");
  const [adminBank, setAdminBank] = useState("BankA");

  const showAlert = (message, type = "info") => {
    setThemedAlert({
      id: Date.now(),
      message,
      type,
    });
  };

  useEffect(() => {
    if (user) {
      loadBalances();
      loadReserves();

      // Poll for updates every 2 seconds
      const interval = setInterval(() => {
        loadBalances();
        loadReserves();
      }, 2000);

      return () => clearInterval(interval);
    }
  }, [blockchainService, user]);

  useEffect(() => {
    if (!themedAlert) return;
    const timer = setTimeout(() => setThemedAlert(null), 4500);
    return () => clearTimeout(timer);
  }, [themedAlert?.id]);

  // Decide which bank reserve to show: Bob sees Bank B only, others see Bank A only
  const username = (user?.username || "").toLowerCase();
  const showBankBReserves = username === "bob";
  const showBankAReserves = !showBankBReserves;

  const loadBalances = async () => {
    try {
      const address = await signer.getAddress();
      console.log("Current signer address:", await signer.getAddress());
      console.log("Expected user address:", user.address);

      console.log(
        `Loading balances for user: ${user.username}, address: ${address}, bank: ${user.bank}`,
      );

      let tokenBal = "0";
      let csBal = "0";

      if (blockchainService) {
        // Force fresh reads without caching
        const tokenBalance = await blockchainService.getDepositTokenBalance(
          user.bank,
          address,
        );
        const csBalance = await blockchainService.getConsortiumBalance(address);
        tokenBal = ethers.formatEther(tokenBalance);
        csBal = ethers.formatEther(csBalance);

        console.log(`Updated balances for ${address}:`, {
          depositToken: tokenBal,
          consortium: csBal,
          bank: user.bank,
        });
      }

      // Get USD balance from backend
      const usdResponse = await fetch(
        `http://localhost:8080/api/balance/${user.username}`,
      );
      const usdData = await usdResponse.json();

      setBalances({
        depositToken: tokenBal,
        consortium: csBal,
        usd: usdData.balance || "0",
      });
    } catch (error) {
      console.error("Error loading balances:", error);
    }
  };

  const loadReserves = async () => {
    try {
      if (!blockchainService) {
        setReserves({ reserveA: "0", reserveB: "0", total: "0" });
        return;
      }
      const reserveData = await blockchainService.getReserves();
      setReserves(reserveData);
    } catch (error) {
      console.error("Error loading reserves:", error);
    }
  };

  const handleDeposit = async (e) => {
    e.preventDefault();
    if (!blockchainService) {
      showAlert(
        "Blockchain is not available. Start the local node to perform deposits.",
        "warning",
      );
      return;
    }

    setActionLoading(true);

    try {
      const amount = ethers.parseEther(depositAmount);
      const tx = await blockchainService.deposit(user.bank, amount);

      // Optimistically update UI: show deposited tokens and reduced USD immediately
      try {
        const deposit = parseFloat(depositAmount) || 0;
        setBalances((prev) => {
          const prevUsd = parseFloat(prev.usd) || 0;
          const prevDeposit = parseFloat(prev.depositToken) || 0;
          const newUsd = (prevUsd - deposit).toString();
          const newDeposit = (prevDeposit + deposit).toString();
          return {
            ...prev,
            usd: newUsd,
            depositToken: newDeposit,
          };
        });
      } catch (err) {
        console.warn("Failed to apply optimistic balance update", err);
      }

      // Wait for on-chain confirmation before reconciling balances
      try {
        if (tx && typeof tx.wait === "function") {
          await tx.wait();
        }
      } catch (waitErr) {
        console.warn("Error waiting for transaction confirmation", waitErr);
      }

      showAlert(`Deposit successful! Transaction: ${tx.hash}`, "success");

      // Update USD balance in backend
      await fetch("http://localhost:8080/api/balance/update", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: user.username,
          amount: -parseFloat(depositAmount),
        }),
      });

      setDepositAmount("");
      await loadBalances();
    } catch (error) {
      showAlert("Deposit failed: " + (error?.message || error), "error");
      console.error(error);
    } finally {
      setActionLoading(false);
    }
  };

  const handleConvertToConsortium = async (e) => {
    e.preventDefault();
    if (!blockchainService) {
      showAlert(
        "Blockchain is not available. Start the local node to perform conversions.",
        "warning",
      );
      return;
    }

    setActionLoading(true);

    try {
      const amount = ethers.parseEther(convertToAmount);
      const tx = await blockchainService.convertToConsortium(user.bank, amount);

      showAlert(`Conversion successful! Transaction: ${tx.hash}`, "success");
      setConvertToAmount("");
      await loadBalances();
      await loadReserves();
    } catch (error) {
      showAlert("Conversion failed: " + (error?.message || error), "error");
      console.error(error);
    } finally {
      setActionLoading(false);
    }
  };

  const handleConvertFromConsortium = async (e) => {
    e.preventDefault();
    if (!blockchainService) {
      showAlert(
        "Blockchain is not available. Start the local node to perform conversions.",
        "warning",
      );
      return;
    }

    setActionLoading(true);

    try {
      const amount = ethers.parseEther(convertFromAmount);
      const tx = await blockchainService.convertFromConsortium(
        user.bank,
        amount,
      );

      showAlert(`Conversion successful! Transaction: ${tx.hash}`, "success");
      setConvertFromAmount("");
      await loadBalances();
      await loadReserves();
    } catch (error) {
      showAlert("Conversion failed: " + (error?.message || error), "error");
      console.error(error);
    } finally {
      setActionLoading(false);
    }
  };

  const handleIntraBankTransfer = async (e) => {
    e.preventDefault();
    if (!blockchainService) {
      showAlert(
        "Blockchain is not available. Start the local node to perform transfers.",
        "warning",
      );
      return;
    }

    setActionLoading(true);

    try {
      const amount = ethers.parseEther(transferAmount);
      const tx = await blockchainService.intraBankTransfer(
        user.bank,
        transferTo,
        amount,
      );

      showAlert(`Transfer successful! Transaction: ${tx.hash}`, "success");
      setTransferAmount("");
      setTransferTo("");
      await loadBalances();
    } catch (error) {
      showAlert("Transfer failed: " + (error?.message || error), "error");
      console.error(error);
    } finally {
      setActionLoading(false);
    }
  };

  const handleInterBankTransfer = async (e) => {
    e.preventDefault();
    if (!blockchainService) {
      showAlert(
        "Blockchain is not available. Start the local node to perform inter-bank transfers.",
        "warning",
      );
      return;
    }

    setActionLoading(true);

    try {
      const targetBank = user.bank === "BankA" ? "BankB" : "BankA";
      const amount = ethers.parseEther(interBankAmount);
      const tx = await blockchainService.interBankTransfer(
        user.bank,
        targetBank,
        interBankTo,
        amount,
      );

      showAlert(
        `Inter-bank transfer successful! Transaction: ${tx.hash}`,
        "success",
      );
      setInterBankAmount("");
      setInterBankTo("");

      // Immediately refresh and then aggressively poll for 10 seconds
      await loadBalances();
      await loadReserves();

      // Trigger aggressive polling by updating state
      for (let i = 0; i < 10; i++) {
        await new Promise((resolve) => setTimeout(resolve, 500));
        await loadBalances();
        await loadReserves();
      }
    } catch (error) {
      showAlert(
        "Inter-bank transfer failed: " + (error?.message || error),
        "error",
      );
      console.error(error);
    } finally {
      setActionLoading(false);
    }
  };

  // Non-admin: request KYC approval by supplying admin credentials
  const handleRequestKYC = async () => {
    if (!signer || !signer.provider) {
      showAlert(
        "Start the local node and ensure you are connected before requesting KYC.",
        "warning",
      );
      return;
    }

    const adminKey = window.prompt(
      "Enter admin (owner) private key to perform KYC approval (keeps key local):",
    );
    if (!adminKey) return;

    // Basic check for private key format
    if (
      !adminKey.startsWith("0x") ||
      (adminKey.length !== 66 && adminKey.length !== 64)
    ) {
      if (
        !window.confirm(
          "The provided key does not look like a valid private key. Proceed anyway?",
        )
      )
        return;
    }

    let defaultAddress = "";
    try {
      defaultAddress = await signer.getAddress();
    } catch (err) {
      // ignore
    }

    const addressToApprove = window.prompt(
      "Address to approve (leave empty to approve your address):",
      defaultAddress || "",
    );
    if (!addressToApprove) return;

    const bankChoice = window.prompt(
      "Bank to approve for (BankA or BankB):",
      user.bank || "BankA",
    );
    if (!bankChoice) return;

    setActionLoading(true);
    try {
      // Create wallet locally first, then connect to provider to avoid ENS lookups
      const adminWallet = new ethers.Wallet(adminKey);
      const adminWalletConnected = adminWallet.connect(signer.provider);

      // Ask the user to confirm admin wallet address to avoid wrong-key mistakes
      const confirmed = window.confirm(
        `Using admin address ${adminWalletConnected.address} to approve KYC. Proceed?`,
      );
      if (!confirmed) {
        setActionLoading(false);
        return;
      }

      const adminService = new BlockchainService(adminWalletConnected);
      const initialized = await adminService.initialize();
      if (!initialized) {
        showAlert(
          "Failed to initialize blockchain service with admin key (check deployment.json).",
          "error",
        );
        setActionLoading(false);
        return;
      }

      const tx = await adminService.approveKYC(bankChoice, addressToApprove);
      showAlert("KYC approved! Transaction: " + (tx.hash || "n/a"), "success");
    } catch (err) {
      const errMsg =
        err?.reason ||
        err?.data?.message ||
        err?.error?.message ||
        err?.message ||
        String(err);
      showAlert("KYC approval request failed: " + errMsg, "error");
      console.error("KYC approval failed:", err);
    } finally {
      setActionLoading(false);
    }
  };

  // KYC disabled: approval UI and client flows removed/disabled
  /*
  const handleApproveKYC = async (e) => {
    e.preventDefault();
    if (!blockchainService) {
      alert('Blockchain is not available. Start the local node and log in as an admin to approve KYC.');
      return;
    }

    setActionLoading(true);
    try {
      const tx = await blockchainService.approveKYC(adminBank, adminAddress);
      alert(`KYC approved! Transaction: ${tx.hash}`);
      setAdminAddress('');
    } catch (error) {
      alert('Approve KYC failed: ' + (error?.message || error));
      console.error(error);
    } finally {
      setActionLoading(false);
    }
  };

  const handleApproveAllKYC = async () => {
    if (!blockchainService) {
      alert('Blockchain is not available. Start the local node and log in as admin to approve KYC.');
      return;
    }

    setActionLoading(true);
    try {
      await blockchainService.approveAllKYC();
      alert('KYC approved for all test users (where applicable).');
    } catch (error) {
      alert('Approve all KYC failed: ' + (error?.message || error));
      console.error(error);
    } finally {
      setActionLoading(false);
    }
  };

  // Non-admin: request KYC approval by supplying admin credentials
  const handleRequestKYC = async () => {
    if (!signer || !signer.provider) {
      alert('Start the local node and ensure you are connected before requesting KYC.');
      return;
    }

    const adminKey = window.prompt('Enter admin (owner) private key to perform KYC approval (keeps key local):');
    if (!adminKey) return;

    // Basic check for private key format
    if (!adminKey.startsWith('0x') || (adminKey.length !== 66 && adminKey.length !== 64)) {
      if (!window.confirm('The provided key does not look like a valid private key. Proceed anyway?')) return;
    }

    const addressToApprove = window.prompt('Address to approve (leave empty to approve your address):', user.address || '');
    if (!addressToApprove) return;

    const bankChoice = window.prompt('Bank to approve for (BankA or BankB):', user.bank || 'BankA');
    if (!bankChoice) return;

    setActionLoading(true);
    try {
      const adminWallet = new ethers.Wallet(adminKey, signer.provider);

      // Ask the user to confirm admin wallet address to avoid wrong-key mistakes
      const confirmed = window.confirm(`Using admin address ${adminWallet.address} to approve KYC. Proceed?`);
      if (!confirmed) {
        setActionLoading(false);
        return;
      }

      const adminService = new BlockchainService(adminWallet);
      const initialized = await adminService.initialize();
      if (!initialized) {
        alert('Failed to initialize blockchain service with admin key (check deployment.json).');
        setActionLoading(false);
        return;
      }

      const tx = await adminService.approveKYC(bankChoice, addressToApprove);
      alert('KYC approved! Transaction: ' + (tx.hash || 'n/a'));
    } catch (err) {
      // Friendly error parsing
      const errMsg = err?.reason || err?.data?.message || err?.error?.message || err?.message || String(err);
      alert('KYC approval request failed: ' + errMsg);
      console.error('KYC approval failed:', err);
    } finally {
      setActionLoading(false);
    }
  };
  */

  return (
    <div className="dashboard">
      {themedAlert && (
        <div
          className="themed-alert-backdrop"
          onClick={() => setThemedAlert(null)}
          role="presentation"
        >
          <div
            className={`themed-alert themed-alert-${themedAlert.type}`}
            role="alertdialog"
            aria-modal="true"
            onClick={(e) => e.stopPropagation()}
          >
            <span className="themed-alert-message">{themedAlert.message}</span>
            <button
              type="button"
              className="themed-alert-close"
              onClick={() => setThemedAlert(null)}
              aria-label="Dismiss alert"
            >
              Close
            </button>
          </div>
        </div>
      )}
      <h2>
        Dashboard -{" "}
        {(user.bank || "").toLowerCase() === "banka"
          ? "BNP Paribas"
          : (user.bank || "").toLowerCase() === "bankb"
          ? "Bank of America"
          : user.bank}
      </h2>
      {!blockchainService && (
        <div className="offline-banner">
          âš ï¸ Blockchain offline â€” on-chain operations are disabled. Start
          the Hardhat node to enable them.
        </div>
      )}

      {/* Balances Card */}
      <div className="card balances-card">
        <h3>Your Balances</h3>
        <div className="balance-grid">
          <div className="balance-item">
            <label>USD (Off-Ledger)</label>
            <span className="balance-value">${balances.usd}</span>
          </div>
          <div className="balance-item">
            <label>{user.bank === "BankA" ? "DA" : "DB"} (Deposit Token)</label>
            <span className="balance-value">
              {parseFloat(balances.depositToken).toFixed(4)}
            </span>
          </div>
          <div className="balance-item">
            <label>CS (Consortium)</label>
            <span className="balance-value">
              {parseFloat(balances.consortium).toFixed(4)}
            </span>
          </div>
        </div>
      </div>

      {/* Reserves Card */}
      <div className="card reserves-card">
        <h3>Consortium Reserves</h3>
        <div className="reserve-grid">
          {showBankAReserves && (
            <div className="reserve-item">
              <label>BNP Paribas Reserve</label>
              <span>{reserves.reserveA}</span>
            </div>
          )}

          {showBankBReserves && (
            <div className="reserve-item">
              <label>Bank B Reserve</label>
              <span>{reserves.reserveB}</span>
            </div>
          )}
        </div>
      </div>

      {/* Operations */}
      <div className="operations-grid">
        {/* Deposit */}
        <div className="card operation-card">
          <h3>USD to DA</h3>
          <p className="description">
            Convert off-ledger USD to on-ledger deposit tokens
          </p>
          <form onSubmit={handleDeposit}>
            <input
              type="number"
              step="0.01"
              placeholder="Amount (USD)"
              value={depositAmount}
              onChange={(e) => setDepositAmount(e.target.value)}
              required
            />
            <button
              type="submit"
              disabled={!blockchainService || actionLoading}
            >
              {actionLoading ? "Processing..." : "Deposit"}
            </button>
          </form>
        </div>

        {/* Convert to Consortium */}
        <div className="card operation-card">
          <h3>Convert to Consortium</h3>
          <p className="description">
            Convert deposit tokens to consortium stablecoin
          </p>
          <form onSubmit={handleConvertToConsortium}>
            <input
              type="number"
              step="0.01"
              placeholder="Amount"
              value={convertToAmount}
              onChange={(e) => setConvertToAmount(e.target.value)}
              required
            />
            <button
              type="submit"
              disabled={!blockchainService || actionLoading}
            >
              {actionLoading ? "Processing..." : `Mint CS`}
            </button>
          </form>
        </div>

        {/* Intra-bank Transfer */}
        <div className="card operation-card">
          <h3>Intra-Bank Transfer</h3>
          <p className="description">
            Send deposit tokens to another{" "}
            {(user.bank || "").toLowerCase() === "banka"
              ? "BNP Paribas"
              : (user.bank || "").toLowerCase() === "bankb"
              ? "Bank of America"
              : user.bank}{" "}
            customer
          </p>
          <form onSubmit={handleIntraBankTransfer}>
            <input
              type="text"
              placeholder="Recipient Address"
              value={transferTo}
              onChange={(e) => setTransferTo(e.target.value)}
              required
            />
            <input
              type="number"
              step="0.01"
              placeholder="Amount"
              value={transferAmount}
              onChange={(e) => setTransferAmount(e.target.value)}
              required
            />
            <button
              type="submit"
              disabled={!blockchainService || actionLoading}
            >
              {actionLoading ? "Processing..." : "Transfer"}
            </button>
          </form>
        </div>

        {/* Inter-bank Transfer */}
        <div className="card operation-card">
          <h3>Inter-Bank Transfer</h3>
          <p className="description">
            Send to {user.bank === "BankA" ? "Bank of America" : "BNP Paribas"}{" "}
            customer via consortium
          </p>
          <form onSubmit={handleInterBankTransfer}>
            <input
              type="text"
              placeholder="Recipient Address"
              value={interBankTo}
              onChange={(e) => setInterBankTo(e.target.value)}
              required
            />
            <input
              type="number"
              step="0.01"
              placeholder="Amount"
              value={interBankAmount}
              onChange={(e) => setInterBankAmount(e.target.value)}
              required
            />
            <button
              type="submit"
              disabled={!blockchainService || actionLoading}
            >
              {actionLoading ? "Processing..." : "Send"}
            </button>
          </form>
        </div>
      </div>

      {/* KYC features disabled â€” KYC assumed approved for all users */}
      {/* {user && user.username !== "admin" && (
        <div className="card kyc-request-card">
          <h3>Request KYC Approval</h3>
          <p className="description">
            Provide admin private key to approve KYC for an address (keeps key
            local).
          </p>
          <div>
            <button onClick={handleRequestKYC} disabled={actionLoading}>
              {actionLoading
                ? "Processing..."
                : "Request Approve KYC (enter admin key)"}
            </button>
          </div>
        </div>
      )} */}

      {/* Admin Panel (owner only) - KYC disabled */}
      {/* {false && user && user.username === "admin" && (
        <div className="card admin-card">
          <h3>Admin: KYC Management</h3>
          <p className="description">
            KYC is disabled in this build; approvals are not necessary.
          </p>
        </div>
      )} */}
    </div>
  );
}

export default Dashboard;
