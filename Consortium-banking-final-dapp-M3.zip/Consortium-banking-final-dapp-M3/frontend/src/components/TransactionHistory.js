import React, { useState, useEffect } from 'react';
import { ethers } from 'ethers';
import './TransactionHistory.css';

function TransactionHistory({ user, blockchainService }) {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    if (blockchainService && user) {
      loadTransactions();
      
      // Poll for new transactions every 10 seconds
      const interval = setInterval(() => {
        loadTransactions();
      }, 10000);
      
      return () => clearInterval(interval);
    }
  }, [blockchainService, user, filter]);

  const loadTransactions = async () => {
    try {
      setLoading(true);
      const txs = await blockchainService.getTransactionHistory(user.bank);
      
      // Filter transactions based on selected filter
      let filtered = txs;
      if (filter !== 'all') {
        filtered = txs.filter(tx => tx.type.toLowerCase() === filter.toLowerCase());
      }
      
      setTransactions(filtered);
    } catch (error) {
      console.error('Error loading transactions:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatAddress = (address) => {
    if (!address) return '';
    return `${address.substring(0, 6)}...${address.substring(38)}`;
  };

  const formatAmount = (amount) => {
    try {
      return parseFloat(ethers.formatEther(amount)).toFixed(4);
    } catch {
      return '0.0000';
    }
  };

  const formatTimestamp = (timestamp) => {
    return new Date(timestamp * 1000).toLocaleString();
  };

  const getTransactionTypeClass = (type) => {
    const typeMap = {
      'DepositMinted': 'deposit',
      'DepositBurned': 'burn',
      'DepositTransferred': 'transfer',
      'ConsortiumMinted': 'consortium-mint',
      'ConsortiumBurned': 'consortium-burn',
      'ConversionPending': 'pending'
    };
    return typeMap[type] || 'default';
  };

  return (
    <div className="transaction-history">
      <div className="history-header">
        <h2>Transaction History (On-Ledger)</h2>
        {!blockchainService && user && (
          <div className="offline-banner">⚠️ Blockchain offline — transaction history is unavailable until the node is started.</div>
        )}
        <div className="filter-buttons">
          <button 
            className={filter === 'all' ? 'active' : ''} 
            onClick={() => setFilter('all')}
          >
            All
          </button>
          <button 
            className={filter === 'depositminted' ? 'active' : ''} 
            onClick={() => setFilter('depositminted')}
          >
            Deposits
          </button>
          <button 
            className={filter === 'deposittransferred' ? 'active' : ''} 
            onClick={() => setFilter('deposittransferred')}
          >
            Transfers
          </button>
          <button 
            className={filter === 'consortiumminted' ? 'active' : ''} 
            onClick={() => setFilter('consortiumminted')}
          >
            Consortium
          </button>
        </div>
      </div>

      <div className="transaction-list">
        {loading ? (
          <div className="loading-spinner">Loading transactions...</div>
        ) : transactions.length === 0 ? (
          <div className="no-transactions">
            <p>No transactions found</p>
            <small>All on-ledger transactions will appear here</small>
          </div>
        ) : (
          <div className="transactions-grid">
            {transactions.map((tx, index) => (
              <div key={index} className={`transaction-card ${getTransactionTypeClass(tx.type)}`}>
                <div className="tx-header">
                  <span className="tx-type">{tx.type}</span>
                  <span className="tx-time">{formatTimestamp(tx.timestamp)}</span>
                </div>
                
                <div className="tx-details">
                  <div className="tx-row">
                    <label>Transaction Hash:</label>
                    <a 
                      href={`https://etherscan.io/tx/${tx.transactionHash}`} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="tx-hash"
                    >
                      {formatAddress(tx.transactionHash)}
                    </a>
                  </div>
                  
                  {tx.user && (
                    <div className="tx-row">
                      <label>User:</label>
                      <span>{formatAddress(tx.user)}</span>
                    </div>
                  )}
                  
                  {tx.from && (
                    <div className="tx-row">
                      <label>From:</label>
                      <span>{formatAddress(tx.from)}</span>
                    </div>
                  )}
                  
                  {tx.to && (
                    <div className="tx-row">
                      <label>To:</label>
                      <span>{formatAddress(tx.to)}</span>
                    </div>
                  )}
                  
                  <div className="tx-row amount-row">
                    <label>Amount:</label>
                    <span className="amount">{formatAmount(tx.amount)}</span>
                  </div>
                  
                  {tx.bank && (
                    <div className="tx-row">
                      <label>Bank:</label>
                      <span className="bank-badge">{tx.bank}</span>
                    </div>
                  )}
                  
                  {tx.targetBank && (
                    <div className="tx-row">
                      <label>Target Bank:</label>
                      <span className="bank-badge">{tx.targetBank}</span>
                    </div>
                  )}
                  
                  <div className="tx-row">
                    <label>Block:</label>
                    <span>#{tx.blockNumber}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      
      <div className="legend">
        <h4>Transaction Types:</h4>
        <ul>
          <li><span className="legend-dot deposit"></span> DepositMinted - USD converted to deposit tokens</li>
          <li><span className="legend-dot burn"></span> DepositBurned - Deposit tokens burned for consortium</li>
          <li><span className="legend-dot transfer"></span> DepositTransferred - Intra-bank transfer</li>
          <li><span className="legend-dot consortium-mint"></span> ConsortiumMinted - Consortium stablecoin minted</li>
          <li><span className="legend-dot consortium-burn"></span> ConsortiumBurned - Consortium stablecoin burned</li>
        </ul>
      </div>
    </div>
  );
}

export default TransactionHistory;
