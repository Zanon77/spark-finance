import React, { useState } from "react";
import axios from "axios";
import "./Login.css";

function Login({ onLogin }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      // Authenticate with backend
      const response = await axios.post(
        "http://localhost:8080/api/auth/login",
        {
          username,
          password,
        },
      );

      if (response.data.success) {
        onLogin(response.data.user);
      } else {
        setError("Invalid credentials");
      }
    } catch (err) {
      setError("Login failed. Please check your credentials and try again.");
      console.error("Login error:", err);
    } finally {
      setLoading(false);
    }
  };

  const quickLogin = (user) => {
    setUsername(user);
    setPassword("password123");
  };

  return (
    <div className="login-container">
      <div className="login-box">
        <h2>Consortium Banking</h2>
        <p className="subtitle">Blockchain-Powered Banking Infrastructure</p>

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Username</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Enter username"
              required
            />
          </div>

          <div className="form-group">
            <label>Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter password"
              required
            />
          </div>

          {error && <div className="error-message">{error}</div>}

          <button type="submit" className="login-btn" disabled={loading}>
            {loading ? "Authenticating..." : "Login"}
          </button>
        </form>

        <div className="quick-login">
          <p>Demo Accounts</p>
          <div className="demo-users">
            <button onClick={() => quickLogin("alice")} className="demo-btn">
              <strong>Alice</strong>
              <span>BNP Paribas</span>
            </button>
            <button onClick={() => quickLogin("bob")} className="demo-btn">
              <strong>Bob</strong>
              <span>Bank of America</span>
            </button>
            <button onClick={() => quickLogin("carol")} className="demo-btn">
              <strong>Carol</strong>
              <span>BNP Paribas</span>
            </button>
            <button onClick={() => quickLogin("dave")} className="demo-btn">
              <strong>Dave</strong>
              <span>BNP Paribas</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Login;
