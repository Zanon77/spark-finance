import React, { useState, useEffect } from "react";
import { ethers } from "ethers";
import Login from "./components/Login";
import Dashboard from "./components/Dashboard";
import TransactionHistory from "./components/TransactionHistory";
import { BlockchainService } from "./services/BlockchainService";
import "./App.css";

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [provider, setProvider] = useState(null);
  const [signer, setSigner] = useState(null);
  const [blockchainService, setBlockchainService] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    initializeBlockchain();
  }, []);

  const initializeBlockchain = async () => {
    try {
      // Connect to Hardhat local node
      const provider = new ethers.JsonRpcProvider("http://localhost:8545");
      setProvider(provider);
      console.log("Connected to Hardhat network");
    } catch (error) {
      console.error("Failed to initialize blockchain:", error);
    }
  };

  const handleLogin = async (userData) => {
    setLoading(true);
    try {
      // Get signer based on username (use predefined private keys)
      const userPrivateKeys = {
        alice:
          "0x59c6995e998f97a5a0044966f0945389dc9e86dae88c7a8412f4603b6b78690d", // Account #1
        bob: "0x5de4111afa1a4b94908f83103eb1f1706367c2e68ca870fc3fb9a804cdab365a", // Account #2
        carol:
          "0x7c852118294e51e653712a81e05800f419141751be58f605c371e15141b007a6", // Account #3
        dave: "0x47e179ec2c2b2b2c2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b", // Account #4
      };

      const privateKey = userPrivateKeys[userData.username];
      if (!privateKey) {
        // User not in mapping — show a helpful message and stop
        alert("User not found. Please check username.");
        setLoading(false);
        return;
      }

      let address;

      try {
        // Try to connect to Hardhat local node
        const provider = new ethers.JsonRpcProvider("http://localhost:8545");
        const signer = new ethers.Wallet(privateKey, provider);
        address = await signer.getAddress();

        setProvider(provider);
        setSigner(signer);

        // Initialize blockchain service (optional)
        const service = new BlockchainService(signer);
        const initialized = await service.initialize();
        if (initialized) {
          setBlockchainService(service);
        } else {
          console.warn(
            "Blockchain service failed to initialize; proceeding without on-chain capabilities",
          );
          setBlockchainService(null);
        }
      } catch (err) {
        // If blockchain isn't reachable, continue login without it
        console.warn(
          "Blockchain connection failed, proceeding without blockchain:",
          err,
        );
        const tempWallet = new ethers.Wallet(privateKey);
        address = await tempWallet.getAddress();
        setProvider(null);
        setSigner(tempWallet);
        setBlockchainService(null);
      }

      // Set user data with blockchain address (or fallback address)
      setCurrentUser({
        ...userData,
        address: address,
      });

      setIsLoggedIn(true);
    } catch (error) {
      console.error("Login failed:", error);
      // Silently fail—do not show the previous blockchain connection alert. Only alert on explicit missing user above.
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setCurrentUser(null);
    setSigner(null);
    setBlockchainService(null);
  };

  return (
    <div className="App">
      {loading && (
        <div className="loading-overlay">
          <div className="spinner"></div>
          <p>Connecting to blockchain...</p>
        </div>
      )}

      {!isLoggedIn ? (
        <Login onLogin={handleLogin} />
      ) : (
        <div className="app-container">
          <header className="app-header">
            <h1>Consortium Banking System</h1>
            <div className="user-info">
              <span>
                {currentUser.username} ({" "}
                {(currentUser.bank || "").toLowerCase() === "banka"
                  ? "BNP "
                  : (currentUser.bank || "").toLowerCase() === "bankb"
                  ? "BOA "
                  : currentUser.bank}
                )
              </span>
              <span className="address">
                {currentUser.address?.substring(0, 6)}...
                {currentUser.address?.substring(38)}
              </span>
              <button onClick={handleLogout} className="logout-btn">
                Logout
              </button>
            </div>
          </header>
          {isLoggedIn && !blockchainService && (
            <div className="global-offline-banner">
              ⚠️ Blockchain offline — on-chain features are disabled. Start the
              local node to enable them.
            </div>
          )}

          <div className="main-content">
            <Dashboard
              user={currentUser}
              blockchainService={blockchainService}
              signer={signer}
            />
            <TransactionHistory
              user={currentUser}
              blockchainService={blockchainService}
            />
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
