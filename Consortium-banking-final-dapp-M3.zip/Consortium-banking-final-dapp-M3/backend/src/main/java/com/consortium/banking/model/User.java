package com.consortium.banking.model;

import jakarta.persistence.*;

@Entity
@Table(name = "users")
public class User {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(unique = true, nullable = false)
    private String username;
    
    @Column(nullable = false)
    private String password;
    
    @Column(nullable = false)
    private String bank; // BankA or BankB
    
    @Column(name = "full_name")
    private String fullName;
    
    @Column
    private String email;
    
    @Column(name = "kyc_approved")
    private boolean kycApproved = true;
    
    @Column(name = "usd_balance")
    private Double usdBalance = 50000.0; // Initial balance
    
    // Constructors
    public User() {}
    
    public User(String username, String password, String bank, String fullName, String email) {
        this.username = username;
        this.password = password;
        this.bank = bank;
        this.fullName = fullName;
        this.email = email;
        this.kycApproved = true;
        this.usdBalance = 50000.0;
    }
    
    // Getters and Setters
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public String getUsername() {
        return username;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getBank() {
        return bank;
    }
    
    public void setBank(String bank) {
        this.bank = bank;
    }
    
    public String getFullName() {
        return fullName;
    }
    
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public boolean isKycApproved() {
        return kycApproved;
    }
    
    public void setKycApproved(boolean kycApproved) {
        this.kycApproved = kycApproved;
    }
    
    public Double getUsdBalance() {
        return usdBalance;
    }
    
    public void setUsdBalance(Double usdBalance) {
        this.usdBalance = usdBalance;
    }
}
