package com.consortium.banking.controller;

import com.consortium.banking.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "*")
public class AdminController {

    @Autowired
    private UserService userService;

    @PostMapping("/kyc")
    public ResponseEntity<Map<String, Object>> setKyc(@RequestBody Map<String, Object> body) {
        String username = (String) body.get("username");
        Boolean approved = (Boolean) body.get("approved");

        Map<String, Object> response = new HashMap<>();
        if (username == null || approved == null) {
            response.put("success", false);
            response.put("message", "username and approved are required");
            return ResponseEntity.badRequest().body(response);
        }

        boolean updated = userService.updateKyc(username, approved);
        if (updated) {
            response.put("success", true);
            response.put("message", "KYC status updated");
        } else {
            response.put("success", false);
            response.put("message", "User not found");
        }

        return ResponseEntity.ok(response);
    }
}
