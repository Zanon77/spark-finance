package com.consortium.banking.config;

import com.consortium.banking.model.User;
import com.consortium.banking.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Override
    public void run(String... args) throws Exception {
        // Clear existing data
        userRepository.deleteAll();

        // Create demo users
        User alice = new User("alice", "password123", "BankA", "Alice Johnson", "alice@example.com");
        User bob = new User("bob", "password123", "BankB", "Bob Smith", "bob@example.com");
        User carol = new User("carol", "password123", "BankA", "Carol Williams", "carol@example.com");
        User dave = new User("dave", "password123", "BankA", "Dave Brown", "dave@example.com");
        User admin = new User("admin", "password123", "BankA", "Admin", "admin@example.com");

        userRepository.save(alice);
        userRepository.save(bob);
        userRepository.save(carol);
        userRepository.save(dave);
        userRepository.save(admin);

        System.out.println("Demo users initialized:");
        System.out.println("- alice (BNP Paribas)");
        System.out.println("- bob (Bank of America)");
        System.out.println("- carol (BNP Paribas)");
        System.out.println("- dave (BNP Paribas)");
        System.out.println("- admin (BNP Paribas) [use for UI admin tasks]");
        System.out.println("Password for all: password123");
    }
}
