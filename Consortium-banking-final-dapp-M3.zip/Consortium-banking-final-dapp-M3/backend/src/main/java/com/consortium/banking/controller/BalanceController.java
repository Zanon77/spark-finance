package com.consortium.banking.controller;

import com.consortium.banking.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/balance")
@CrossOrigin(origins = "*")
public class BalanceController {
    
    @Autowired
    private UserService userService;
    
    @GetMapping("/{username}")
    public ResponseEntity<Map<String, Object>> getBalance(@PathVariable String username) {
        Double balance = userService.getBalance(username);
        
        Map<String, Object> response = new HashMap<>();
        response.put("username", username);
        response.put("balance", balance);
        
        return ResponseEntity.ok(response);
    }
    
    @PostMapping("/update")
    public ResponseEntity<Map<String, Object>> updateBalance(@RequestBody Map<String, Object> request) {
        String username = (String) request.get("username");
        Double amount = Double.parseDouble(request.get("amount").toString());
        
        boolean success = userService.updateBalance(username, amount);
        
        Map<String, Object> response = new HashMap<>();
        response.put("success", success);
        
        if (success) {
            response.put("newBalance", userService.getBalance(username));
        } else {
            response.put("message", "Insufficient balance or user not found");
        }
        
        return ResponseEntity.ok(response);
    }
}
